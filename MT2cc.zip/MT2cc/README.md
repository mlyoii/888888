# MT Workspace

构建指定插件：

```bash
./build main-plugin
./build main-plugin debug
./build main-plugin --extract-strings
```
build gggg --extract-strings
新建插件：

```bash
cp -r plugins/_template plugins/my-plugin
./build my-plugin
```
