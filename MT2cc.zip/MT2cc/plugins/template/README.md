Copy this directory to create a new plugin.
