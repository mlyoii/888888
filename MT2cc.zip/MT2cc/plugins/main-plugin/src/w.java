package cail;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import bin.mt.plugin.api.PluginContext;
import bin.mt.plugin.api.preference.PluginPreference;
import bin.mt.plugin.api.ui.*;
import bin.mt.plugin.api.ui.builder.PluginRootLayoutBuilder;

import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;

import org.json.JSONObject;
import java.lang.ref.WeakReference;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.widget.Toast;

import android.os.StatFs;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.hardware.SensorManager;
import android.hardware.Sensor;
import android.telephony.TelephonyManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.NetworkInterface;
import java.net.InetAddress;
import java.net.Inet4Address;
import java.util.Enumeration;


import java.util.Map;

import android.animation.ValueAnimator;
import android.animation.TimeInterpolator;
import android.view.animation.LinearInterpolator;
import android.graphics.Shader;
import android.graphics.LinearGradient;
import android.graphics.Matrix;

import android.view.DragEvent;
import java.util.Collections;
import java.util.HashMap;

public class w implements PluginPreference {

    PluginContext c;
    O o;
    public static WeakReference<PluginContext> weakContext;

    // 预定义的 API 服务商列表 (保持不变)
    static java.util.List<p> P = new ArrayList<>();

    static void initProviders() {
        if (!P.isEmpty()) return;
        P.addAll(Arrays.asList(
        new p("SiliconFlow", "https://api.siliconflow.cn/v1/chat/completions", "https://cloud.siliconflow.cn/i/3dPeL6IV", new String[]{"deepseek-ai/DeepSeek-V3", "Qwen/Qwen2.5-Coder-32B-Instruct", "Pro/deepseek-ai/DeepSeek-R1", "meta-llama/Llama-4-Maverick-17B-128E-Instruct"}),
        new p("Groq", "https://api.groq.com/openai/v1/chat/completions", "https://console.groq.com/keys", new String[]{"llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768", "gemma2-9b-it"}),
        new p("OpenRouter", "https://openrouter.ai/api/v1/chat/completions", "https://openrouter.ai/keys", new String[]{"openai/gpt-oss-120b", "meta-llama/llama-4-maverick-17b-128e-instruct", "anthropic/claude-3.5-sonnet", "google/gemini-flash-1.5"}),
        new p("Together AI", "https://api.together.xyz/v1/chat/completions", "https://api.together.ai/settings/api-keys", new String[]{"meta-llama/Llama-4-Maverick-17B-128E-Instruct", "deepseek-ai/DeepSeek-R1", "Qwen/Qwen3-32B", "mistralai/Mixtral-8x22B-Instruct"}),
        new p("Fireworks AI", "https://api.fireworks.ai/inference/v1/chat/completions", "https://fireworks.ai/api-keys", new String[]{"accounts/fireworks/models/llama-4-maverick-17b-128e-instruct", "accounts/fireworks/models/deepseek-r1", "accounts/fireworks/models/qwen3-32b"}),
        new p("Cloudflare Workers AI", "https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/v1/chat/completions", "https://dash.cloudflare.com/?to=/:account/workers-ai", new String[]{"@cf/meta/llama-4-maverick-17b-128e-instruct", "@cf/qwen/qwen3-32b", "@cf/openai/gpt-oss-120b"}),
        new p("Hugging Face", "https://router.huggingface.co/v1/chat/completions", "https://huggingface.co/settings/tokens", new String[]{"meta-llama/Llama-4-Maverick-17B-128E-Instruct", "Qwen/Qwen3-32B", "google/gemma-3-27b-it"}),
        new p("讯飞星火", "https://spark-api-open.xf-yun.com/v1/chat/completions", "https://console.xfyun.cn/services/bm35", new String[]{"generalv4", "4.0Ultra", "generalv3.5"}),
        new p("百度千帆", "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions", "https://console.bce.baidu.com/qianfan/ais/console/applicationConsole/application", new String[]{"ernie-4.5-8k", "ernie-4.5-turbo", "ernie-speed-128k"}),
        new p("腾讯混元", "https://api.hunyuan.cloud.tencent.com/v1/chat/completions", "https://console.cloud.tencent.com/hunyuan/apikey", new String[]{"hunyuan-turbo", "hunyuan-pro", "hunyuan-large"}),
        new p("智谱AI", "https://open.bigmodel.cn/api/paas/v4/chat/completions", "https://www.bigmodel.cn/invite?icode=ImA%2FFxt5NUUX36RyLLBwAEjPr3uHog9F4g5tjuOUqno%3D", new String[]{"glm-4-9b-chat", "glm-4v-plus", "glm-4-flash"}),
        new p("阿里通义千问", "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions", "https://dashscope.console.aliyun.com/apiKey", new String[]{"qwen-max", "qwen-plus", "qwen-turbo", "qwen3-32b"}),
        new p("Moonshot", "https://api.moonshot.cn/v1/chat/completions", "https://platform.moonshot.cn/console/api-keys", new String[]{"moonshot-v1-128k", "moonshot-v1-32k", "moonshot-v1-8k"}),
        new p("ChatAnywhere", "https://api.chatanywhere.org/v1/chat/completions", "https://github.com/chatanywhere/GPT_API_free", new String[]{"gpt-4o-mini", "gpt-3.5-turbo", "deepseek-chat"}),
        new p("Mistral AI", "https://api.mistral.ai/v1/chat/completions", "https://console.mistral.ai/api-keys", new String[]{"mistral-large-latest", "mistral-medium-3", "open-mistral-nemo", "pixtral-12b"}),
        new p("Cohere", "https://api.cohere.ai/v1/chat/completions", "https://dashboard.cohere.com/api-keys", new String[]{"command-r-plus", "command-a-03-2025", "command-r"}),
        new p("Perplexity", "https://api.perplexity.ai/chat/completions", "https://www.perplexity.ai/settings/api", new String[]{"sonar-pro", "sonar-reasoning-pro", "sonar-deep-research", "r1-1776"}),
        new p("DeepInfra", "https://api.deepinfra.com/v1/openai/chat/completions", "https://deepinfra.com/dashboard/api_keys", new String[]{"meta-llama/Llama-4-Maverick-17B-128E-Instruct", "deepseek-ai/DeepSeek-R1", "Qwen/Qwen3-32B"}),
        new p("Novita AI", "https://api.novita.ai/v1/chat/completions", "https://novita.ai/dashboard/api-keys", new String[]{"deepseek/deepseek-r1-turbo", "meta-llama/Llama-4-Maverick-17B", "Qwen/Qwen3-32B"}),
        new p("DeepSeek", "https://api.deepseek.com/v1/chat/completions", "https://platform.deepseek.com/api_keys", new String[]{"deepseek-chat", "deepseek-reasoner", "deepseek-v3.2"}),
        new p("OpenAI", "https://api.openai.com/v1/chat/completions", "https://platform.openai.com/api-keys", new String[]{"gpt-5.2", "gpt-4o", "gpt-4o-mini", "o3-pro"}),
        new p("Grok (xAI)", "https://api.x.ai/v1/chat/completions", "https://console.x.ai/api-keys", new String[]{"grok-4", "grok-4.1-fast", "grok-3"}),
        new p("Gemini (Google)", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "https://ai.google.dev/gemini-api/docs/api-key", new String[]{"gemini-2.5-pro", "gemini-2.0-flash", "gemini-3-pro"}),
        new p("Anthropic (Claude)", "https://api.anthropic.com/v1/chat/completions", "https://console.anthropic.com/settings/keys", new String[]{"claude-opus-4-1", "claude-sonnet-4-5", "claude-haiku-4-5"}),
        new p("自定义提供商", "", "", new String[]{})
        ));
    }

    static class p {
        String n, u, k; String[] m;
        p(String n, String u, String k, String[] m) { this.n = n; this.u = u; this.k = k; this.m = m; }
    }

    public void init(@NonNull PluginContext c) {
        this.c = c;
        weakContext = new WeakReference<>(c);
        this.o = new O();
        this.o.init(c);
    }

    @Override
    public void onBuild(@NonNull PluginContext c, @NonNull Builder b) {
        this.c = c;
        weakContext = new WeakReference<>(c);
        if (o == null) { o = new O(); o.init(c); }
        initProviders();
        SharedPreferences s = c.getPreferences();

        String uTemp = O.gUrl(c);
        if (uTemp.isEmpty()) uTemp = P.get(0).u;
        final String u = uTemp;

        String m = s.getString(O._0, P.get(0).m[0]);
        String n = g(u);
        boolean k = !O.g(c).isEmpty();

        b.title("AI文本分析助手设置");

        PluginPreference.Text def = b.addText("API 服务配置").summary("当前: " + n + " / " + m);
        def.onClick((i, t) -> S(i, s, t, def));

        boolean isDg = O.isDowngraded(c);
        String apiKeySummary = k ? (isDg ? "已存储 (⚠️安全降级模式)" : "已加密存储 (点击修改)") : "未设置 (点击设置)";
        PluginPreference.Text apiKeyPref = b.addText("API 密钥");
        apiKeyPref.summary(apiKeySummary);
        apiKeyPref.onClick((i, t) -> K(i, z -> {
            apiKeyPref.summary(z);
            u(t, z);
            if (t != apiKeyPref) u(apiKeyPref, z);
        }));

        b.addText("密钥保管箱").summary("管理多组API密钥").onClick((i, t) -> { if (o != null) o.kv(i); });
        b.addText("获取 API Key").summary("点击跳转当前服务商官网").onClick((i, t) -> U(i, u));

        b.addHeader("参数与提示词");
        b.addText("模型参数").summary("Temperature, Max Tokens 等").onClick((i, t) -> P(i));
        b.addText("分析提示词").summary("点击编辑分析使用的 Prompt").onClick((i, t) -> p(i));

        b.addHeader("界面定制");
        b.addText("背景与颜色设置").summary("透明度、自定义背景API、颜色定制").onClick((i, t) -> B(i));

        b.addHeader("功能管理");
        b.addSwitch("自动保存密钥到保管箱", "api_auto_kv").defaultValue(false).summary("开启后，配置或使用的 API Key 将自动保存到密钥保管箱");
        b.addSwitch("全局系统悬浮窗", "global_float_window").defaultValue(false).summary("开启后，在桌面显示悬浮图标，点击即可对话");
        
        if (Build.VERSION.SDK_INT >= 23) {
             Context gCtx = getGlobalContext();
             if (gCtx != null && !android.provider.Settings.canDrawOverlays(gCtx)) {
                 b.addText("⚠️ 授予悬浮窗权限").summary("点击授权以使用全局悬浮窗").onClick((ui, v) -> {
                     Context ctx = getGlobalContext();
                     if (ctx != null) {
                         Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.getPackageName()));
                         intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                         ctx.startActivity(intent);
                     }
                });
             }
        }
        b.addSwitch("继续对话时显示历史列表", O.I).defaultValue(false).summary("开启后，点击继续对话将弹出历史记录可供选择，否则默认使用最新对话");
        b.addSwitch("长按拖拽对话框按钮调整顺序", "dialog_drag_enabled").defaultValue(false).summary("开启后，对话框的“确定/取消”等按钮支持长按拖拽改变左右顺序");

        b.addText("对话管理").summary("查看和管理AI对话历史记录").onClick((i, t) -> {
            if (o != null) o.h(i);
        });
        b.addText("日志查看").summary("查看插件运行日志").onClick((i, t) -> c.openLogViewer());

        b.addHeader("关于");
        b.addText("使用指南").summary("查看详细使用说明").onClick((i, t) -> u(i));
        b.addText("关于插件").summary("版本、协议与鸣谢").onClick((i, t) -> a(i));
        b.addText("兼容性智能检测").summary("点击让 AI 分析当前环境是否适合运行本插件").onClick((i, t) -> C(i));

        applyLiquidGlassTheme(c);
    }

    // =========================================================
    // 液态玻璃主题重构逻辑 (Liquid Glass V3 - Reflection Based)
    // =========================================================

    private void applyLiquidGlassTheme(PluginContext c) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                Activity activity = findActivity();
                if (activity == null) return;

                SharedPreferences s = c.getPreferences();
                int bgMode = s.getInt("bg_mode", 0); // 0:内置, 1:文件, 2:API, 3:本地库
                String customPath = s.getString("bg_local_path", ""); // 修正 key
                String apiUrl = s.getString("bg_api_url", "https://yingciyuan.cn/pe.php");
                int userAlpha = s.getInt("bg_alpha", 0); // 用户输入的 255
                int alpha = 255 - userAlpha; // 255 - 255 = 0 (全透明)；255 - 0 = 255 (不透明)

                Window window = activity.getWindow();
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

                boolean success = false;

                // 背景图加载策略
                try {
                    if (bgMode == 0) {
                        success = loadBmpFromAsset(c, alpha, window);
                    } else if (bgMode == 1) {
                        if (!customPath.isEmpty() && new File(customPath).exists()) {
                            success = loadBmpFromFile(customPath, alpha, window);
                        }
                    } else if (bgMode == 2) {
                        success = loadBmpFromApiCached(c, apiUrl, alpha, window);
                    } else if (bgMode == 3) {
                        success = loadBmpFromLocalLibrary(alpha, window);
                    }
                } catch (Exception e) {
                    success = false;
                    new O.L(c).e("UI", "Bmp load error", e);
                }

                // 失败回退逻辑
                if (!success && bgMode != 0) {
                    loadBmpFromAsset(c, alpha, window);
                    c.showToast("背景加载失败，已回退至默认背景");
                } else if (!success) {
                    // mode 0 失败，尝试重新加载 asset
                    loadBmpFromAsset(c, alpha, window);
                }

                View rootView = window.getDecorView().findViewById(android.R.id.content);
                processViewsLiquidGlass(rootView);
                schedulePeriodicUpdate(rootView);
            } catch (Exception e) {
                 new O.L(c).e("UI", "Theme apply failed", e);
            }
        }, 10);
    }

    private boolean loadBmpFromAsset(PluginContext c, int alpha, Window w) {
        try (java.io.InputStream is = c.getAssetsAsStream("B.avif")) {
            Bitmap bmp = BitmapFactory.decodeStream(is);
            if (bmp != null) {
                w.getDecorView().setBackground(new AspectDrawable(bmp, 0xFFF0F0F0, alpha));
                return true;
            } else {
                // AVIF decoding fallback using WebView
                decodeAvif(c, "B.avif", (b) -> {
                    if (b != null) {
                        w.getDecorView().setBackground(new AspectDrawable(b, 0xFFF0F0F0, alpha));
                    }
                });
                return true; // Handled async
            }
        } catch (Exception e) {
             new O.L(c).e("UI", "Asset load failed", e);
        }
        return false;
    }

    private void decodeAvif(PluginContext c, String assetName, ValueCallback<Bitmap> cb) {
    // 1. 在子线程进行 IO 操作（读取流并转 Base64），避免阻塞主线程
    new Thread(() -> {
        String base64Image = null;
        try (java.io.InputStream is = c.getAssetsAsStream(assetName)) {
            if (is != null) {
                base64Image = inputStreamToBase64(is);
            }
        } catch (Exception e) {
            new O.L(c).e("UI", "Avif decode failed", e);
        }

        final String finalBase64 = base64Image;

        // 2. 切回主线程操作 WebView
        new Handler(Looper.getMainLooper()).post(() -> {
            if (finalBase64 == null) {
                cb.onReceiveValue(null);
                return;
            }

            try {
                Context ctx = (c instanceof Context) ? (Context) c : getGlobalContext();
                if (ctx == null) {
                    cb.onReceiveValue(null);
                    return;
                }

                WebView webView = new WebView(ctx);
                // 必须允许内容访问，虽然 Data URI 不需要文件权限，但保持设置无害
                webView.getSettings().setAllowContentAccess(true); 
                
                webView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        // 延迟一会以确保渲染完成
                        new Handler().postDelayed(() -> {
                            try {
                                if (view.getWidth() <= 0 || view.getHeight() <= 0) {
                                    android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
                                    view.measure(View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.EXACTLY),
                                            View.MeasureSpec.makeMeasureSpec(dm.heightPixels, View.MeasureSpec.EXACTLY));
                                    view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
                                }
                                
                                Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
                                Canvas canvas = new Canvas(bitmap);
                                view.draw(canvas);
                                cb.onReceiveValue(bitmap);
                                
                                // 建议在回调后清理 WebView，防止内存泄漏，但要确保 draw 已完成
                                view.destroy(); 
                            } catch (Exception e) {
                                new O.L(c).e("UI", "WebView draw failed", e);
                                cb.onReceiveValue(null);
                                try { view.destroy(); } catch (Exception ignored) {}
                            }
                        }, 100); // 100ms 延时，视图片大小可能需要调整
                    }
                });

                // 初始化布局参数，防止宽高为0
                android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
                webView.measure(View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(dm.heightPixels, View.MeasureSpec.EXACTLY));
                webView.layout(0, 0, webView.getMeasuredWidth(), webView.getMeasuredHeight());

                // 3. 构建包含 Base64 图片数据的 HTML
                // 使用 data:image/avif;base64, 协议
                String imgData = "data:image/avif;base64," + finalBase64;
                
                // CSS background 方式，确保覆盖全屏
                String html = "<html><body style='margin:0;padding:0;width:100%;height:100%;" +
                        "background-image:url(" + imgData + ");" +
                        "background-position:center center;" +
                        "background-repeat:no-repeat;" +
                        "background-size:cover;'>" + // 或者 cover，视需求而定
                        "</body></html>";

                webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);

            } catch (Exception e) {
                new O.L(c).e("UI", "WebView error", e);
                cb.onReceiveValue(null);
            }
        });
    }).start();
}

/**
 * 辅助方法：将 InputStream 转换为 Base64 字符串
 */
private String inputStreamToBase64(InputStream is) throws IOException {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    int nRead;
    byte[] data = new byte[16384]; // 16KB buffer
    while ((nRead = is.read(data, 0, data.length)) != -1) {
        buffer.write(data, 0, nRead);
    }
    buffer.flush();
    byte[] bytes = buffer.toByteArray();
    return Base64.encodeToString(bytes, Base64.NO_WRAP);
}

    private boolean loadBmpFromFile(String path, int alpha, Window w) {
        try (FileInputStream fis = new FileInputStream(path)) {
            Bitmap bmp = BitmapFactory.decodeStream(fis);
            if (bmp != null) {
                w.getDecorView().setBackground(new AspectDrawable(bmp, 0xFFF0F0F0, alpha));
                return true;
            }
        } catch (Exception e) {
             new O.L(c).e("UI", "File load failed: " + path, e);
        }
        return false;
    }

    // 新增：API 缓存逻辑
    private boolean loadBmpFromApiCached(PluginContext c, String url, int alpha, Window w) {
        try {
            File cacheDir = new File(c.getFilesDir(), "bg_cache");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            
            File next = new File(cacheDir, "next.jpg");
            File curr = new File(cacheDir, "curr.jpg");
            
            // 1. 如果有缓存的下一张，挪到当前使用，实现“预加载”效果
            if (next.exists() && next.length() > 0) {
                if (curr.exists()) curr.delete();
                next.renameTo(curr);
            }
            
            boolean loaded = false;
            
            // 2. 尝试加载当前图片
            if (curr.exists() && curr.length() > 0) {
                loaded = loadBmpFromFile(curr.getAbsolutePath(), alpha, w);
            }
            
            // 3. 如果没加载成功（无缓存或文件损坏），则使用旧的在线加载方式作为兜底（会慢）
            if (!loaded) {
                next.delete();
                // 暂时返回 false 让上层回退到默认背景，保证界面立刻响应
                // 同时触发下载任务
            }
            
            // 4. 无论如何，开启线程预下载下一张图片，供下次使用
            new Thread(() -> {
                try {
                    downloadFile(url, next);
                } catch (Exception e) {
                    new O.L(c).e("UI", "Download bg failed", e);
                }
            }).start();
            
            return loaded;
        } catch (Exception e) {
            new O.L(c).e("UI", "API cache load failed", e);
            return false;
        }
    }

    private void downloadFile(String urlStr, File target) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        try {
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setDoInput(true);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            conn.connect();
            
            // Ensure parent directory exists
            File parentDir = target.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                parentDir.mkdirs();
            }
    
            // 先下载到临时文件，下载完成后再重命名，防止文件损坏
            File tmp = new File(parentDir, target.getName() + "_" + UUID.randomUUID() + ".tmp");
            try (InputStream is = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(tmp)) {
                byte[] buffer = new byte[8192];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len);
                }
            }
            
            // Use Files.move for atomic operation if possible, fallback to delete+rename
            if (target.exists()) {
                 if (!target.delete()) {
                     // Try to force delete or handle error? For now log/ignore
                     new O.L(c).e("IO", "Target delete failed: " + target, null);
                 }
            }
            if (!tmp.renameTo(target)) {
                 // Fallback: Copy and delete
                 try {
                     Files.copy(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
                     tmp.delete();
                 } catch (Exception e) {
                     tmp.delete();
                     throw new IOException("Failed to move temp file to target: " + e.getMessage(), e);
                 }
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
    
    // 保持兼容旧代码
    private void loadBmpFromApi(String url, int alpha, Window w) {
       // 此方法已弃用，保留为空或重定向
    }

    private boolean loadBmpFromLocalLibrary(int alpha, Window w) {
        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(downloadsDir, "MT_AI_BG");
            if (dir.exists() && dir.isDirectory()) {
                File[] files = dir.listFiles((d, name) -> 
                    name.toLowerCase().endsWith(".jpg") || 
                    name.toLowerCase().endsWith(".png") || 
                    name.toLowerCase().endsWith(".webp"));
                
                if (files != null && files.length > 0) {
                    File randomFile = files[new Random().nextInt(files.length)];
                    return loadBmpFromFile(randomFile.getAbsolutePath(), alpha, w);
                }
            }
        } catch (Exception e) {
             new O.L(c).e("UI", "Local lib load failed", e);
        }
        return false;
    }

    private void schedulePeriodicUpdate(View rootView) {
        rootView.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            private long lastUpdateTime = 0;
            private boolean isFinished = false;
            private View cachedScrollContainer = null; 

            @Override
            public void onScrollChanged() {
                if (isFinished) return;

                long currentTime = System.currentTimeMillis();
                if (currentTime - lastUpdateTime >= 150) {
                    processViewsLiquidGlass(rootView);
                    lastUpdateTime = currentTime;

                    if (cachedScrollContainer == null) {
                        cachedScrollContainer = findRealScrollableContainer(rootView);
                    }

                    if (cachedScrollContainer == null) {
                        terminate();
                    } else {
                        // if (!cachedScrollContainer.canScrollVertically(1)) {
                        //    terminate();
                        // }
                    }
                }
            }

            private void terminate() {
                isFinished = true;
                rootView.post(() -> {
                    if (rootView.getViewTreeObserver().isAlive()) {
                        rootView.getViewTreeObserver().removeOnScrollChangedListener(this);
                    }
                });
            }
        });
        
        processViewsLiquidGlass(rootView);
    }

    /**
     * 深度递归搜索：找到真正能够滚动的那个 View
     */
    private View findRealScrollableContainer(View v) {
        if (v == null || v.getVisibility() != View.VISIBLE) return null;

        if (v.canScrollVertically(1) || v.canScrollVertically(-1)) {
            return v;
        }

        if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            for (int i = 0; i < group.getChildCount(); i++) {
                View found = findRealScrollableContainer(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private void processViewsLiquidGlass(View v) {
        if (v == null) return;
        SharedPreferences s = c.getPreferences();
        
        // 获取自定义颜色设置
        int colorTitle = s.getInt("color_title", 0xFF000000);
        int colorSummary = s.getInt("color_summary", 0xFF444444);
        int colorHeader = s.getInt("color_header", 0xFF333333);
        int colorText = s.getInt("color_text", 0xFF333333);
        int colorIcon = s.getInt("color_icon", 0xFF1D1D1F);
        int listAlpha = s.getInt("bg_list_alpha", 0x40); // 默认 0x40 (64)
        
        String idName = "";
        String className = v.getClass().getName();
        try { if (v.getId() != View.NO_ID) idName = v.getContext().getResources().getResourceEntryName(v.getId()); } catch (Exception e) {
             // ID 查找失败通常不重要，但如果需要调试可以记录
             new O.L(c).e("UI", "ID lookup failed", e);
        }

        if (idName.equals("MT_Protector")) {
            v.setBackgroundColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { v.setElevation(0f); v.setOutlineProvider(null); }
            ViewParent p = v.getParent();
            if (p instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) p;
                vg.setBackgroundColor(Color.TRANSPARENT);
                for (int i = 0; i < vg.getChildCount(); i++) {
                    View child = vg.getChildAt(i);
                    if (child != v && child.getHeight() > 0 && child.getHeight() < 15) child.setVisibility(View.GONE);
                }
            }
        }

        boolean isRecyclerViewItem = false;
        ViewParent pCheck = v.getParent();
        while (pCheck != null) {
            if (pCheck.getClass().getName().contains("RecyclerView")) { isRecyclerViewItem = true; break; }
            pCheck = pCheck.getParent();
        }

        if (v instanceof RelativeLayout || (isRecyclerViewItem && v instanceof ViewGroup && !className.contains("RecyclerView") && !className.contains("TextView"))) {
            // applyGlassCardStyle handles RenderEffect now
            applyGlassCardStyle(v, listAlpha);
            v.post(() -> {
        v.setPivotX(v.getWidth() / 2f);
        v.setPivotY(v.getHeight() / 2f);
    });
        }

        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            String text = tv.getText().toString();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) tv.setRenderEffect(null);

            if (text.equals("AI文本分析助手设置")) {
                tv.setTextColor(colorTitle);
                tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                tv.setShadowLayer(5, 0, 0, Color.WHITE);
            } else if (idName.equals("title")) {
                tv.setTextColor(colorText);
            } else if (idName.equals("summary")) {
                tv.setTextColor(colorSummary);
            } else {
                tv.setTextColor(colorHeader);
            }
        }

        if (v instanceof ImageButton) {
            CharSequence desc = v.getContentDescription();
            if (desc != null && desc.toString().contains("上一层级")) {
                ImageButton ib = (ImageButton) v;
                ib.setColorFilter(colorIcon, PorterDuff.Mode.SRC_IN);
                GradientDrawable circle = new GradientDrawable();
                circle.setShape(GradientDrawable.OVAL);
                circle.setColor(0x20000000);
                v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x30FFFFFF), null, circle));
            }
        }

        if (className.contains("Switch") || v instanceof CompoundButton) {
             // Remove RenderEffect clear to allow global effects if any
            
            int sThumbOn = s.getInt("color_sw_thumb_on", 0xFF2196F3);
            int sThumbOff = s.getInt("color_sw_thumb_off", 0xFFBBBBBB);
            int sTrackOn = s.getInt("color_sw_track_on", 0x662196F3);
            int sTrackOff = s.getInt("color_sw_track_off", 0x4D000000);

            int[][] states = new int[][]{ new int[]{-android.R.attr.state_checked}, new int[]{ android.R.attr.state_checked} };
            ColorStateList thumbTint = new ColorStateList(states, new int[]{sThumbOff, sThumbOn});
            ColorStateList trackTint = new ColorStateList(states, new int[]{sTrackOff, sTrackOn});

            try {
                Method setThumbTint = v.getClass().getMethod("setThumbTintList", ColorStateList.class);
                Method setTrackTint = v.getClass().getMethod("setTrackTintList", ColorStateList.class);
                setThumbTint.invoke(v, thumbTint);
                setTrackTint.invoke(v, trackTint);
            } catch (Exception e) {
                if (v instanceof CompoundButton && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) 
                    ((CompoundButton) v).setButtonTintList(thumbTint);
                new O.L(c).e("UI", "Switch tint failed", e);
            }
        }

        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) processViewsLiquidGlass(g.getChildAt(i));
        }
    }

    private void applyGlassCardStyle(View v, int listAlpha) {
        if (v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
            lp.setMargins(30, 15, 30, 15);
            v.setLayoutParams(lp);
        }

        // 修复：复用 LiquidGlassDrawable
        if (v.getBackground() instanceof LiquidGlassDrawable) {
            ((LiquidGlassDrawable) v.getBackground()).updateParams(listAlpha);
        } else {
            LiquidGlassDrawable bg = new LiquidGlassDrawable(listAlpha);
            bg.setView(v);
            v.setBackground(bg);
        }
        
        // 关键修改：减少 padding，让子 View 有“收缩空间”
    v.setPadding(40, 40, 40, 40);  // 原 40 → 改 20 或 16

    // 关键：强制设置缩放中心为 View 中心
    v.setPivotX(v.getWidth() / 2f);
    v.setPivotY(v.getHeight() / 2f);

    // 可选：提升动画流畅度
    v.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        
        // 尝试使用 RenderEffect (仅 Android 12+)
        if (Build.VERSION.SDK_INT >= 31) {
             v.setRenderEffect(null);
        }
        
        // 4. 点击缩放特效
        addClickScaleEffect(v);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            v.setForeground(new RippleDrawable(ColorStateList.valueOf(0x15FFFFFF), null, null));
        }
    }

    private void addClickScaleEffect(View v) {
        if (v.getTag(0xDEADBEEF) != null) return;
        v.setTag(0xDEADBEEF, "scaled");
        // v.setClickable(true); // 保持注释状态，通过 Drawable 响应状态变化来实现回弹

        // 移除 OnTouchListener，改由 LiquidGlassDrawable 的 onStateChange 驱动
        // 这样既能兼容 ListView 的点击（不拦截），又能兼容普通按钮的点击
    }

    /**
     * iOS 26 液态玻璃风格 Drawable (精简版 - 移除流光/模糊)
     */
    public static class LiquidGlassDrawable extends Drawable {
        private Paint mPaint;
        private Paint mBorderPaint;
        private Paint mHighlightPaint;
        
        private float mRadius = 45f; // 对应 2rem (约 30-40dp)
        
        private int mBaseAlpha;
        private boolean mIsPressed = false;
        
        // 新增：持有 View 的弱引用以控制动画
        private WeakReference<View> mViewRef;

        public LiquidGlassDrawable(int alpha) {
            init(alpha);
        }
        
        // 新增：设置关联 View
        public void setView(View v) {
            this.mViewRef = new WeakReference<>(v);
        }

        void init(int alpha) {
            mBaseAlpha = alpha;
            
            mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            mPaint.setColor(Color.WHITE);
            mPaint.setAlpha(alpha);
            mPaint.setStyle(Paint.Style.FILL);

            mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(3f);
            
            mHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            mHighlightPaint.setStyle(Paint.Style.FILL);
        }

        // 新增：更新参数
        public void updateParams(int alpha) {
            if (mBaseAlpha != alpha) {
                init(alpha);
                invalidateSelf();
            }
        }

        @Override
        public boolean isStateful() {
            return true;
        }

        @Override
        protected boolean onStateChange(int[] state) {
            boolean pressed = false;
            for (int s : state) {
                if (s == android.R.attr.state_pressed) {
                    pressed = true;
                    break;
                }
            }
            
            setPressed(pressed);
            
            // 触发 View 动画
            if (mViewRef != null) {
                View v = mViewRef.get();
                if (v != null) {
                    v.animate().cancel();

                    if (pressed) {
                        v.animate()
                            .scaleX(0.95f)
                            .scaleY(0.95f)
                            .setDuration(150)
                            .setInterpolator(new android.view.animation.DecelerateInterpolator())
                            .withLayer()
                            .start();
                    } else {
                        v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(300)
                            .setInterpolator(new android.view.animation.OvershootInterpolator(1.5f))
                            .withLayer()
                            .start();
                    }
                }
            }
            
            return super.onStateChange(state);
        }

        public void setPressed(boolean pressed) {
            if (mIsPressed != pressed) {
                mIsPressed = pressed;
                invalidateSelf();
            }
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            Rect b = getBounds();
            float w = b.width();
            float h = b.height();
            if (w <= 0 || h <= 0) return;
            
            // 动态调整圆角 (Hover/Press 效果)
            float currentRadius = mIsPressed ? mRadius * 1.2f : mRadius;

            // 1. 绘制玻璃本体 (Tint)
            mPaint.setColor(Color.WHITE);
            mPaint.setAlpha(mIsPressed ? mBaseAlpha + 20 : mBaseAlpha); // 按下变亮
            canvas.drawRoundRect(new RectF(b), currentRadius, currentRadius, mPaint);

            // 2. 绘制高光 (Shine - Inset Shadow simulation)

            // 顶部高光
            LinearGradient topShine = new LinearGradient(0, 0, 0, h/3,
                0x80FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            mHighlightPaint.setShader(topShine);
            canvas.drawRoundRect(new RectF(b.left+2, b.top+2, b.right-2, b.bottom-2), currentRadius, currentRadius, mHighlightPaint);
            
            // 左上角强烈反光
            RadialGradient spotShine = new RadialGradient(0, 0, w, 
                0x60FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            mHighlightPaint.setShader(spotShine);
            canvas.drawRoundRect(new RectF(b), currentRadius, currentRadius, mHighlightPaint);

            // 3. 绘制边框 (Border)
            // 渐变边框：左上白，右下透
            LinearGradient borderGrad = new LinearGradient(0, 0, w, h,
                new int[]{0xCCFFFFFF, 0x20FFFFFF, 0x40FFFFFF},
                null, Shader.TileMode.CLAMP);
            mBorderPaint.setShader(borderGrad);
            canvas.drawRoundRect(new RectF(b), currentRadius, currentRadius, mBorderPaint);
        }

        @Override
        public void setAlpha(int alpha) { mPaint.setAlpha(alpha); }
        @Override
        public void setColorFilter(@Nullable ColorFilter colorFilter) { mPaint.setColorFilter(colorFilter); }
        @Override
        public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /**
     * 自定义液态玻璃 Dialog
     * 替代系统 Dialog，实现完全自定义的 UI
     */
    public static class LiquidDialog {
        private final Context context;
        private final android.app.Dialog dialog;
        private final LinearLayout root;
        private final TextView titleView;
        private final FrameLayout contentContainer;
        private final LinearLayout buttonBar;
        private final ScrollView scrollView;
        private final PluginContext pluginContext;
        
        private static class BtnConfig {
            String text;
            bin.mt.plugin.api.ui.dialog.PluginDialog.OnClickListener listener;
            String type;
            BtnConfig(String t, bin.mt.plugin.api.ui.dialog.PluginDialog.OnClickListener l, String type) { text=t; listener=l; this.type=type; }
        }
        private java.util.Map<String, BtnConfig> buttons = new java.util.HashMap<>();
        private java.util.List<String> currentOrder = new java.util.ArrayList<>();

        public LiquidDialog(PluginUI ui) {
            Context ctx = null;
            try {
                  Object pc = ui.getContext();
                  if (pc instanceof Context) ctx = (Context) pc;
             } catch (Exception e) {
                 if (w.weakContext != null && w.weakContext.get() != null) {
                     new O.L(w.weakContext.get()).e("UI", "Context lookup failed", e);
                 }
             }
             if (ctx == null) ctx = new w().findActivity();
            if (ctx == null && w.weakContext != null) {
                Object obj = w.weakContext.get();
                if (obj instanceof Context) ctx = (Context) obj;
            }
            if (ctx == null) {
                try {
                    Class<?> atClass = Class.forName("android.app.ActivityThread");
                    ctx = (Context) atClass.getMethod("currentApplication").invoke(null);
                } catch (Exception e) {}
            }
            if (ctx == null) throw new RuntimeException("Cannot find Activity Context");

            this.context = ctx;
            
            PluginContext pcFromUi = null;
            try {
                if (ui.getContext() instanceof PluginContext) pcFromUi = (PluginContext) ui.getContext();
            } catch (Exception e) {}
            
            this.pluginContext = pcFromUi != null ? pcFromUi : (w.weakContext != null ? w.weakContext.get() : null);
            
            dialog = new android.app.Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (dialog.getWindow() != null) {
                // Fix: Set type for non-Activity context (e.g. Floating Window)
                if (!(context instanceof android.app.Activity)) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
                    } else {
                        dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
                    }
                }
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setDimAmount(0.5f);
            }

            int bgAlpha = 230;
            int titleColor = Color.BLACK;
            if (pluginContext != null) {
                SharedPreferences s = pluginContext.getPreferences();
                bgAlpha = s.getInt("bg_dialog_alpha", 230);
                if (bgAlpha < 50) bgAlpha = 230;
                titleColor = s.getInt("color_title", Color.BLACK);
                
                String orderStr = s.getString("dialog_btn_order", "NEU,NEG,POS");
                if(orderStr != null && !orderStr.isEmpty()) {
                    String[] parts = orderStr.split(",");
                    for(String p : parts) currentOrder.add(p.trim());
                }
            }
            if(currentOrder.isEmpty()) {
                currentOrder.add("NEU"); currentOrder.add("SPRING"); currentOrder.add("NEG"); currentOrder.add("POS");
            }

            root = new LinearLayout(context);
            root.setOrientation(LinearLayout.VERTICAL);
            LiquidGlassDrawable bg = new LiquidGlassDrawable(bgAlpha); 
            root.setBackground(bg);
            root.setPadding(50, 50, 50, 50);
            
            titleView = new TextView(context);
            titleView.setTextSize(18);
            titleView.setTypeface(Typeface.DEFAULT_BOLD);
            titleView.setTextColor(titleColor); 
            titleView.setPadding(0, 0, 0, 20);
            titleView.setVisibility(View.GONE);
            root.addView(titleView);

            scrollView = new ScrollView(context);
            scrollView.setVerticalScrollBarEnabled(false);
            scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
            
            contentContainer = new FrameLayout(context);
            scrollView.addView(contentContainer);
            
            LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f
            );
            root.addView(scrollView, scrollLp);

            buttonBar = new LinearLayout(context);
            buttonBar.setOrientation(LinearLayout.HORIZONTAL);
            buttonBar.setGravity(Gravity.END);
            buttonBar.setWeightSum(3.0f);
            buttonBar.setPadding(0, 20, 0, 0);
            root.addView(buttonBar);

            dialog.setContentView(root);
        }

        public LiquidDialog setPadding(int left, int top, int right, int bottom) {
            root.setPadding(left, top, right, bottom);
            buttonBar.setPadding(20, 20, 20, 20);
            titleView.setPadding(20, 20, 20, 20);
            return this;
        }

        public LiquidDialog setTitle(CharSequence title) {
            titleView.setText(title);
            titleView.setVisibility(View.VISIBLE);
            return this;
        }

        public LiquidDialog setMessage(CharSequence message) {
            TextView tv = new TextView(context);
            tv.setText(message);
            tv.setTextColor(Color.DKGRAY);
            tv.setTextSize(14);
            if (pluginContext != null) {
                SharedPreferences s = pluginContext.getPreferences();
                tv.setTextColor(s.getInt("color_text", Color.DKGRAY));
            }
            contentContainer.removeAllViews();
            contentContainer.addView(tv);
            return this;
        }

        public LiquidDialog setView(Object view) {
            View v = O.getRealView(view);
            if (v == null && view instanceof View) v = (View) view;
            
            if (v != null) {
                contentContainer.removeAllViews();
                if (v.getParent() != null) ((ViewGroup)v.getParent()).removeView(v);
                
                ViewGroup.LayoutParams lp = v.getLayoutParams();
                FrameLayout.LayoutParams flp;
                if (lp instanceof ViewGroup.MarginLayoutParams) {
                    flp = new FrameLayout.LayoutParams(lp.width, lp.height);
                    flp.setMargins(((ViewGroup.MarginLayoutParams)lp).leftMargin, 
                                   ((ViewGroup.MarginLayoutParams)lp).topMargin,
                                   ((ViewGroup.MarginLayoutParams)lp).rightMargin,
                                   ((ViewGroup.MarginLayoutParams)lp).bottomMargin);
                } else if (lp != null) {
                    flp = new FrameLayout.LayoutParams(lp);
                } else {
                    flp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                }
                v.setLayoutParams(flp);
                
                contentContainer.addView(v);
            }
            return this;
        }

        public LiquidDialog setCancelable(boolean flag) {
            dialog.setCancelable(flag);
            return this;
        }

        public LiquidDialog setPositiveButton(String text, bin.mt.plugin.api.ui.dialog.PluginDialog.OnClickListener listener) {
            buttons.put("POS", new BtnConfig(text, listener, "POS"));
            return this;
        }

        public LiquidDialog setNegativeButton(String text, bin.mt.plugin.api.ui.dialog.PluginDialog.OnClickListener listener) {
            buttons.put("NEG", new BtnConfig(text, listener, "NEG"));
            return this;
        }

        public LiquidDialog setNeutralButton(String text, bin.mt.plugin.api.ui.dialog.PluginDialog.OnClickListener listener) {
             buttons.put("NEU", new BtnConfig(text, listener, "NEU"));
             return this;
        }
        
        public LiquidDialog setItems(String[] items, bin.mt.plugin.api.ui.dialog.PluginDialog.OnClickListener listener) {
            LinearLayout list = new LinearLayout(context);
            list.setOrientation(LinearLayout.VERTICAL);
            int textColor = Color.BLACK;
            if (pluginContext != null) textColor = pluginContext.getPreferences().getInt("color_text", Color.BLACK);
            
            for (int i = 0; i < items.length; i++) {
                final int index = i;
                TextView tv = new TextView(context);
                tv.setText(items[i]);
                tv.setPadding(20, 30, 20, 30);
                tv.setTextSize(16);
                tv.setTextColor(textColor);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    tv.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x20000000), null, null));
                }
                tv.setOnClickListener(v -> {
                    if (listener != null) listener.onClick(null, index);
                    dialog.dismiss();
                });
                list.addView(tv);
            }
            contentContainer.removeAllViews();
            contentContainer.addView(list);
            return this;
        }

        private int getButtonColor(int slotIndex) {
            if (pluginContext == null) return Color.GRAY;
            SharedPreferences s = pluginContext.getPreferences();
            if (slotIndex == 0) return s.getInt("color_btn_neu", Color.LTGRAY);
            if (slotIndex == 1) return s.getInt("color_btn_neg", Color.GRAY);
            return s.getInt("color_btn_pos", Color.parseColor("#2196F3"));
        }

        public android.app.Dialog show() {
            renderButtons();
            try {
                dialog.show();
                Window w = dialog.getWindow();
                if (w != null) {
                    android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
                    w.setLayout((int)(dm.widthPixels * 0.85), ViewGroup.LayoutParams.WRAP_CONTENT);
                }
            } catch (Exception e) {
                if (pluginContext != null) new O.L(pluginContext).e("UI", "Dialog show failed", e);
            }
            return dialog;
        }

        private void renderButtons() {
            buttonBar.removeAllViews();
            boolean dragEnabled = pluginContext != null && pluginContext.getPreferences().getBoolean("dialog_drag_enabled", false);
            
            // 确保 currentOrder 包含所有存在的按钮类型
            for(String type : buttons.keySet()) {
                if(!currentOrder.contains(type)) currentOrder.add(type);
            }

            for(String type : currentOrder) {
                if (type.equals("SPRING")) {
                    View spring = new View(context);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 0, 1.0f);
                    spring.setLayoutParams(lp);
                    buttonBar.addView(spring);
                    continue;
                }

                if (!buttons.containsKey(type)) continue;

                BtnConfig b = buttons.get(type);
                TextView btn = new TextView(context);
                btn.setText(b.text);
                
                int colorIndex = 0; // default
                if (type.equals("NEG")) colorIndex = 1;
                else if (type.equals("POS")) colorIndex = 2;
                btn.setTextColor(getButtonColor(colorIndex));
                
                btn.setTypeface(Typeface.DEFAULT_BOLD);
                btn.setGravity(Gravity.CENTER);
                btn.setPadding(30, 20, 30, 20);

                // 如果有 Spring，按钮使用 wrap_content，否则平分
                boolean hasSpring = currentOrder.contains("SPRING");
                LinearLayout.LayoutParams lp;
                if (hasSpring) {
                    lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.weight = 0;
                    // 给按钮之间加点间距
                    lp.leftMargin = 10;
                    lp.rightMargin = 10;
                } else {
                    lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
                }
                btn.setLayoutParams(lp);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                     btn.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x20000000), null, null));
                }
                
                btn.setOnClickListener(v -> {
                    if (b.listener != null) b.listener.onClick(null, 0); 
                    dialog.dismiss();
                });

                if (dragEnabled) {
                    btn.setOnLongClickListener(v -> {
                        View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
                        if (Build.VERSION.SDK_INT >= 24) {
                            v.startDragAndDrop(null, shadow, b.type, 0);
                        } else {
                            v.startDrag(null, shadow, b.type, 0);
                        }
                        return true;
                    });
                    
                    btn.setOnDragListener((v, event) -> {
                        switch (event.getAction()) {
                            case DragEvent.ACTION_DROP:
                                Object localState = event.getLocalState();
                                if(localState instanceof String) {
                                    String srcType = (String) localState;
                                    String destType = b.type;
                                    if (!srcType.equals(destType)) {
                                        swapOrder(srcType, destType);
                                    }
                                }
                                return true;
                        }
                        return true;
                    });
                }
                buttonBar.addView(btn);
            }
        }
        
        private void swapOrder(String src, String dest) {
            int idx1 = currentOrder.indexOf(src);
            int idx2 = currentOrder.indexOf(dest);
            if(idx1 != -1 && idx2 != -1) {
                Collections.swap(currentOrder, idx1, idx2);
                if(pluginContext != null) {
                    StringBuilder sb = new StringBuilder();
                    for(int i=0; i<currentOrder.size(); i++) {
                        sb.append(currentOrder.get(i));
                        if(i < currentOrder.size()-1) sb.append(",");
                    }
                    pluginContext.getPreferences().edit().putString("dialog_btn_order", sb.toString()).apply();
                }
                renderButtons();
            }
        }
    }

    // =========================================================
    // 原有逻辑函数 (保留完整并增强背景设置)
    // =========================================================

    void B(PluginUI i) {
    SharedPreferences s = c.getPreferences();
    // 使用数组容器解决变量未初始化即在回调中引用的编译报错
    final PluginView[] vArr = {null};

    PluginRootLayoutBuilder builder = i.buildVerticalLayout();
    
    builder.addTextView().text("背景图片来源:").bold()
           .addSpinner("mode").items(Arrays.asList("程序内置", "指定本地图片", "自定义API", "本地缓存库")).selection(s.getInt("bg_mode", 0))
           
           // --- 本地路径部分 ---
           .addTextView("h_local").text("本地图片路径:").bold().marginTopDp(10)
           .addEditText("local_path").text(s.getString("bg_local_path", "")).hint("请输入图片的绝对路径").singleLine(true)
           
           // --- API URL 部分 ---
           .addTextView("h_api").text("API URL:").bold().marginTopDp(10)
           .addEditText("api_url").text(s.getString("bg_api_url", "https://yingciyuan.cn/pe.php")).hint("请输入 API 请求地址").singleLine(true)
           
           // --- API 缓存控制部分 ---
           .addTextView("h_cache").text("API 自动缓存控制:").bold().marginTopDp(10)
           .addButton("cache").text("从当前 API 缓存 5 张图片到本地库").onClick(btn -> {
               // 通过 vArr[0] 安全引用已构建的视图
               if (vArr[0] != null) {
                   String currentApi = vArr[0].<PluginEditText>requireViewById("api_url").getText().toString().trim();
                   cacheFromApi(c, currentApi.isEmpty() ? "https://yingciyuan.cn/pe.php" : currentApi);
               }
           })

           // --- 透明度设置 (保留原样) ---
           .addTextView().text("透明度设置(值越大越不透明):").bold().marginTopDp(15)
           .addTextView().text("整体背景透明度 (0-255):").textSize(12)
           .addEditText("alpha").text(String.valueOf(s.getInt("bg_alpha", 0))).inputType(2)
           .addTextView().text("菜单列表透明度 (0-255):").textSize(12)
           .addEditText("l_alpha").text(String.valueOf(s.getInt("bg_list_alpha", 64))).inputType(2)
           .addTextView().text("对话框背景透明度 (50-255):").textSize(12)
           .addEditText("d_alpha").text(String.valueOf(s.getInt("bg_dialog_alpha", 230))).inputType(2)
           
           // --- 颜色定制 (保留原样字符串与逻辑) ---
           .addTextView().text("界面颜色定制 (Hex: #AARRGGBB):").bold().marginTopDp(15)
           .addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("返回图标颜色：")
                   .addEditText("c_icon").text(String.format("#%08X", s.getInt("color_icon", 0xFF1D1D1F))).hint("#FF1D1D1F")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("设置标题颜色：")
                   .addEditText("c_title").text(String.format("#%08X", s.getInt("color_title", 0xFF000000))).hint("#FF000000")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("菜单分类颜色：")
                   .addEditText("c_header").text(String.format("#%08X", s.getInt("color_header", 0xFF333333))).hint("#FF333333")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("菜单标题颜色：")
                   .addEditText("c_text").text(String.format("#%08X", s.getInt("color_text", 0xFF333333))).hint("#FF333333")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("菜单摘要颜色：")
                   .addEditText("c_summary").text(String.format("#%08X", s.getInt("color_summary", 0xFF444444))).hint("#FF444444")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("滑块开启颜色：")
                   .addEditText("c_sw_on").text(String.format("#%08X", s.getInt("color_sw_thumb_on", 0xFF2196F3))).hint("#FF2196F3")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("滑轨开启颜色：")
                   .addEditText("c_sw_r_on").text(String.format("#%08X", s.getInt("color_sw_track_on", 0x662196F3))).hint("#662196F3")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("滑块关闭颜色：")
                   .addEditText("c_sw_off").text(String.format("#%08X", s.getInt("color_sw_thumb_off", 0xFFBBBBBB))).hint("#FFBBBBBB")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("滑轨关闭颜色：")
                   .addEditText("c_sw_r_off").text(String.format("#%08X", s.getInt("color_sw_track_off", 0x4D000000))).hint("#4D000000")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("积极按钮颜色：")
                   .addEditText("c_btn_pos").text(String.format("#%08X", s.getInt("color_btn_pos", 0xFF2196F3))).hint("#FF2196F3")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("消极按钮颜色：")
                   .addEditText("c_btn_neg").text(String.format("#%08X", s.getInt("color_btn_neg", 0xFF888888))).hint("#FF888888")
           ).addHorizontalLayout().children(subBuilder -> subBuilder
                   .addTextView().text("中性按钮颜色：")
                   .addEditText("c_btn_neu").text(String.format("#%08X", s.getInt("color_btn_neu", 0xFFCCCCCC))).hint("#FFCCCCCC")
           );

        // --- 流光特效设置 ---

    // 完成构建并赋值给数组
    vArr[0] = builder.build();
    PluginView v = vArr[0];

        // --- 动态显隐逻辑 ---
        PluginSpinner modeSpinner = v.requireViewById("mode");

        
        // --- 动态显隐逻辑 ---
    File cacheDir = new File(c.getFilesDir(), "bg_cache");
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();  // 确保目录存在
        }
        File next = new File(cacheDir, "next.jpg");
    Runnable updateVisibility = () -> {
        int mode = modeSpinner.getSelection();
        // 模式：0内置, 1本地, 2API, 3本地库
        v.requireViewById("h_local").setVisibility(mode == 1 ? View.VISIBLE : View.GONE);
        v.requireViewById("local_path").setVisibility(mode == 1 ? View.VISIBLE : View.GONE);
        v.requireViewById("h_api").setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
        v.requireViewById("api_url").setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
        v.requireViewById("h_cache").setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
        v.requireViewById("cache").setVisibility(mode == 2 ? View.VISIBLE : View.GONE);

    if (mode == 2) {
        // 从输入框实时获取 URL（去掉首尾空格）
        String url = vArr[0].<PluginEditText>requireViewById("api_url").getText().toString().trim();

        // 简单校验 URL 不为空（可根据需要加强校验）
        if (!url.isEmpty() && !(next.exists() && next.length() > 0)) {
            new Thread(() -> {
                try {
                    downloadFile(url, next);  // 假设你的 downloadFile 第二个参数是文件路径字符串
                    // 下载成功后可刷新 UI（如更新图片预览）
                    // 示例：在主线程更新
                    // ((Activity) c).runOnUiThread(() -> { /* 更新界面 */ });
                } catch (Exception e) {
                    new O.L(c).e("IO", "Download failed: " + url, e);
                    next.delete();
                    // 可选：主线程提示用户下载失败
                    // ((Activity) c).runOnUiThread(() -> Toast.makeText(c, "图片下载失败", Toast.LENGTH_SHORT).show());
                }
            }).start();
        }
    }

    };
    modeSpinner.setOnItemSelectedListener((sp, pos) -> updateVisibility.run());
    updateVisibility.run();

    new LiquidDialog(i).setTitle("界面视觉深度定制").setView(v).setPositiveButton("保存并应用", (d, w) -> {
        try {
            SharedPreferences.Editor e = s.edit();
            int selectedMode = modeSpinner.getSelection();
            e.putInt("bg_mode", selectedMode);
            
            // 拆分保存
            String localP = v.<PluginEditText>requireViewById("local_path").getText().toString().trim();
            String apiU = v.<PluginEditText>requireViewById("api_url").getText().toString().trim();
            e.putString("bg_local_path", localP);
            e.putString("bg_api_url", apiU);
            

            // 验证并保存透明度
            int alpha = Integer.parseInt(v.<PluginEditText>requireViewById("alpha").getText().toString());
            if (alpha < 0 || alpha > 255) throw new IllegalArgumentException("整体透明度必须在 0-255 之间");
            e.putInt("bg_alpha", alpha);

            int lAlpha = Integer.parseInt(v.<PluginEditText>requireViewById("l_alpha").getText().toString());
            if (lAlpha < 0 || lAlpha > 255) throw new IllegalArgumentException("菜单列表透明度必须在 0-255 之间");
            e.putInt("bg_list_alpha", lAlpha);

            int dAlpha = Integer.parseInt(v.<PluginEditText>requireViewById("d_alpha").getText().toString());
            if (dAlpha < 0 || dAlpha > 255) throw new IllegalArgumentException("对话框透明度必须在 0-255 之间");
            e.putInt("bg_dialog_alpha", dAlpha);
            
            // 颜色部分 (增加校验)
            String[] colorKeys = {"color_icon", "color_title", "color_header", "color_text", "color_summary", "color_sw_thumb_on", "color_sw_track_on", "color_sw_thumb_off", "color_sw_track_off", "color_btn_pos", "color_btn_neg", "color_btn_neu"};
            String[] colorIds = {"c_icon", "c_title", "c_header", "c_text", "c_summary", "c_sw_on", "c_sw_r_on", "c_sw_off", "c_sw_r_off", "c_btn_pos", "c_btn_neg", "c_btn_neu"};
            
            for(int k=0; k<colorKeys.length; k++) {
                String hex = v.<PluginEditText>requireViewById(colorIds[k]).getText().toString().trim();
                if(!hex.matches("^#[0-9A-Fa-f]{8}$")) throw new IllegalArgumentException("颜色格式错误 (" + colorIds[k] + "): 必须为 #AARRGGBB");
                e.putInt(colorKeys[k], Color.parseColor(hex));
            }
            
            // 保存特效设置
            
            e.apply();
            i.showToast("设置已保存，请重新进入页面");
        } catch (Exception ex) { 
            i.showToast("输入格式错误: " + ex.getMessage()); 
            new O.L(c).e("UI", "Settings save failed", ex);
        }
    }).setNegativeButton("取消", null).show();
}



    private void cacheFromApi(PluginContext ctx, String apiUrl) {
        Handler mainHandler = new Handler(Looper.getMainLooper());
        
        new Thread(() -> {
            try {
                // 1. 获取 Context
                Context appContext = (ctx instanceof Context) ? (Context) ctx : getGlobalContext();
                if (appContext == null) return;

                final Context finalContext = appContext;

                // 2. 准备下载
                DownloadManager manager = (DownloadManager) finalContext.getSystemService(Context.DOWNLOAD_SERVICE);

                mainHandler.post(() -> Toast.makeText(finalContext, "开始后台缓存任务...", Toast.LENGTH_SHORT).show());

                for (int i = 0; i < 5; i++) {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apiUrl));
                    
                    // 伪装浏览器 Header (对抗 Cloudflare 418)
                    request.addRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
                    request.addRequestHeader("Referer", "https://lie.moe/");
                    
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setTitle("AI背景缓存 " + (i + 1));
                    
                    String fileName = "BG_" + System.currentTimeMillis() + "_" + i + ".jpg";
                    request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "MT_AI_BG/" + fileName);

                    manager.enqueue(request);
                    Thread.sleep(300); // 间隔请求，防止被封
                }

                mainHandler.post(() -> Toast.makeText(finalContext, "5个任务已加入通知栏，请查看下载进度", Toast.LENGTH_LONG).show());

            } catch (Exception e) {
                new O.L(ctx).e("UI", "Cache failed", e);
                // 发生异常时，确保 Toast 的 Context 不为 null
                final String err = e.toString();
                mainHandler.post(() -> {
                    // 这里的逻辑：如果异常了，我们尽量找一个不为 null 的 Context 弹窗
                    try {
                        Class<?> atClass = Class.forName("android.app.ActivityThread");
                        Context c = (Context) atClass.getMethod("currentApplication").invoke(null);
                        if (c != null) Toast.makeText(c, "严重异常: " + err, Toast.LENGTH_LONG).show();
                    } catch (Exception ignored) {
                        new O.L(ctx).e("UI", "Toast context lookup failed", ignored);
                    }
                });
            }
        }).start();
    }

    private Activity findActivity() {
        try {
            Class<?> threadClass = Class.forName("android.app.ActivityThread");
            Object thread = threadClass.getMethod("currentActivityThread").invoke(null);
            Field field = threadClass.getDeclaredField("mActivities");
            field.setAccessible(true);
            Map<?, ?> activities = (Map<?, ?>) field.get(thread);
            for (Object record : activities.values()) {
                Field pausedField = record.getClass().getDeclaredField("paused");
                pausedField.setAccessible(true);
                if (!pausedField.getBoolean(record)) {
                    Field actField = record.getClass().getDeclaredField("activity");
                    actField.setAccessible(true);
                    return (Activity) actField.get(record);
                }
            }
        } catch (Exception e) {
             if (c != null) new O.L(c).e("UI", "Activity find failed", e);
        }
        return null;
    }

    class AspectDrawable extends Drawable {
        private Bitmap mBitmap; private Paint mPaint; private int mBgColor;
        AspectDrawable(Bitmap bitmap, int bgColor, int alpha) {
            this.mBitmap = bitmap; this.mBgColor = bgColor;
            this.mPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            this.mPaint.setAlpha(alpha);
        }
        @Override
        public void draw(@NonNull Canvas canvas) {
            Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) return;
            canvas.drawColor(mBgColor);
            float vW = b.width(), vH = b.height(), bW = mBitmap.getWidth(), bH = mBitmap.getHeight(), scale, dx = 0, dy = 0;
            if (bW * vH > vW * bH) { scale = vH / bH; dx = (vW - bW * scale) * 0.5f; }
            else { scale = vW / bW; dy = (vH - bH * scale) * 0.5f; }
            Matrix m = new Matrix(); m.setScale(scale, scale); m.postTranslate(dx, dy);
            canvas.drawBitmap(mBitmap, m, mPaint);
        }
        @Override public void setAlpha(int a) { mPaint.setAlpha(a); }
        @Override public void setColorFilter(ColorFilter cf) { mPaint.setColorFilter(cf); }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    // --- 以下代码保持原样 (S, u, g, K, U, P, p, u, a, C 方法) ---
    // 修改 S 方法以支持 Definition 更新
    void S(PluginUI i, SharedPreferences p, Object t, PluginPreference.Text def) {
        String u = O.gUrl(c); if (u.isEmpty()) u = P.get(0).u;
        String m = p.getString(O._0, ""), n = g(u);
        java.util.List<String> l = new ArrayList<>();
        int x = 0;
        for (int k = 0; k < P.size(); k++) { l.add(P.get(k).n); if (P.get(k).n.equals(n)) x = k; }
        final int[] X = {x}; final int[] Y = {0};
        PluginView v = i.buildVerticalLayout()
                .addTextView().text("服务提供商:").bold().paddingBottomDp(5)
                .addSpinner("s").items(l).selection(x)
                .addEditText("u").text(u).hint("输入 API URL").singleLine(true).marginTopDp(5)
                .addTextView().text("模型选择:").bold().paddingTopDp(15).paddingBottomDp(5)
                .addSpinner("m")
                .addEditText("e").text(m).hint("输入模型名称").singleLine(true).marginTopDp(5).build();
        PluginSpinner S = v.requireViewById("s"), M = v.requireViewById("m");
        PluginEditText U = v.requireViewById("u"), E = v.requireViewById("e");
        Runnable R = () -> {
            int k = X[0]; p z = P.get(k); boolean isCustom = "自定义提供商".equals(z.n);
            if (isCustom) { U.setVisible(); if (U.getText().toString().isEmpty()) U.setText("https://"); }
            else { U.setGone(); U.setText(z.u); }
            java.util.List<String> ml = new ArrayList<>();
            if (!isCustom) Collections.addAll(ml, z.m);
            ml.add("自定义...");
            M.setItems(ml);
            String tm = isCustom ? m : p.getString(O._0, "");
            int mi = ml.indexOf(tm); if (mi == -1) mi = ml.size() - 1;
            M.setSelection(mi); Y[0] = mi;
            if (isCustom || mi == ml.size() - 1) { E.setVisible(); if (!isCustom && E.getText().toString().equals(tm)) E.setText(""); }
            else E.setGone();
        };
        S.setOnItemSelectedListener((sp, pos) -> { X[0] = pos; R.run(); E.setText(""); });
        M.setOnItemSelectedListener((sp, pos) -> {
            Y[0] = pos; String sel = (String) sp.getItem(pos);
            if ("自定义...".equals(sel)) { E.setVisible(); E.requestFocus(); }
            else { E.setGone(); E.setText(sel); }
        });
        R.run();
        new LiquidDialog(i).setTitle("配置服务").setView(v).setPositiveButton("保存", (d, w) -> {
            String fu = U.getText().toString().trim(), fm = E.getText().toString().trim(), fn = P.get(X[0]).n;
            if (fu.isEmpty() || fm.isEmpty()) { i.showToast("URL 或 模型不能为空"); return; }
            O.sUrl(c, fu); p.edit().putString(O._0, fm).apply();
            String newSummary = fn + " / " + fm;
            u(t, newSummary); 
            if (def != null) def.summary(newSummary); // 更新 Definition 以持久化
            i.showToast("已保存配置");
            if (p.getBoolean("api_auto_kv", false)) {
                String key = O.g(c); if (!key.isEmpty()) {
                    String r = "自动添加 " + new java.text.SimpleDateFormat("MM-dd HH:mm").format(new Date());
                    o.sk(i, -1, fn.equals("自定义提供商") ? fu : fn, key, r, true);
                }
            }
        }).setNegativeButton("取消", null).show();
    }

    // 保留旧签名的 S 方法以防万一
    void S(PluginUI i, SharedPreferences p, Object t) {
        S(i, p, t, null);
    }

    void u(Object o, String t) {
        try { Method m = o.getClass().getMethod("setSummary", CharSequence.class); m.setAccessible(true); m.invoke(o, t); }
        catch (Exception e) { try { Method m = o.getClass().getMethod("setSummary", String.class); m.setAccessible(true); m.invoke(o, t); } catch (Exception x) {
             new O.L(c).e("UI", "Summary update failed", x);
        } }
    }

    String g(String u) { for (p p : P) if (p.u.equals(u)) return p.n; return "自定义提供商"; }

    interface I { void u(String s); }

    void K(PluginUI i, I u) {
        String k = O.g(c);
        boolean isDg = O.isDowngraded(c);
        PluginView v = i.buildVerticalLayout()
                .addTextView().text(isDg ? "⚠️当前设备不支持硬件级加密，密钥将使用软件加密存储。" : "API Key 将加密存储在本地。").textSize(12).textColor(isDg ? 0xFFFF0000 : 0xFF888888).paddingBottomDp(5)
                .addEditText("k").text(k).hint("请输入 API 密钥").inputType(129).singleLine(true).build();
        new LiquidDialog(i).setTitle("设置 API 密钥").setView(v).setPositiveButton("保存", (d, w) -> {
            String K_val = v.<PluginEditText>requireViewById("k").getText().toString().trim();
            if (!K_val.isEmpty()) {
                O.s(c, K_val); 
                boolean dg = O.isDowngraded(c);
                i.showToast("密钥已保存" + (dg ? " (⚠️降级模式)" : "")); 
                if (u != null) u.u(dg ? "已存储 (⚠️安全降级模式)" : "已加密存储 (点击修改)");
                if (c.getPreferences().getBoolean("api_auto_kv", false)) {
                    String ur = O.gUrl(c); String n = g(ur);
                    String r = "自动添加 " + new java.text.SimpleDateFormat("MM-dd HH:mm").format(new Date());
                    o.sk(i, -1, n.equals("自定义提供商") ? ur : n, K_val, r, true);
                }
            } else { O.s(c, ""); if (u != null) u.u("未设置 (点击设置)"); }
        }).setNegativeButton("取消", null).show();
    }

    void U(PluginUI i, String u) {
        for (p p : P) if (p.u.equals(u)) { if (p.k != null && !p.k.isEmpty()) c.openBrowser(p.k); else i.showToast("该提供商无预设注册链接"); return; }
        i.showToast("自定义提供商请自行获取 API Key");
    }

    void P(PluginUI i) {
        String j = c.getPreferences().getString(O.i, "{}");
        double t = 1.0, tp = 1.0; int mt = 4096; String ex = "";
        try {
            JSONObject obj = new JSONObject(j); t = obj.optDouble("temperature", 1.0); tp = obj.optDouble("top_p", 1.0); mt = obj.optInt("max_tokens", 4096);
            obj.remove("temperature"); obj.remove("top_p"); obj.remove("max_tokens"); if (obj.length() > 0) ex = obj.toString();
        } catch (Exception e) {
             new O.L(c).e("UI", "Params JSON parse failed", e);
        }
        PluginRootLayoutBuilder b = i.buildVerticalLayout();
        b.addTextView().text("Temperature (0.0 - 2.0):"); b.addEditText("t").text(String.valueOf(t)).inputType(8194);
        b.addTextView().text("Top P (0.0 - 1.0):"); b.addEditText("p").text(String.valueOf(tp)).inputType(8194);
        b.addTextView().text("Max Tokens:"); b.addEditText("m").text(String.valueOf(mt)).inputType(2);
        b.addTextView().text("自定义 JSON 参数:"); b.addEditText("e").hint("例如 {\"thinking\":{\"type\":\"enabled\"}}").text(ex).singleLine(false);
        PluginView v = b.build();
        new LiquidDialog(i).setTitle("参数设置").setView(v).setPositiveButton("保存", (d, w) -> {
            try {
                JSONObject obj = new JSONObject();
                String T = v.<PluginEditText>requireViewById("t").getText().toString(), TP = v.<PluginEditText>requireViewById("p").getText().toString(), MT = v.<PluginEditText>requireViewById("m").getText().toString(), EX = v.<PluginEditText>requireViewById("e").getText().toString();
                if (!T.isEmpty()) obj.put("temperature", Double.parseDouble(T));
                if (!TP.isEmpty()) obj.put("top_p", Double.parseDouble(TP));
                if (!MT.isEmpty()) obj.put("max_tokens", Integer.parseInt(MT));
                if (!EX.isEmpty()) { JSONObject x = new JSONObject(EX); Iterator<String> keys = x.keys(); while (keys.hasNext()) { String K_key = keys.next(); obj.put(K_key, x.get(K_key)); } }
                c.getPreferences().edit().putString(O.i, obj.toString()).apply(); i.showToast("参数已保存");
            } catch (Exception e) { 
                i.showToast("格式错误: " + e.getMessage()); 
                new O.L(c).e("UI", "Params save failed", e);
            }
        }).setNegativeButton("取消", null).show();
    }

    void p(PluginUI i) {
        String pStr = c.getPreferences().getString(O.l, "请分析以下文本内容：\n\n{text}");
        PluginView v = i.buildVerticalLayout().addTextView().text("提示: 使用 {text} 代表选中的文本。").textSize(12).textColor(0xFF888888).addEditText("p").text(pStr).singleLine(false).heightDp(150).build();
        new LiquidDialog(i).setTitle("编辑分析提示词").setView(v).setPositiveButton("保存", (d, w) -> {
            String P_val = v.<PluginEditText>requireViewById("p").getText().toString();
            if (P_val.isEmpty()) P_val = "请分析以下文本内容：\n\n{text}";
            c.getPreferences().edit().putString(O.l, P_val).apply(); i.showToast("保存成功");
        }).setNegativeButton("取消", null).show();
    }

    void u(PluginUI i) {
        PluginView v = i.buildVerticalLayout()
                .addTextView().text("使用指南").bold().textSize(18).textColor(0xFF8B4513).paddingBottomDp(10)
                .addTextView().text("1. 基础配置").bold().marginTopDp(5)
                .addTextView().text("   - 首次使用请点击“服务提供商”选择 AI 服务（推荐 SiliconFlow 或 DeepSeek）。\n   - 点击“获取 API Key”跳转官网注册获取密钥。\n   - 点击“API 密钥”输入密钥，插件会自动加密存储。\n   - 若需使用自定义服务，请选择“自定义提供商”并填入完整 API URL（如 https://api.example.com/v1/chat/completions）。").textSize(13)
                .addTextView().text("2. 进阶设置").bold().marginTopDp(5)
                .addTextView().text("   - 模型参数：可调整 Temperature (随机性) 和 Max Tokens (回复长度)。支持自定义 JSON 参数以启用特定模型功能（如思维链）。\n   - 提示词：点击“分析提示词”可自定义 AI 的系统指令，{text} 为选中文本占位符。\n   - 界面定制：支持自定义背景图片（本地/API）、调整透明度及各部分字体颜色，打造专属液态玻璃 UI。").textSize(13)
                .addTextView().text("3. 功能使用").bold().marginTopDp(5)
                .addTextView().text("   - 在文本编辑器中选中任意文本 -> 点击底部工具栏或悬浮球 -> 选择“AI文本分析”。\n   - 在弹出的对话框中，您可以直接查看分析结果，或继续输入问题进行追问。\n   - 支持历史对话记忆，开启“显示历史列表”后可随时接续之前的会话。\n   - 长按对话内容可复制，点击标题栏可导出对话记录。").textSize(13)
                .addTextView().text("4. 密钥保管箱").bold().marginTopDp(5)
                .addTextView().text("   - 支持保存多组 API Key，方便在不同服务商之间快速切换。\n   - 开启“自动保存”后，新输入的 Key 会自动存入保管箱。\n   - 支持设置独立密码保护密钥安全。").textSize(13)
                .addTextView().text("5. 核心架构").bold().marginTopDp(5)
                .addTextView().text("   - 对话UI管理: 本插件核心 UI 引擎，采用 WebView 混合渲染技术，内置高性能 Markdown 解析器模块。通过 JS Bridge 实现流式传输，支持 DeepSeek R1 等模型的思考过程 (Chain of Thought) 实时展示。独创的“对话树”可视化结构，允许用户在多次重新生成的内容间自由切换 (Branching)。\n   - 对话历史记录管理: 采用 SQLite 关系型数据库存储，并未简单的线性存储，而是完整记录了对话的树状拓扑结构。这不仅保证了多轮对话上下文的严谨性，还实现了对“撤回”、“重新生成”等操作的完美状态保存。支持导出为 HTML 格式，方便二次编辑与分享。").textSize(13)
                .addTextView().text("6. 常见问题与故障排除").bold().marginTopDp(5)
                .addTextView().text("   - Q: 提示“密钥无效”？\n     A: 请检查 Key 是否正确，或服务商额度是否耗尽。\n   - Q: 界面卡顿或背景加载失败？\n     A: 请检查网络连接，或尝试关闭自定义背景功能。\n   - Q: 背景图片无法加载？\n     A: 插件已内置回退机制，若API或本地图片失效，将自动使用默认背景。请检查网络或图片路径。\n   - Q: 自定义API背景更新不及时？\n     A: 为保证速度，插件会预缓存下一张图片。若需立即更新，请重新进入设置页。\n   - Q: 兼容性问题？\n     A: 使用首页的“兼容性智能检测”功能获取诊断报告。").textSize(13)
                .addTextView().text("7. 安全声明").bold().marginTopDp(5).textColor(0xFFCC0000)
                .addTextView().text("   - 本插件所有网络请求均直连第三方 API，不经过任何中转服务器。\n   - API Key 采用 Android KeyStore 系统级加密存储，极大降低泄露风险。\n   - 请勿在不可信的设备上使用本插件。").textSize(12).textColor(0xFF888888)
                .build();
        new LiquidDialog(i).setTitle("全方位使用指南").setView(v).setPositiveButton("已完全了解", null).show();
    }

    void a(PluginUI i) {
        PluginView v = i.buildVerticalLayout()
                .addTextView().text("AI 文本分析助手 v1.0").bold().textSize(18).paddingBottomDp(10)
                .addTextView().text("开源与声明：").bold()
                .addTextView().text("本插件基于bin.mt.plugin api-3.0.0-alpha6构建，仅在MT管理器2.19.4进行测试，无法保证在其他版本正常运行。插件兼容性取决于 MT 管理器版本更新，如出现异常请及时反馈。本插件作为MT管理器扩展功能，不收集任何用户数据。所有API调用均直接发往用户配置的第三方服务商。用户需自行承担使用第三方 API 服务所产生的费用及风险。本插件不保证API服务的可用性及内容准确性。AI 生成的内容仅供参考，可能存在事实错误、偏见或不适当内容，请用户自行判断并承担使用责任。本插件不不对 AI 输出内容的准确性、完整性或合法性负责。请遵守相关法律法规使用。\n\n如需源码请联系作者获取。\n").textSize(13).paddingBottomDp(10)
                .addTextView().text("鸣谢：").bold().addTextView().text("谨向 MT 管理器开发者 @Bin 及论坛众多插件开发者致以最崇高的敬意。本插件的开发是在借鉴论坛诸多优秀示例的基础上，并结合 Gemini3 pro 等 AI 工具的辅助，才得以基本实现设计目标。").textSize(13).paddingBottomDp(10)
                .addTextView().text("免责声明").bold().marginTopDp(10)
                .addTextView().text("本插件仅供学习交流使用，用户需自行承担使用第三方 API 服务所产生的费用及风险。AI 生成内容仅供参考。").textSize(12).textColor(0xFF888888)
                .addTextView().text("联系作者").bold().marginTopDp(10)
                .addTextView().text("QQ: 921992797").textColor(0xFF336699).onClick(p -> c.openBrowser("https://ti.qq.com/open_qq/index2.html?url=mqqapi://userprofile/friend_profile_card?src_type=web&version=1.0&source=2&uin=921992797"))
                .addTextView().text("论坛主页 (@sjlz)").textColor(0xFF336699).onClick(p -> c.openBrowser("https://bbs.binmt.cc/home.php?mod=space&uid=153150&do=profile"))
                .build();
        new LiquidDialog(i).setTitle("关于插件").setView(v).setPositiveButton("这就去玩", null).show();
    }

    void C(PluginUI i) {
        if (O.g(c).isEmpty()) { i.showToast("请先配置 API Key 后再使用智能检测"); return; }
        i.showToast("正在启动深度兼容性扫描...");
        
        new Thread(() -> {
            try {
                StringBuilder info = new StringBuilder();
                info.append("=== Device Diagnosis Report ===\n");
                info.append("Time: ").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())).append("\n");
                
                // 1. Basic Hardware
                info.append("\n[Hardware]\n");
                info.append("Model: ").append(Build.MODEL).append("\n");
                info.append("Manufacturer: ").append(Build.MANUFACTURER).append("\n");
                info.append("Brand: ").append(Build.BRAND).append("\n");
                info.append("Board: ").append(Build.BOARD).append("\n");
                info.append("Device: ").append(Build.DEVICE).append("\n");
                info.append("Hardware: ").append(Build.HARDWARE).append("\n");
                info.append("Product: ").append(Build.PRODUCT).append("\n");
                try { 
                    if (Build.VERSION.SDK_INT >= 26) {
                        // info.append("Serial: ").append(Build.getSerial()).append("\n"); // Requires permission
                    }
                } catch (Exception e) { new O.L(c).e("Diag", "Serial check failed", e); }

                // 2. CPU / ABI
                info.append("\n[CPU & ABI]\n");
                info.append("Primary ABI: ").append(Build.CPU_ABI).append("\n");
                info.append("Secondary ABI: ").append(Build.CPU_ABI2).append("\n");
                info.append("Supported ABIs: ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append("\n");
                
                int cores = Runtime.getRuntime().availableProcessors();
                info.append("Cores: ").append(cores).append("\n");
                
                try {
                    BufferedReader br = new BufferedReader(new FileReader("/proc/cpuinfo"));
                    String line;
                    while ((line = br.readLine()) != null) {
                         if (line.startsWith("Hardware")) info.append("CPU Hardware: ").append(line.split(":")[1].trim()).append("\n");
                         if (line.startsWith("Processor")) info.append("Processor: ").append(line.split(":")[1].trim()).append("\n");
                    }
                    br.close();
                } catch (Exception e) { new O.L(c).e("Diag", "CPU info read failed", e); }
                
                // Iterate all cores for freq
                for (int k = 0; k < cores; k++) {
                    try {
                        String freq = readFileOneLine("/sys/devices/system/cpu/cpu" + k + "/cpufreq/scaling_cur_freq");
                        if (!freq.isEmpty()) info.append("Core ").append(k).append(" Freq: ").append(Integer.parseInt(freq) / 1000).append(" MHz\n");
                    } catch (Exception e) { new O.L(c).e("Diag", "Core freq read failed", e); }
                }
                 try {
                     String gov = readFileOneLine("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
                     if (!gov.isEmpty()) info.append("Governor (Core0): ").append(gov).append("\n");
                } catch (Exception e) { new O.L(c).e("Diag", "Governor read failed", e); }

                try {
                     // Thermal
                     File thermalDir = new File("/sys/class/thermal");
                     if (thermalDir.exists()) {
                         File[] zones = thermalDir.listFiles((d, n) -> n.startsWith("thermal_zone"));
                         if (zones != null) {
                             for (File z : zones) {
                                 String type = readFileOneLine(new File(z, "type").getAbsolutePath());
                                 String temp = readFileOneLine(new File(z, "temp").getAbsolutePath());
                                 if (!type.isEmpty() && !temp.isEmpty()) {
                                     try {
                                         float t = Integer.parseInt(temp) / 1000.0f;
                                         if (t > 0 && t < 100) info.append("Thermal ").append(type).append(": ").append(String.format("%.1f", t)).append("°C\n");
                                     } catch (Exception e) { new O.L(c).e("Diag", "Thermal parse failed", e); }
                                 }
                             }
                         }
                     }
                } catch (Exception e) { new O.L(c).e("Diag", "Thermal read failed", e); }
                
                // 3. System
                info.append("\n[System]\n");
                info.append("Android Ver: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
                info.append("Security Patch: ").append(Build.VERSION.SECURITY_PATCH).append("\n");
                info.append("Fingerprint: ").append(Build.FINGERPRINT).append("\n");
                try { info.append("Kernel: ").append(System.getProperty("os.name")).append(" ").append(System.getProperty("os.version")).append(" ").append(System.getProperty("os.arch")).append("\n"); } catch (Exception e) { new O.L(c).e("Diag", "Kernel info failed", e); }
                try { info.append("Full Kernel: ").append(readFileOneLine("/proc/version")).append("\n"); } catch (Exception e) { new O.L(c).e("Diag", "Full kernel read failed", e); }

                // 4. Screen & Graphics
                info.append("\n[Display & Graphics]\n");
                Context ctx = getGlobalContext();
                if (ctx != null) {
                    android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
                    info.append("Resolution: ").append(dm.widthPixels).append("x").append(dm.heightPixels).append("\n");
                    info.append("Density: ").append(dm.densityDpi).append(" dpi\n");
                    
                    WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                    if (wm != null) {
                        Display d = wm.getDefaultDisplay();
                        info.append("Refresh Rate: ").append(d.getRefreshRate()).append(" Hz\n");
                        if (Build.VERSION.SDK_INT >= 24) {
                            Display.HdrCapabilities hdr = d.getHdrCapabilities();
                             if (hdr != null && hdr.getSupportedHdrTypes().length > 0) {
                                 info.append("HDR Support: Yes (Types: ").append(Arrays.toString(hdr.getSupportedHdrTypes())).append(")\n");
                             } else {
                                 info.append("HDR Support: No\n");
                             }
                        }
                    }
                }
                
                // 5. Camera
                info.append("\n[Camera]\n");
                if (ctx != null && Build.VERSION.SDK_INT >= 21) {
                    try {
                        android.hardware.camera2.CameraManager cm = (android.hardware.camera2.CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
                        String[] ids = cm.getCameraIdList();
                        info.append("Cameras Found: ").append(ids.length).append("\n");
                        for (String id : ids) {
                            android.hardware.camera2.CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                            Integer facing = cc.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
                            String faceStr = (facing != null && facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT) ? "Front" : "Back";
                            android.util.Size[] sizes = cc.get(android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(android.graphics.ImageFormat.JPEG);
                            int mp = 0;
                            if (sizes != null && sizes.length > 0) {
                                mp = (sizes[0].getWidth() * sizes[0].getHeight()) / 1000000;
                            }
                            info.append("Cam ").append(id).append(" (").append(faceStr).append("): ").append(mp).append(" MP\n");
                        }
                    } catch (Exception e) {
                        info.append("Camera check failed: ").append(e.getMessage()).append("\n");
                        new O.L(c).e("Diag", "Camera check failed", e);
                    }
                }

                // 6. Network
                info.append("\n[Network]\n");
                if (ctx != null) {
                    try {
                         android.net.ConnectivityManager cm = (android.net.ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
                         if (Build.VERSION.SDK_INT >= 23) {
                             android.net.Network net = cm.getActiveNetwork();
                             if (net != null) {
                                 android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(net);
                                 if (nc != null) {
                                     info.append("Transport: ");
                                     if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) info.append("WiFi ");
                                     if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)) info.append("Cellular ");
                                     info.append("\n");
                                     info.append("Downstream: ").append(nc.getLinkDownstreamBandwidthKbps() / 1000).append(" Mbps\n");
                                 }
                             }
                         }
                         
                         android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                         if (wm != null && wm.isWifiEnabled()) {
                             android.net.wifi.WifiInfo wi = wm.getConnectionInfo();
                             if (wi != null) {
                                 info.append("WiFi SSID: ").append(wi.getSSID()).append("\n");
                                 info.append("WiFi Freq: ").append(wi.getFrequency()).append(" MHz\n");
                                 info.append("WiFi Speed: ").append(wi.getLinkSpeed()).append(" Mbps\n");
                             }
                         }
                         
                         // IP Address
                         try {
                             Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
                             while (en.hasMoreElements()) {
                                 NetworkInterface intf = en.nextElement();
                                 Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses();
                                 while (enumIpAddr.hasMoreElements()) {
                                     InetAddress inetAddress = enumIpAddr.nextElement();
                                     if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                         info.append("IP: ").append(inetAddress.getHostAddress()).append("\n");
                                     }
                                 }
                             }
                         } catch (Exception e) { new O.L(c).e("Diag", "IP check failed", e); }
                    } catch (Exception e) { info.append("Network check failed: ").append(e.getMessage()).append("\n"); new O.L(c).e("Diag", "Network info failed", e); }
                }

                // 7. Battery & Power
                info.append("\n[Battery & Power]\n");
                if (ctx != null) {
                     Intent batteryStatus = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                     if (batteryStatus != null) {
                            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                            int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
                            int temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                            int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                            
                            info.append("Level: ").append(level * 100 / (float)scale).append("%\n");
                            info.append("Temp: ").append(temp / 10.0).append(" °C\n");
                            info.append("Voltage: ").append(voltage).append(" mV\n");
                            
                            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
                            if (Build.VERSION.SDK_INT >= 21) {
                                int currentNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                                int currentAvg = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE);
                                info.append("Current (Now): ").append(currentNow / 1000).append(" mA\n");
                                info.append("Current (Avg): ").append(currentAvg / 1000).append(" mA\n");
                                long chargeCounter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                                info.append("Charge Counter: ").append(chargeCounter / 1000).append(" mAh\n");
                                
                                // 尝试读取更多电池容量信息
                                try {
                                    File psDir = new File("/sys/class/power_supply");
                                    if (psDir.exists() && psDir.isDirectory()) {
                                        File[] files = psDir.listFiles();
                                        if (files != null) {
                                            long totalCap = 0;
                                            boolean foundAny = false;
                                            for (File f : files) {
                                                String name = f.getName().toLowerCase();
                                                if (name.contains("battery") || name.contains("bms")) {
                                                    String[] checkFiles = {"charge_full", "charge_full_design", "capacity_mah"};
                                                    for (String cf : checkFiles) {
                                                        File target = new File(f, cf);
                                                        if (target.exists()) {
                                                            String val = readFileOneLine(target.getAbsolutePath());
                                                            if (!val.isEmpty()) {
                                                                try {
                                                                    long v = Long.parseLong(val.trim());
                                                                    if (v > 0) {
                                                                        String unit = "uAh";
                                                                        long mah = v / 1000;
                                                                        if (cf.contains("mah")) {
                                                                            mah = v;
                                                                            unit = "mAh";
                                                                        } else if (v < 20000) { 
                                                                             // If value is small, it might be mAh already or just wrong, but assume mAh if < 20000 (20Ah)
                                                                             // Typical phone battery: 3000-6000 mAh. 
                                                                             // If uAh: 3000000 - 6000000.
                                                                             // So if > 100000, likely uAh.
                                                                             if (v < 100000) { mah = v; unit = "mAh (guessed)"; }
                                                                        }
                                                                        
                                                                        info.append("Capacity (").append(name).append("/").append(cf).append("): ").append(mah).append(" mAh\n");
                                                                        
                                                                        // Simple heuristic for dual cell total:
                                                                        // If we see "battery" and "battery2" with similar large values, we might want to sum them mentally, 
                                                                        // but here we just list them for the user to see.
                                                                        // Some kernels report total in "battery" and parts in "bms".
                                                                    }
                                                                } catch (Exception e) {
                                                                    new O.L(c).e("Diag", "Battery parse failed", e);
                                                                }
                                                                // If we found a valid value for this node, maybe skip other checks for this node to avoid duplicates? 
                                                                // But maybe charge_full and charge_full_design differ. Let's keep all.
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    new O.L(c).e("Diag", "Battery sysfs scan failed", e);
                                }
                            }
                     }
                }
                
                // 8. Memory & Storage
                info.append("\n[Memory & Storage]\n");
                if (ctx != null) {
                    android.app.ActivityManager am = (android.app.ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
                    android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                    am.getMemoryInfo(mi);
                    info.append("RAM Total: ").append(mi.totalMem / 1024 / 1024).append(" MB\n");
                    info.append("RAM Avail: ").append(mi.availMem / 1024 / 1024).append(" MB\n");
                    
                    File dataDir = Environment.getDataDirectory();
                    StatFs stat = new StatFs(dataDir.getPath());
                    info.append("Internal Total: ").append(stat.getTotalBytes() / 1024 / 1024 / 1024).append(" GB\n");
                    info.append("Internal Avail: ").append(stat.getAvailableBytes() / 1024 / 1024 / 1024).append(" GB\n");
                }
                
                // 9. Sensors
                if (ctx != null) {
                    SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
                    if (sm != null) {
                        info.append("\n[Sensors]\n");
                        java.util.List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
                        for(Sensor s : sensors) info.append(s.getName()).append(", ");
                        info.append("\n");
                    }
                }

                // 10. Environment Security
                info.append("\n[Environment Security]\n");
                String[] suPaths = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/usr/we-need-root/su", "/magisk/.core/bin/su"};
                boolean isRooted = false;
                for (String p : suPaths) {
                    if (new File(p).exists()) { isRooted = true; info.append("SU Binary: ").append(p).append("\n"); break; }
                }
                info.append("Root Access: ").append(isRooted ? "Yes" : "No (File Check)").append("\n");

                try (java.util.Scanner s = new java.util.Scanner(new File("/proc/mounts"))) {
                    boolean magiskFound = false;
                    while (s.hasNextLine()) {
                        String line = s.nextLine();
                        if (line.contains("magisk") || line.contains("core/mirror") || line.contains("com.topjohnwu.magisk")) { magiskFound = true; break; }
                    }
                    info.append("Magisk Mount: ").append(magiskFound).append("\n");
                } catch (Exception ignored) { new O.L(c).e("Diag", "Magisk check failed", ignored); }
                
                // System Properties Reflection
                info.append("\n[System Properties]\n");
                try {
                    Class<?> sysProp = Class.forName("android.os.SystemProperties");
                    Method get = sysProp.getMethod("get", String.class);
                    String[] keys = {
                        "ro.build.type", "ro.build.tags", "ro.build.flavor", "ro.build.display.id",
                        "ro.product.cpu.abi", "ro.board.platform", "ro.hardware", 
                        "ro.secure", "ro.debuggable", "ro.boot.flash.locked", "ro.boot.verifiedbootstate"
                    };
                    for (String k : keys) {
                         String v = (String) get.invoke(null, k);
                         if (v != null && !v.isEmpty()) info.append(k).append(": ").append(v).append("\n");
                    }
                } catch (Exception ignored) { new O.L(c).e("Diag", "SysProp check failed", ignored); }

                // Host App Info
                info.append("\n[Host App]\n");
                try {
                        if (ctx != null) {
                        android.content.pm.PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
                        info.append("Package: ").append(pi.packageName).append("\n");
                        info.append("Version Name: ").append(pi.versionName).append("\n");
                        info.append("Version Code: ").append(pi.versionCode).append("\n");
                        info.append("Installer: ").append(ctx.getPackageManager().getInstallerPackageName(ctx.getPackageName())).append("\n");
                        info.append("Last Update: ").append(new Date(pi.lastUpdateTime)).append("\n");
                    }
                } catch (Exception e) {
                    info.append("Host info failed: ").append(e.getMessage()).append("\n");
                    new O.L(c).e("Diag", "Host info failed", e);
                }

                // Plugin Self Info
                info.append("\n[Plugin Self]\n");
                info.append("Name: AI文本分析助手\n");
                info.append("Version: ").append(c.getPluginVersionName()).append(" (").append(c.getPluginVersionCode()).append(")\n");
                info.append("SDK Version: ").append(PluginContext.SDK_VERSION).append("\n");
                info.append("Min API: 26 (Android 8.0)\n");
                info.append("开发者仅在MT管理器2.19.4及安卓15版本测试正常运行，其他版本请用户自行测试，理论上支持所有安卓8.0及以上版本。\n");

                // Prompt Construction
                StringBuilder prompt = new StringBuilder();
                prompt.append("你是一位资深的 Android 系统与应用兼容性专家，同时也是 MT 管理器插件开发的权威顾问。请根据以下收集到的详细设备环境信息，对“AI文本分析助手”插件的运行兼容性进行全方位的深度诊断。\n\n");
                prompt.append("【环境信息快照】\n").append(info.toString()).append("\n\n");
                prompt.append("【插件技术规格】\n");
                prompt.append("- 核心架构：WebView 混合渲染 (Require API 26+)\n");
                prompt.append("- 关键依赖：OkHttp 4 (Require API 21+), SQLite, Android KeyStore\n");
                prompt.append("- 渲染特性：CSS3 Flexbox, Markdown Parsing, Hardware Acceleration\n");
                prompt.append("- 安全特性：AES-GCM Encryption, Reflection-based UI Injection\n\n");
                prompt.append("【诊断报告要求】\n");
                prompt.append("请以亲切、专业且易于理解的中文输出报告，包含以下部分：\n");
                prompt.append("1. **综合评分** (0-100分，并给出评级，如 S/A/B/C)\n");
                prompt.append("2. **环境亮点** (如高性能CPU、大内存、新版系统等)\n");
                prompt.append("3. **潜在风险** (重点分析 Root/Magisk 对 WebView 的影响、系统版本过旧、Webview 版本过低等风险)\n");
                prompt.append("4. **优化建议** (针对当前环境的个性化设置建议)\n");
                prompt.append("5. **最终结论** (是否推荐在此设备上长期使用)\n");
                prompt.append("6. **详细硬件分析** (针对存储、电池、传感器等新增检测项进行详细点评)\n");

                new Handler(Looper.getMainLooper()).post(() -> {
                    if (o != null) o.a(i, prompt.toString(), "", "Diagnose_" + System.currentTimeMillis());
                });

            } catch (Exception e) {
                new O.L(c).e("Diag", "Global diagnosis failed", e);
                new Handler(Looper.getMainLooper()).post(() -> i.showToast("诊断过程发生错误: " + e.getMessage()));
            }
        }).start();
    }
    
    private String readFileOneLine(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            return br.readLine();
        } catch (Exception e) {
            // Suppress log for /proc/version permission denied as it is expected on Android 11+
            // Also suppress permission denied for power_supply on some devices
            if (!path.equals("/proc/version") && !e.getMessage().contains("EACCES") && !e.getMessage().contains("Permission denied")) {
                new O.L(c).e("IO", "Read file failed: " + path, e);
            }
            return "";
        }
    }

    // Helper to get Context safely
    private Context getGlobalContext() {
        try {
            Class<?> atClass = Class.forName("android.app.ActivityThread");
            return (Context) atClass.getMethod("currentApplication").invoke(null);
        } catch (Exception e) {
            if (c != null) new O.L(c).e("UI", "Global context lookup failed", e);
            return null;
        }
    }
}
