package cail;

import androidx.annotation.NonNull;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import bin.mt.plugin.api.PluginContext;
import bin.mt.plugin.api.translation.BaseTranslationEngine;
import okhttp3.*;

/**
 * 翻译引擎接口实现类 I
 * 主要用于API配置的连通性测试与状态检查
 * 继承自 BaseTranslationEngine 以利用 MT 管理器的翻译接口进行测试结果展示
 * 保持了混淆的命名风格
 */
public class I extends BaseTranslationEngine {

    /**
     * 获取引擎名称
     * @return 显示在UI上的名称，此处用于标识为API配置测试工具
     */
    @NonNull 
    public String name() {
        return "API 配置联通性测试";
    }

    /**
     * 加载源语言列表
     * 这里借用语言代码作为触发指令，返回特定的配置检查标识
     * @return 支持的源语言代码列表
     */
    @NonNull 
    public List<String> loadSourceLanguages() {
        return Arrays.asList("config_check");
    }

    /**
     * 加载目标语言列表
     * 根据源语言返回对应的目标操作
     * @param s 源语言代码
     * @return 支持的目标语言代码列表
     */
    @NonNull 
    public List<String> loadTargetLanguages(String s) {
        return Arrays.asList("config_info");
    }

    /**
     * 获取语言的显示名称
     * 用于在翻译界面显示友好的名称
     * @param l 语言代码
     * @return 用户友好的显示名称
     */
    @NonNull 
    public String getLanguageDisplayName(String l) {
        return l.equals("config_check") ? "配置检查输入" : "配置信息与联通性";
    }

    /**
     * 执行翻译（实际执行API测试）
     * 通过模拟翻译过程来触发API连通性测试，并返回测试结果报告
     * @param t 待翻译文本（测试时通常忽略，或作为附加信息）
     * @param s 源语言（操作指令）
     * @param d 目标语言（操作指令）
     * @return 测试报告或错误信息
     */
    @NonNull 
    public String translate(String t, String s, String d) {
        // 仅处理特定目标语言 "config_info"
        if (!d.equals("config_info")) return "Error";
        
        PluginContext c = getContext();
        // 从 O 类获取解密后的 URL 和 Key
        String u = O.gUrl(c);
        String k = O.g(c);
        // 获取当前配置的模型名称
        String m = c.getPreferences().getString(O._0, "");

        // 设置默认值，防止空配置导致无法测试默认接口
        if (u.isEmpty()) u = "https://api.siliconflow.cn/v1/chat/completions";
        if (m.isEmpty()) m = "deepseek-ai/DeepSeek-V3";

        // 构建基础报告内容，显示当前配置状态
        StringBuilder r = new StringBuilder("【测试报告】\nURL: " + u + "\nModel: " + m + "\nKey: " + (k.isEmpty() ? "❌" : "✅") + "\n");
        
        // 如果未配置Key，直接返回报告
        if (k.isEmpty()) return r.toString();

        try {
            // 执行网络请求测试，验证API连通性
            String[] x = q(u, k, m);
            // 追加响应状态码和响应体
            r.append("Status: ").append(x[0]).append("\nResp: ").append(x[1]);
        } catch (Exception e) {
            // 捕获并记录异常信息
            r.append("Err: ").append(e.getMessage());
            new O.L(getContext()).e("API", "Test failed", e);
        }
        return r.toString();
    }

    /**
     * 发送测试请求
     * 构造一个最小化的API请求来验证接口是否可用
     * @param u API URL 地址
     * @param k API Key 密钥
     * @param m 模型名称
     * @return 包含状态码和响应体的字符串数组 [状态码, 响应体]
     * @throws Exception 网络或JSON异常
     */
    String[] q(String u, String k, String m) throws Exception {
        // 构建最小化测试请求体，仅请求极少Token以节省配额
        JSONObject j = new JSONObject().put("model", m).put("max_tokens", 5);
        JSONArray ms = new JSONArray();
        ms.put(new JSONObject().put("role", "user").put("content", "Hello"));
        j.put("messages", ms);

        // 构建 HTTP 请求，包含必要的鉴权头
        Request r = new Request.Builder()
                .url(u)
                .header("Authorization", "Bearer " + k)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(MediaType.parse("application/json"), j.toString()))
                .build();

        // 执行请求并获取响应
        try (Response p = O.getHttpClient().newCall(r).execute()) {
            String b = p.body() != null ? p.body().string() : "";
            return new String[]{String.valueOf(p.code()), b};
        }
    }
}
