package cail;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.os.*;
import android.util.Base64;
import org.json.*;
import bin.mt.plugin.api.*;
import bin.mt.plugin.api.editor.*;
import bin.mt.plugin.api.ui.*;
import bin.mt.plugin.api.ui.builder.PluginRootLayoutBuilder;
import bin.mt.plugin.api.ui.dialog.PluginDialog;
import bin.mt.plugin.api.util.*;
import okhttp3.*;
import okio.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.lang.ref.WeakReference;
import java.util.regex.*;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import java.lang.reflect.Method;
import android.webkit.*;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.lang.reflect.Field;
import android.text.TextUtils;
import android.view.ViewParent;
import android.graphics.drawable.Drawable;
import bin.mt.plugin.api.ui.PluginUI.Style;
import android.view.WindowManager;
import android.view.Window;
import android.view.Gravity;
import android.view.MotionEvent;
import android.graphics.Typeface;
import android.graphics.PixelFormat;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.animation.ValueAnimator;

/**
 * 核心逻辑类 O
 * 包含对话管理、网络请求、UI展示、加密存储等主要功能
 * 保持了混淆的命名风格
 */
public class O extends BaseTextEditorFunction {
    // 常量定义：API URL, Key, Prompt, Model, History Selection, Params
    public static final String o = "api_key", O = "api_url", l = "analysis_prompt", _0 = "model_name", I = "show_history_selection", i = "api_params";
    // 密钥别名
    static final String _1 = "MT_Plugin_Secure_Key_v4", _2 = "aes_key_blob";
    
    // 线程池，用于执行异步任务
    static final ExecutorService E = Executors.newCachedThreadPool();
    // HTTP 客户端，设置超时时间
    static final OkHttpClient C = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build();
    // 并发锁，防止重复提交
    final AtomicBoolean c = new AtomicBoolean(false);
    
    // 数据库和日志管理对象
    DB h;
    L log;
    
    // 当前会话状态：对话树和会话ID
    List<Node> currentTree = new ArrayList<>();
    String currentSid;
    boolean isHistoryDetail = false;

    /**
     * 初始化加密环境（虚假/混淆用）
     * 实际用于触发一些类加载和预热
     */
    private void fo() {
        try {
            Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(1, new SecretKeySpec(new byte[16], "AES"), new IvParameterSpec(new byte[16]));
            c.doFinal(new byte[16]);
        } catch (Exception e) {
            // 预热失败不影响主流程，但记录日志
             if (log != null) log.e("SEC", "Warmup failed", e);
        }
    }

    /**
     * 初始化插件
     * 在这里初始化数据库和日志记录器
     */
    static SharedPreferences.OnSharedPreferenceChangeListener prefListener;

    @Override
    protected void init() {
        super.init();
        h = new DB(getContext());
        log = new L(getContext());
        x(); // 安全检查
        fo(); // 预热加密
        
        try {
            if(getContext().getPreferences().getBoolean("global_float_window", false)) {
                // Delay to ensure context is ready or avoid blocking init
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                     Context ctx = (getContext() instanceof Context) ? (Context)getContext() : null;
                     if(ctx == null) ctx = getGlobalContext();
                     if(ctx != null && Build.VERSION.SDK_INT >= 23 && android.provider.Settings.canDrawOverlays(ctx)) {
                         startSystemFloating(ctx);
                     }
                }, 1000);
            }
        } catch(Exception e) {
            log.e("Init", "Auto float failed", e);
        }

        if (prefListener == null) {
            prefListener = (p, k) -> {
                if ("global_float_window".equals(k)) {
                    boolean val = p.getBoolean(k, false);
                    Context ctx = getGlobalContext();
                    if (val) {
                         if (ctx != null) startSystemFloating(ctx);
                    } else {
                        stopSystemFloating();
                    }
                }
            };
            getContext().getPreferences().registerOnSharedPreferenceChangeListener(prefListener);
        }
    }

    private Context getGlobalContext() {
        try {
            Class<?> atClass = Class.forName("android.app.ActivityThread");
            return (Context) atClass.getMethod("currentApplication").invoke(null);
        } catch (Exception e) {
            if (log != null) log.e("UI", "Global context lookup failed", e);
            return null;
        }
    }

    /**
     * 安全检查：验证调用栈和包名
     * 防止被非法调用或重打包
     */
    void x() {
        try {
            String n = getClass().getName();
            if (!n.equals("cail") && !n.startsWith("cail")) throw new Error();
            StackTraceElement[] s = Thread.currentThread().getStackTrace();
            boolean v = false;
            for (StackTraceElement e : s) {
                if (e.getClassName().contains("cail.O")) v = true;
            }
            if (!v) Runtime.getRuntime().halt(0);
        } catch (Throwable t) {
            new L(getContext()).e("SEC", "Stack check failed", t);
            Runtime.getRuntime().halt(0);
        }
    }

    /**
     * 获取 HTTP 客户端
     * @return OkHttpClient 实例
     */
    public static OkHttpClient getHttpClient() { return C; }

    /**
     * 获取或生成本地加密密钥 (KeyStore)
     * 使用 Android KeyStore 保证安全性
     * @param c 插件上下文
     * @return AES 密钥
     */
    static SecretKey sk(PluginContext c) {
        try {
            SharedPreferences p = c.getPreferences();
            String b = p.getString(_2, null);
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (!ks.containsAlias(_1)) {
                KeyPairGenerator g = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
                if (Build.VERSION.SDK_INT >= 23)
                    g.initialize(new android.security.keystore.KeyGenParameterSpec.Builder(_1, 3).setDigests("SHA-256", "SHA-1").setEncryptionPaddings("RSA/OAEP").setUserAuthenticationRequired(false).build());
                g.generateKeyPair();
            }
            if (b == null) {
                KeyGenerator kg = KeyGenerator.getInstance("AES");
                kg.init(256);
                SecretKey k = kg.generateKey();
                Cipher cp = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
                cp.init(1, ks.getCertificate(_1).getPublicKey(), new javax.crypto.spec.OAEPParameterSpec("SHA-256", "MGF1", java.security.spec.MGF1ParameterSpec.SHA1, javax.crypto.spec.PSource.PSpecified.DEFAULT));
                p.edit().putString(_2, Base64.encodeToString(cp.doFinal(k.getEncoded()), 0)).apply();
                return k;
            } else {
                Cipher cp = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
                cp.init(2, ks.getKey(_1, null), new javax.crypto.spec.OAEPParameterSpec("SHA-256", "MGF1", java.security.spec.MGF1ParameterSpec.SHA1, javax.crypto.spec.PSource.PSpecified.DEFAULT));
                return new SecretKeySpec(cp.doFinal(Base64.decode(b, 0)), "AES");
            }
        } catch (Exception e) {
            new L(c).e("SEC", "KeyStore error, using fallback", e);
            return fb(c);
        }
    }

    /**
     * 降级密钥方案（当 KeyStore 不可用时）
     * 使用纯软件 AES 实现
     * @param c 插件上下文
     * @return AES 密钥
     */
    static SecretKey fb(PluginContext c) {
        SharedPreferences p = c.getPreferences();
        String k = p.getString("fb_k", null);
        if (k == null) {
            new Handler(Looper.getMainLooper()).post(() -> {
                try { 
                    Context ctx = (c instanceof Context) ? (Context)c : null;
                    if (ctx != null) Toast.makeText(ctx, "警告: KeyStore 不可用，已降级为软件加密存储", 1).show(); 
                } catch (Exception e) {
                    new L(c).e("SEC", "Fallback toast failed", e);
                }
            });
            byte[] b = new byte[32];
            new SecureRandom().nextBytes(b);
            k = Base64.encodeToString(b, 0);
            p.edit().putString("fb_k", k).apply();
        }
        return new SecretKeySpec(Base64.decode(k, 0), "AES");
    }

    /**
     * 判断是否使用了降级密钥
     */
    public static boolean isDowngraded(PluginContext c) {
        return c.getPreferences().contains("fb_k");
    }

    /**
     * 获取解密后的 API Key
     * 包含调用栈检查
     * @param c 插件上下文
     * @return 明文 API Key
     */
    public static String g(PluginContext c) {
        L lg = new L(c);
        StackTraceElement[] s = Thread.currentThread().getStackTrace();
        boolean a = false;
        String cl;
        StringBuilder sb = new StringBuilder();
        for (int i = 2; i < s.length; i++) {
            cl = s[i].getClassName();
            if (cl.equals("O") || cl.startsWith("O$")) continue;
            sb.append("| ").append(cl).append(".").append(s[i].getMethodName()).append("(").append(s[i].getFileName()).append(":").append(s[i].getLineNumber()).append(")\n");
            if (cl.equals("w") || cl.startsWith("cail") || cl.equals("I") || cl.startsWith("I$") || cl.equals("f") || cl.startsWith("f$")) {
                a = true; break;
            } else {
                a = false; break;
            }
        }
        if (!a) {
            lg.e("SEC", "Block:\n" + sb.toString(), null);
            return "";
        }
        lg.d("SEC", "Pass");
        return gd(c, o);
    }

    /**
     * 获取解密后的 API URL
     * @param c 插件上下文
     * @return 明文 URL
     */
    public static String gUrl(PluginContext c) { return gd(c, O); }

    /**
     * 解密通用逻辑
     * 使用 AES-GCM 解密
     * @param c 插件上下文
     * @param k 键名
     * @return 解密后的值
     */
    static String gd(PluginContext c, String k) {
        try {
            String e = c.getPreferences().getString(k, "");
            if (e.isEmpty()) return "";
            if (!e.contains(":")) return "";
            String[] s = e.split(":");
            byte[] iv = Base64.decode(s[0], 0), d = Base64.decode(s[1], 0);
            Cipher cp = Cipher.getInstance("AES/GCM/NoPadding");
            cp.init(2, sk(c), new GCMParameterSpec(128, iv));
            byte[] b = cp.doFinal(d);
            return new String(b, StandardCharsets.UTF_8);
        } catch (Exception e) {
            new L(c).e("SEC", "Decryption failed for " + k, e);
            return "";
        }
    }

    /**
     * 保存 API Key (加密)
     * @param c 插件上下文
     * @param v 明文 Key
     */
    public static void s(PluginContext c, String v) { sd(c, o, v); }
    
    /**
     * 保存 API URL (加密)
     * @param c 插件上下文
     * @param v 明文 URL
     */
    public static void sUrl(PluginContext c, String v) { sd(c, O, v); }

    /**
     * 加密保存通用逻辑
     * 使用 AES-GCM 加密
     * @param c 插件上下文
     * @param k 键名
     * @param v 值
     */
    static void sd(PluginContext c, String k, String v) {
        try {
            if (v == null || v.isEmpty()) {
                c.getPreferences().edit().remove(k).apply();
                return;
            }
            Cipher cp = Cipher.getInstance("AES/GCM/NoPadding");
            cp.init(1, sk(c));
            byte[] iv = cp.getIV(), d = cp.doFinal(v.getBytes(StandardCharsets.UTF_8));
            String s = Base64.encodeToString(iv, 0).trim() + ":" + Base64.encodeToString(d, 0).trim();
            c.getPreferences().edit().putString(k, s).apply();
        } catch (Exception e) {
            new L(c).e("SEC", "Save failed", e);
        }
    }

    /**
     * 判断插件是否启用
     * @return 是否已配置 API Key
     */
    public boolean isEnabled() { return !getContext().getPreferences().getString(o, "").isEmpty(); }

    /**
     * 插件名称
     */
    @NonNull public String name() { return "AI文本分析"; }

    public boolean supportEditTextView() { return false; }
    public boolean supportRepeat() { return false; }

    /**
     * 执行插件功能
     * 处理选中文本并启动对话
     */
    public void doFunction(PluginUI i, TextEditor e, @Nullable bin.mt.json.JSONObject d) {
        try {
            String s = e.getSelectedText();
            if (s == null || s.isEmpty()) {
                i.showToast("未选择文本");
                return;
            }
            D.a(i, s, "", new D.I() {
                public void y(String t, boolean n) {
                    try {
                        if (n) a(i, s, t, "C_" + System.currentTimeMillis(), null, null);
                        else {
                            if (getContext().getPreferences().getBoolean(I, false)) b(i, s, t);
                            else a(i, s, t, c(), null, null);
                        }
                    } catch (Exception ex) {
                        i.showToast("Error: " + ex.getMessage());
                        log.e("Func", "Callback failed", ex);
                    }
                }
                public void n() {}
            });
        } catch (Exception ex) {
            i.showToast("Error: " + ex.getMessage());
            log.e("Func", "Main failed", ex);
        }
    }

    /**
     * 获取最新会话ID
     */
    String c() {
        List<Map<String, String>> l = h.l(1, 0);
        return l.isEmpty() ? "C_" + System.currentTimeMillis() : l.get(0).get("session_id");
    }

    /**
     * 显示历史会话选择对话框
     */
    void b(PluginUI i, String t, String u) {
        List<Map<String, String>> l = h.l(20, 0);
        if (l.isEmpty()) {
            a(i, t, u, "C_" + System.currentTimeMillis(), null, null);
            return;
        }
        String[] n = new String[l.size()];
        final String[] id = new String[l.size()];
        SimpleDateFormat f = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
        for (int j = 0; j < l.size(); j++) {
            Map<String, String> m = l.get(j);
            id[j] = m.get("session_id");
            n[j] = f.format(new Date(Long.parseLong(m.get("update_time")))) + " " + m.get("topic");
        }
        new w.LiquidDialog(i).setTitle("选择对话").setItems(n, (d, w) -> a(i, t, u, id[w], null, null)).setNegativeButton("取消", null).show();
    }

    /**
     * 密钥保管箱入口
     */
    public void kv(PluginUI i) {
        String p = getContext().getPreferences().getString("kv_p", "");
        if (!p.isEmpty()) ka(i, p);
        else kl(i);
    }

    /**
     * 验证保管箱密码
     */
    void ka(PluginUI i, String p) {
        PluginView v = i.buildVerticalLayout().addEditText("p").hint("密码").inputType(129).build();
        new w.LiquidDialog(i).setTitle("验证").setView(v).setPositiveButton("确定", (d, w) -> {
            if (v.<PluginEditText>requireViewById("p").getText().toString().equals(p)) kl(i);
            else i.showToast("错误");
        }).show();
    }

    /**
     * 列出保管箱密钥
     */
    void kl(PluginUI i) {
        try {
            JSONArray a = new JSONArray(getContext().getPreferences().getString("kv_d", "[]"));
            Map<String, Integer> c = new HashMap<>();
            for (int k = 0; k < a.length(); k++) {
                String n = a.getJSONObject(k).optString("n");
                c.put(n, c.getOrDefault(n, 0) + 1);
            }
            List<String> dl = new ArrayList<>(), pn = new ArrayList<>();
            for (w.p p : w.P)
                if (c.containsKey(p.n)) {
                    dl.add(p.n + " (" + c.get(p.n) + "条密钥)");
                    pn.add(p.n);
                }
            for (String n : c.keySet()) {
                boolean b = false;
                for (w.p p : w.P)
                    if (p.n.equals(n)) b = true;
                if (!b) {
                    dl.add(n + " (" + c.get(n) + "条密钥)");
                    pn.add(n);
                }
            }
            boolean hp = !getContext().getPreferences().getString("kv_p", "").isEmpty();
            new w.LiquidDialog(i).setTitle("密钥保管箱").setItems(dl.toArray(new String[0]), (d, w) -> ks(i, pn.get(w))).setPositiveButton("新建密钥", (d, w) -> kn(i)).setNeutralButton(hp ? "修改密码" : "设置密码", (d, w) -> kp(i, hp)).setNegativeButton("返回", null).show();
        } catch (Exception e) {
            log.e("KV", "L", e);
        }
    }

    /**
     * 显示特定提供商的密钥
     */
    void ks(PluginUI i, String p) {
        try {
            JSONArray a = new JSONArray(getContext().getPreferences().getString("kv_d", "[]"));
            List<JSONObject> k = new ArrayList<>();
            List<String> d = new ArrayList<>();
            List<Integer> x = new ArrayList<>();
            for (int j = 0; j < a.length(); j++) {
                JSONObject o = a.getJSONObject(j);
                if (o.optString("n").equals(p)) {
                    k.add(o);
                    x.add(j);
                    String ky = o.optString("k"), r = o.optString("r");
                    if (ky.length() > 6) ky = ky.substring(0, 6) + "...";
                    d.add(ky + (r.isEmpty() ? "" : " (" + r + ")"));
                }
            }
            new w.LiquidDialog(i).setTitle(p).setItems(d.toArray(new String[0]), (dg, w) -> ke(i, k.get(w), x.get(w))).setNegativeButton("返回", (dg, w) -> kl(i)).show();
        } catch (Exception e) {
            log.e("KV", "Load failed", e);
        }
    }

    /**
     * 新建密钥UI
     */
    void kn(PluginUI i) {
        List<String> l = new ArrayList<>();
        for (w.p p : w.P) l.add(p.n);
        PluginView v = i.buildVerticalLayout().addTextView().text("服务提供商:").paddingBottomDp(5).addSpinner("p").items(l).addEditText("c").hint("输入自定义提供商名称").marginTopDp(5).addEditText("u").hint("输入API地址").marginTopDp(5).addEditText("k").hint("密钥 (sk-...)").marginTopDp(10).addEditText("r").hint("备注").marginTopDp(10).build();
        PluginSpinner s = v.requireViewById("p");
        PluginEditText c = v.requireViewById("c"), u = v.requireViewById("u");
        c.setGone();
        u.setGone();
        s.setOnItemSelectedListener((sp, pos) -> {
            if (pos == l.size() - 1) {
                c.setVisible();
                u.setVisible();
            } else {
                c.setGone();
                u.setGone();
            }
        });
        new w.LiquidDialog(i).setTitle("新建密钥").setView(v).setPositiveButton("保存", (d, w) -> {
            String pr = s.getSelectedItem().toString();
            if (pr.equals("自定义提供商")) {
                pr = c.getText().toString().trim();
                String url = u.getText().toString().trim();
                if (!url.isEmpty()) pr = url;
            }
            String ky = v.<PluginEditText>requireViewById("k").getText().toString().trim(), rm = v.<PluginEditText>requireViewById("r").getText().toString().trim();
            if (pr.isEmpty() || ky.isEmpty()) {
                i.showToast("完整填写所有字段!");
                return;
            }
            sk(i, -1, pr, ky, rm, false);
        }).setNegativeButton("取消", null).show();
    }

    /**
     * 编辑密钥UI
     */
    void ke(PluginUI i, JSONObject o, int x) {
        String n = o.optString("n"), k = o.optString("k"), r = o.optString("r");
        PluginView v = i.buildVerticalLayout().addEditText("n").text(n).hint("服务提供商").addEditText("k").text(k).hint("密钥").addEditText("r").text(r).hint("备注").build();
        new w.LiquidDialog(i).setTitle("编辑密钥").setView(v).setPositiveButton("保存", (d, w) -> sk(i, x, v.<PluginEditText>requireViewById("n").getText().toString(), v.<PluginEditText>requireViewById("k").getText().toString(), v.<PluginEditText>requireViewById("r").getText().toString(), false)).setNeutralButton("一键使用", (d, w) -> {
            s(getContext(), k);
            i.showToast("已填入当前配置");
        }).setNegativeButton("删除", (d, w) -> dk(i, x)).show();
    }

    /**
     * 保存密钥到存储
     */
    public void sk(PluginUI i, int x, String n, String k, String r, boolean a) {
        try {
            JSONArray j = new JSONArray(getContext().getPreferences().getString("kv_d", "[]"));
            if (a) {
                for (int z = 0; z < j.length(); z++)
                    if (j.getJSONObject(z).optString("k").equals(k)) return;
            }
            JSONObject o = new JSONObject().put("n", n).put("k", k).put("r", r);
            if (x < 0) j.put(o);
            else j.put(x, o);
            getContext().getPreferences().edit().putString("kv_d", j.toString()).apply();
            if (!a) {
                i.showToast("密钥已保存到保管箱");
                kl(i);
            }
        } catch (Exception e) {
            i.showToast("保存失败: " + e.getMessage());
            new L(i.getContext()).e("KV", "Save failed", e);
        }
    }

    /**
     * 删除密钥
     */
    void dk(PluginUI i, int x) {
        try {
            JSONArray a = new JSONArray(getContext().getPreferences().getString("kv_d", "[]"));
            a.remove(x);
            getContext().getPreferences().edit().putString("kv_d", a.toString()).apply();
            i.showToast("密钥已删除");
            kl(i);
        } catch (Exception e) {
            i.showToast("删除失败");
            new L(i.getContext()).e("KV", "Delete failed", e);
        }
    }

    /**
     * 设置或修改保管箱密码
     */
    void kp(PluginUI i, boolean c) {
        PluginRootLayoutBuilder v = i.buildVerticalLayout();
        if (c) v.addEditText("o").hint("原密码").inputType(129).marginBottomDp(10);
        v.addEditText("n").hint("新密码").inputType(129);
        v.addTextView().text("请记忆好这个密码，本插件并未提供任何忘记密码及找回功能。").textColor(Color.RED).textSize(12).marginTopDp(10);
        PluginView pv = v.build();
        i.buildDialog().setTitle(c ? "修改密码" : "设置密码").setView(pv).setPositiveButton("确认", (d, w) -> {
            String np = pv.<PluginEditText>requireViewById("n").getText().toString();
            if (c) {
                String op = pv.<PluginEditText>requireViewById("o").getText().toString();
                if (!op.equals(getContext().getPreferences().getString("kv_p", ""))) {
                    i.showToast("原密码错误");
                    return;
                }
            }
            if (np.isEmpty()) {
                new w.LiquidDialog(i).setTitle("警告").setMessage("密码为空将清除密码保护，确定吗？").setPositiveButton("确定", (dd, ww) -> {
                    getContext().getPreferences().edit().remove("kv_p").apply();
                    i.showToast("密码保护已取消");
                    kl(i);
                }).setNegativeButton("取消", null).show();
                return;
            }
            PluginView v2 = i.buildVerticalLayout().addEditText("c").hint("请再次输入密码以确认").inputType(129).build();
            new w.LiquidDialog(i).setTitle("确认密码").setView(v2).setPositiveButton("确定", (dd, ww) -> {
                if (v2.<PluginEditText>requireViewById("c").getText().toString().equals(np)) {
                    getContext().getPreferences().edit().putString("kv_p", np).apply();
                    i.showToast("密码已设置");
                    kl(i);
                } else i.showToast("两次密码不一致");
            }).show();
        }).setNegativeButton("取消", null).show();
    }

    /**
     * 显示历史会话列表
     */
    public void h(PluginUI i) {
        try {
            List<Map<String, String>> l = h.l(100, 0);
            if (l.isEmpty()) {
                i.showToast("暂无历史记录");
                return;
            }
            String[] n = new String[l.size()];
            final String[] id = new String[l.size()];
            SimpleDateFormat f = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
            for (int j = 0; j < l.size(); j++) {
                Map<String, String> m = l.get(j);
                id[j] = m.get("session_id");
                n[j] = f.format(new Date(Long.parseLong(m.get("update_time")))) + " " + m.get("topic");
            }
            new w.LiquidDialog(i).setTitle("历史").setItems(n, (d, w) -> d(i, id[w])).setPositiveButton("清空", (d, w) -> new w.LiquidDialog(i).setTitle("确认").setMessage("确认清空所有历史记录吗？").setPositiveButton("是", (dd, ww) -> {
                h.c();
                i.showToast("已清空");
            }).setNegativeButton("否", null).show()).setNeutralButton("导出全部", (d, w) -> ea(i)).show();
        } catch (Exception e) {
            log.e("UI", "History", e);
        }
    }

    /**
     * 导出所有会话
     */
    void ea(PluginUI i) {
        try {
            File d = new File("/sdcard/MT2/MT_AI/All_" + System.currentTimeMillis());
            d.mkdirs();
            List<Map<String, String>> l = h.l(999, 0);
            for (Map<String, String> s : l) {
                String id = s.get("session_id");
                List<Node> roots = h.g(id);
                // 导出 MD
                StringBuilder b = new StringBuilder();
                List<Node> flat = flatten(roots);
                for (Node g : flat) b.append("[").append(g.role).append("] ").append(g.content).append("\n\n");
                new FileOutputStream(new File(d, id + ".md")).write(b.toString().getBytes());
                
                // 导出 HTML (支持分支)
                String html = P.generateStaticHtml(roots, s.get("topic"), getContext());
                new FileOutputStream(new File(d, id + ".html")).write(html.getBytes(StandardCharsets.UTF_8));
            }
            i.showToast("已导出至: " + d);
        } catch (Exception e) {
            i.showToast("Err:" + e);
            log.e("IO", "Export All failed", e);
        }
    }

    /**
     * 展平对话树
     */
    synchronized List<Node> flatten(List<Node> roots) {
        List<Node> list = new ArrayList<>();
        if(roots.isEmpty()) return list;
        Node curr = roots.get(0);
        while(curr != null) {
            list.add(curr);
            if(curr.children.isEmpty()) break;
            curr = curr.children.get(curr.selectIndex < curr.children.size() ? curr.selectIndex : 0);
        }
        return list;
    }

    /**
     * 显示具体对话详情 (使用 WebView)
     */
    void d(PluginUI i, String sid) {
        // 使用 P 类逻辑显示对话
        currentSid = sid;
        currentTree = h.g(sid);
        isHistoryDetail = true;
        P p = new P(this, i, () -> {
            save();
            isHistoryDetail = false;
        }, () -> {});
        p.s();
    }

    /**
     * 启动AI对话任务
     */
    public void a(PluginUI i, String t, String u, String sid) {
        a(i, t, u, sid, null, null);
    }

    /**
     * 启动AI对话任务 (带 P 实例和目标节点)
     */
    void a(PluginUI i, String t, String u, String sid, P p, String targetNodeId) {
        String k = g(getContext());
        if (k.isEmpty()) {
            i.showToast("密钥无效，请先配置 API Key");
            return;
        }
        if (!c.compareAndSet(false, true)) {
            i.showToast("当前有正在进行的分析任务，请稍候...");
            return;
        }
        log.d("Task", sid);
        
        // 修复历史泄露：切换会话时重置状态
        if (currentSid != null && !sid.equals(currentSid)) {
            currentTree = new ArrayList<>();
        }
        currentSid = sid;
        List<Node> dbTree = h.g(sid);
        if (!dbTree.isEmpty()) currentTree = dbTree;
        
        // 修复：立即初始化 UI 以避免流式响应延迟
        final P task;
        if (p == null) {
            task = new P(this, i, () -> {
                c.set(false);
                save(); 
            }, () -> {});
            task.s();
        } else {
            task = p;
        }
        
        R r = new R(i, t, u, sid, k, task, targetNodeId);
        E.execute(r);
    }

    /**
     * 保存当前会话到数据库
     * 包含主题更新逻辑优化
     */
    synchronized void save() {
        try {
            if(currentSid != null && !currentTree.isEmpty()) {
                h.s(currentSid, currentTree);
                
                // 更新主题逻辑优化
                String currentTopic = h.getTopic(currentSid);
                if (currentTopic == null || currentTopic.equals("新对话") || currentTopic.isEmpty()) {
                     String topic = "";
                     Node root = currentTree.get(0);
                     // 查找第一条用户消息
                     Node firstUser = null;
                     if ("user".equals(root.role)) firstUser = root;
                     else if (!root.children.isEmpty()) firstUser = root.children.get(0);
                     
                     if (firstUser != null && "user".equals(firstUser.role)) {
                         topic = firstUser.content;
                         // 截断长主题
                         if(topic.length() > 20) topic = topic.substring(0, 20) + "...";
                         h.u(currentSid, topic);
                     }
                }
            }
        } catch (Exception e) {
            if(log != null) log.e("Logic", "Save failed", e);
        }
    }

    /**
     * 异步任务类 R
     * 负责处理 API 请求和响应
     */
    class R implements Runnable {
        WeakReference<PluginUI> wi;
        String t, u, sid, k, targetNodeId;
        String r = "";
        Exception e;
        Call cl;
        P task;
        boolean ca = false;

        R(PluginUI i, String t, String u, String sid, String k, P task, String targetNodeId) {
            this.wi = new WeakReference<>(i);
            this.t = t;
            this.u = u;
            this.sid = sid;
            this.k = k;
            this.task = task;
            this.targetNodeId = targetNodeId;
        }

        public void run() {
            PluginUI i = wi.get();
            if (i == null) {
                O.this.c.set(false);
                return;
            }
            try {
                // UI 已在主线程初始化，此处设置取消回调引用
                if (task != null) {
                    task.onCancel = () -> {
                        ca = true;
                        if (cl != null) cl.cancel();
                        O.this.c.set(false);
                        save();
                    };
                }

                String L = gUrl(getContext());
                if (L.isEmpty()) L = "https://api.siliconflow.cn/v1/chat/completions";
                String M = getContext().getPreferences().getString(_0, "deepseek-ai/DeepSeek-V3").trim();
                String P = getContext().getPreferences().getString(l, "分析文本：\n\n{text}");

                synchronized(O.this) {
                    if (currentTree.isEmpty()) {
                        // System Prompt
                        Node sys = new Node(UUID.randomUUID().toString(), "system", "角色：资深分析师。\n格式：首轮对话第一行输出不被任何Markdown标记包围的 'Topic: 主题'。", null);
                        currentTree.add(sys);
                    }
                }

                String f;
                // 确定上下文。如果是新会话(只有system节点)，添加上下文。
                // 或者用户显式添加文本。
                boolean isNew = currentTree.size() <= 1;
                
                if (isNew) f = (P.contains("{text}") ? P.replace("{text}", t) : P + "\n" + t) + (u != null && !u.isEmpty() ? "\n" + u : "");
                else f = t + (u != null && !u.isEmpty() ? "\n" + u : "");

                // 如果是重新回答，不需要创建用户节点，而是直接使用上下文请求
                if (targetNodeId != null) {
                    // 重新回答逻辑：不需要添加用户节点，上下文构建到 targetNode 的父节点为止
                } else if (!f.trim().isEmpty()) {
                    // 正常对话逻辑：创建用户节点
                    String userContent = t + (u != null && !u.isEmpty() ? "\n" + u : "");
                    
                    synchronized(O.this) {
                        Node parent = findLastNode();
                        Node userNode = new Node(UUID.randomUUID().toString(), "user", userContent, parent == null ? null : parent.id);
                        if(parent != null) {
                            parent.children.add(userNode);
                            parent.selectIndex = parent.children.size() - 1;
                        } else {
                            currentTree.add(userNode); 
                        }
                    }
                    ThreadUtil.post(() -> task.updateTree());
                }

                // 构建上下文
                // 如果 targetNodeId 存在，我们找到它的父节点作为上下文结尾
                Node contextEndNode;
                if (targetNodeId != null) {
                    Node target = findNode(targetNodeId);
                    contextEndNode = target != null ? findNode(target.parentId) : findLastNode();
                } else {
                    contextEndNode = findLastNode();
                }
                
                List<Map<String, String>> ms = buildContext(contextEndNode, isNew, P, t);

                // 预先创建或获取 AI 节点，确保流式输出时 Token 统计显示在正确位置
                if (targetNodeId == null) {
                    synchronized(O.this) {
                        Node last = findLastNode();
                        if (last != null && "assistant".equals(last.role) && (last.content == null || last.content.isEmpty() || "...".equals(last.content))) {
                            targetNodeId = last.id;
                            last.content = "";
                            last.reasoning = "";
                        } else {
                            Node aiNode = new Node(UUID.randomUUID().toString(), "assistant", "", last == null ? null : last.id);
                            if (last != null) {
                                last.children.add(aiNode);
                                last.selectIndex = last.children.size() - 1;
                            } else {
                                currentTree.add(aiNode);
                            }
                            targetNodeId = aiNode.id;
                        }
                    }
                    // 更新当前任务的目标节点ID
                    this.targetNodeId = targetNodeId;
                    // 立即刷新 UI 显示空气泡
                    ThreadUtil.post(() -> task.updateTree());
                }

                // 发送请求
                r = O.this.f(L, k, M, ms, this);
                if (!r.isEmpty()) {
                    // 优化 Topic 识别逻辑，支持多种格式
                    Matcher m = Pattern.compile("(?m)^(?:Topic:|\\*\\*Topic\\*\\*:?)\\s*(.+)").matcher(r);
                    if (m.find()) h.u(sid, m.group(1).trim()); 
                    
                    // 更新完整内容
                    Node target = findNode(targetNodeId);
                    if (target != null) {
                        // 更新完整内容，包括思考过程
                        if (target.reasoning != null && !target.reasoning.isEmpty()) {
                            target.content = r.replace(target.reasoning, "").trim(); 
                        } else {
                            target.content = r;
                        }
                    }
                     ThreadUtil.post(() -> task.updateTree());
                }
            } catch (Exception x) {
                e = x;
                log.e("Task", "Fail", x);
            } finally {
                ThreadUtil.post(() -> {
                    if (task != null) {
                        if (e != null && !ca) {
                            task.c();
                            if (wi.get() != null) new w.LiquidDialog(wi.get()).setMessage("分析任务失败: " + e.getMessage() + "\n请检查网络连接或 API Key 设置。").show();
                        } else if (!ca) task.p();
                    }
                    O.this.c.set(false);
                });
            }
        }
    }
    
    /**
     * 查找最后一个活动节点
     */
    Node findLastNode() {
        if(currentTree.isEmpty()) return null;
        Node curr = currentTree.get(0);
        while(!curr.children.isEmpty()) {
            int idx = curr.selectIndex;
            if(idx < 0 || idx >= curr.children.size()) idx = 0;
            curr = curr.children.get(idx);
        }
        return curr;
    }
    
    /**
     * 构建上下文消息列表
     */
    List<Map<String, String>> buildContext(Node leaf, boolean isNew, String promptTmpl, String selectedText) {
        List<Map<String, String>> ms = new ArrayList<>();
        Node curr = leaf;
        while(curr != null) {
            Map<String, String> m = new HashMap<>();
            m.put("role", curr.role);
            String content = curr.content;
            
            // 如果是第一个用户节点（且 isNew），需要拼接 Prompt
            if (isNew && "user".equals(curr.role) && curr.parentId != null) {
                Node p = findNode(curr.parentId);
                if (p != null && "system".equals(p.role)) {
                     content = (promptTmpl.contains("{text}") ? promptTmpl.replace("{text}", curr.content) : promptTmpl + "\n" + curr.content);
                }
            }
            
            m.put("content", content);
            ms.add(0, m);
            if(curr.parentId == null) break;
            curr = findNode(curr.parentId);
        }
        return ms;
    }
    
    /**
     * 查找节点
     */
    Node findNode(String id) {
        for(Node n : currentTree) {
            Node f = findNodeRec(n, id);
            if(f != null) return f;
        }
        return null;
    }
    
    Node findNodeRec(Node n, String id) {
        if(n.id.equals(id)) return n;
        for(Node c : n.children) {
            Node f = findNodeRec(c, id);
            if(f != null) return f;
        }
        return null;
    }

    /**
     * 执行网络请求 (流式)
     */
    String f(String u, String k, String m, List<Map<String, String>> ms, R a) throws Exception {
        JSONObject b = new JSONObject().put("model", m).put("stream", true);
        JSONArray j = new JSONArray();
        for (Map<String, String> g : ms) j.put(new JSONObject().put("role", g.get("role")).put("content", g.get("content")));
        try {
            String ps = getContext().getPreferences().getString(i, "{}");
            if (ps == null || ps.trim().isEmpty()) ps = "{}";
            JSONObject p = new JSONObject(ps);
            Iterator<String> it = p.keys();
            while (it.hasNext()) {
                String ky = it.next();
                b.put(ky, p.get(ky));
            }
        } catch (Exception e) {
             new L(getContext()).e("Task", "Params parse failed", e);
        }
        b.put("messages", j);
        Request q = new Request.Builder().url(u).header("Authorization", "Bearer " + k).header("Accept", "text/event-stream").post(RequestBody.create(MediaType.parse("application/json"), b.toString())).build();
        a.cl = C.newCall(q);
        StringBuilder f = new StringBuilder(); // 完整内容
        try (Response p = a.cl.execute()) {
            if (!p.isSuccessful()) throw new Exception("HTTP " + p.code());
            ResponseBody rb = p.body();
            if (rb != null) {
                BufferedSource s = rb.source();
                boolean tk = false, st = false;
                while (!s.exhausted()) {
                    if (a.ca) break;
                    String l = s.readUtf8Line();
                    if (l != null && l.startsWith("data: ")) {
                        String d = l.substring(6);
                        if (d.equals("[DONE]")) break;
                        try {
                            JSONObject J = new JSONObject(d);
                            JSONObject usg = J.optJSONObject("usage");
                            if (usg != null) {
                                int pt = usg.optInt("prompt_tokens");
                                int ct = usg.optInt("completion_tokens");
                                int tt = usg.optInt("total_tokens");
                                ThreadUtil.post(() -> {
                                    if (a.task != null) a.task.uTokens(pt, ct, tt, a.targetNodeId);
                                });
                            }
                            JSONArray cs = J.optJSONArray("choices");
                            if (cs != null && cs.length() > 0) {
                                JSONObject dl = cs.getJSONObject(0).optJSONObject("delta");
                                if (dl != null) {
                                    String rs = dl.optString("reasoning_content", "");
                                    String ct = dl.optString("content", "");
                                    
                                    if ("null".equals(rs)) rs = "";
                                    if ("null".equals(ct)) ct = "";
                                    
                                    if (!rs.isEmpty()) {
                                        final String frs = rs;
                                        ThreadUtil.post(() -> {
                                            if (a.task != null) a.task.uReasoning(frs, a.targetNodeId);
                                        });
                                    }
                                    if (!ct.isEmpty()) {
                                        f.append(ct);
                                        final String fct = ct;
                                        ThreadUtil.post(() -> {
                                            if (a.task != null) a.task.u(fct, a.targetNodeId);
                                        });
                                    }
                                }
                            }
                        } catch (Exception e) {
                             new L(getContext()).e("Task", "Stream parse failed: " + d, e);
                        }
                    }
                }
            }
        }
        return f.toString();
    }

    /**
     * 数据库管理类 DB
     * 管理会话历史记录
     */
    static class DB {
        File p;
        PluginContext ctx; // Store context for logging
        DB(PluginContext c) {
            this.ctx = c;
            p = new File(c.getFilesDir(), "ai_history_v2.db");
            try (SQLiteDatabase d = o()) {
                // 升级数据库版本以支持 reasoning 字段
                if (d.getVersion() < 3) {
                    if (d.getVersion() < 2) c(d);
                    try { d.execSQL("ALTER TABLE messages ADD COLUMN reasoning TEXT"); } catch(Exception e){ new L(c).e("DB", "Alter failed", e); }
                    d.setVersion(3);
                }
            }
        }
        SQLiteDatabase o() { return SQLiteDatabase.openOrCreateDatabase(p, null); }
        void c(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT UNIQUE, topic TEXT, update_time LONG)");
            d.execSQL("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, msg_id TEXT UNIQUE, session_id TEXT, role TEXT, content TEXT, parent_id TEXT, created_at LONG)");
        }
        List<Node> g(String sid) {
            Map<String, Node> map = new HashMap<>();
            List<Node> roots = new ArrayList<>();
            try (SQLiteDatabase d = o()) {
                // 查询包含 reasoning 字段
                Cursor c = d.rawQuery("SELECT msg_id, role, content, parent_id, created_at, reasoning FROM messages WHERE session_id = ? ORDER BY created_at ASC", new String[]{sid});
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    Node n = new Node(id, c.getString(1), c.getString(2), c.getString(3));
                    n.created = c.getLong(4);
                    // 兼容旧数据
                    if (c.getColumnCount() > 5) {
                        n.reasoning = c.getString(5);
                    }
                    map.put(id, n);
                }
                c.close();
            }
            for (Node n : map.values()) {
                if (n.parentId == null || !map.containsKey(n.parentId)) roots.add(n);
                else map.get(n.parentId).children.add(n);
            }
            for (Node n : map.values()) Collections.sort(n.children, (a, b) -> Long.compare(a.created, b.created));
            Collections.sort(roots, (a, b) -> Long.compare(a.created, b.created));
            return roots;
        }
        void s(String sid, List<Node> roots) {
            try (SQLiteDatabase d = o()) {
                d.beginTransaction();
                try {
                    d.delete("messages", "session_id=?", new String[]{sid});
                    for (Node n : roots) r(d, sid, n);
                    d.setTransactionSuccessful();
                } finally {
                    d.endTransaction();
                }
            } catch (Exception e) {
                if(ctx != null) new L(ctx).e("DB", "Save failed", e);
            }
        }
        void r(SQLiteDatabase d, String sid, Node n) {
            ContentValues v = new ContentValues();
            v.put("session_id", sid);
            v.put("msg_id", n.id);
            v.put("role", n.role);
            v.put("content", n.content);
            v.put("parent_id", n.parentId);
            v.put("created_at", n.created);
            if (n.reasoning != null) v.put("reasoning", n.reasoning);
            d.insert("messages", null, v);
            for (Node c : n.children) r(d, sid, c);
        }
        void u(String s, String t) {
            try (SQLiteDatabase d = o()) {
                ContentValues v = new ContentValues();
                if (t != null) v.put("topic", t);
                v.put("update_time", System.currentTimeMillis());
                if (d.update("sessions", v, "session_id=?", new String[]{s}) == 0) {
                    v.put("session_id", s);
                    if (t == null) v.put("topic", "新对话");
                    d.insert("sessions", null, v);
                }
            } catch (Exception e) {
                if(ctx != null) new L(ctx).e("DB", "Update failed", e);
            }
        }
        // 新增：获取主题
        String getTopic(String s) {
            try (SQLiteDatabase d = o()) {
                try (Cursor c = d.rawQuery("SELECT topic FROM sessions WHERE session_id=?", new String[]{s})) {
                    if (c.moveToFirst()) {
                        return c.getString(0);
                    }
                }
            } catch(Exception e) {
                if(ctx != null) new L(ctx).e("DB", "GetTopic failed", e);
            }
            return null;
        }
        
        List<Map<String, String>> l(int limit, int off) {
            List<Map<String, String>> l = new ArrayList<>();
            try (SQLiteDatabase d = o()) {
                Cursor c = d.rawQuery("SELECT session_id, topic, update_time FROM sessions ORDER BY update_time DESC LIMIT ? OFFSET ?", new String[]{String.valueOf(limit), String.valueOf(off)});
                while (c.moveToNext()) {
                    Map<String, String> m = new HashMap<>();
                    m.put("session_id", c.getString(0));
                    m.put("topic", c.getString(1));
                    m.put("update_time", String.valueOf(c.getLong(2)));
                    l.add(m);
                }
                c.close();
            }
            return l;
        }
        void d(String s) {
            try (SQLiteDatabase d = o()) {
                d.delete("sessions", "session_id=?", new String[]{s});
                d.delete("messages", "session_id=?", new String[]{s});
            }
        }
        void c() {
            try (SQLiteDatabase d = o()) {
                d.delete("sessions", null, null);
                d.delete("messages", null, null);
            }
        }
    }

    /**
     * 日志管理类 L
     * 负责日志记录和调试信息
     */
    static class L {
        final PluginContext c;
        final SharedPreferences p;
        List<String> t = new ArrayList<>();
        L(PluginContext c) {
            this.c = c;
            if (c != null) {
                p = c.getPreferences();
                try {
                    String j = p.getString("debug_logs", "[]");
                    JSONArray a = new JSONArray(j);
                    for (int i = 0; i < a.length(); i++) t.add(a.getString(i));
                } catch (Exception e) {
                    if(c != null) c.log("Log load failed: " + e.getMessage());
                }
            } else {
                p = null;
            }
        }
        void d(String k, String m) { l("D", k, m); }
        void e(String k, String m, Throwable r) { l("E", k, m + (r != null ? "\n" + g(r) : "")); }
        synchronized void l(String l, String k, String m) {
            String e = new SimpleDateFormat("HH:mm:ss").format(new Date()) + " " + l + "/" + k + ": " + m;
            t.add(e);
            if (t.size() > 100) t.remove(0);
            if (p != null) {
                // Create a copy to avoid concurrent modification during iteration by JSONArray constructor if accessed elsewhere
                // But since we are synchronized, it should be fine if no other method accesses t.
                // However, JSONArray constructor iterates. 
                p.edit().putString("debug_logs", new JSONArray(new ArrayList<>(t)).toString()).apply();
            }
            if (c != null) c.log(e);
            else android.util.Log.i("MT_AI_L", e);
        }
        String g(Throwable t) {
            StringWriter w = new StringWriter();
            t.printStackTrace(new PrintWriter(w));
            return w.toString();
        }
    }
    
    /**
     * 对话节点类 Node
     * 存储单条对话消息及其结构
     */
    static class Node {
        String id;
        String role;
        String content;
        String reasoning; // 新增：思考内容
        String parentId;
        long created;
        List<Node> children = new ArrayList<>();
        int selectIndex = 0;
        // Token 统计
        int promptTokens = 0;
        int completionTokens = 0;
        int totalTokens = 0;

        Node(String id, String role, String content, String parentId) {
            this.id = id;
            this.role = role;
            this.content = content;
            this.parentId = parentId;
            this.created = System.currentTimeMillis();
        }
        JSONObject toJson() throws JSONException {
            JSONObject j = new JSONObject();
            j.put("id", id);
            j.put("role", role);
            j.put("content", content);
            if (reasoning != null) j.put("reasoning", reasoning);
            j.put("parentId", parentId);
            j.put("selectIndex", selectIndex);
            if (totalTokens > 0) {
                j.put("pt", promptTokens);
                j.put("ct", completionTokens);
                j.put("tt", totalTokens);
            }
            if(!children.isEmpty()) {
                JSONArray c = new JSONArray();
                for(Node n : children) c.put(n.toJson());
                j.put("children", c);
            }
            return j;
        }
    }

    // 反射获取 View (用于 hack UI)
    public static View getRealView(Object pluginView) {
        if (pluginView == null) return null;
        try {
            // P.fieldCache is private, need new cache or just reflect every time (or static cache in O)
            // For simplicity in O, let's use a local cache or just reflect.
            // But wait, P had fieldCache. Let's assume we can move the cache too.
            if (P.fieldCache != null) return (View) P.fieldCache.get(pluginView);
            Class<?> clz = pluginView.getClass();
            while (clz != null) {
                for (java.lang.reflect.Field f : clz.getDeclaredFields()) {
                    f.setAccessible(true);
                    Object v = f.get(pluginView);
                    if (v instanceof View) {
                        P.fieldCache = f;
                        return (View) v;
                    }
                }
                clz = clz.getSuperclass();
            }
        } catch (Exception e) {
            PluginContext c = w.weakContext != null ? w.weakContext.get() : null;
            if (c != null) new L(c).e("UI", "Reflect View failed", e);
        }
        return null;
    }

    /**
     * 对话 UI 管理类 P
     * 负责 WebView 的创建和交互
     */
    static class P {
        static java.lang.reflect.Field fieldCache = null;
        private static java.lang.reflect.Field dialogFieldCache = null;
        O outer;
        PluginUI u;
        Runnable onCancel, onFollow;
        Handler h = new Handler(Looper.getMainLooper());
        android.app.Dialog d;
        WebView webView;
        PluginEditText inputEdit;
        boolean isCancelled = false, isLoaded = false;
        boolean isFloating = false;

        P(O outer, PluginUI u, Runnable c, Runnable f) {
            this.outer = outer;
            this.u = u;
            this.onCancel = c;
            this.onFollow = f;
        }

        private android.app.Dialog getInternalDialog(Object pluginDialog) {
            if (pluginDialog == null) return null;
            try {
                if (dialogFieldCache != null) return (android.app.Dialog) dialogFieldCache.get(pluginDialog);
                Class<?> clz = pluginDialog.getClass();
                while (clz != null) {
                    for (java.lang.reflect.Field f : clz.getDeclaredFields()) {
                        f.setAccessible(true);
                        Object v = f.get(pluginDialog);
                        if (v instanceof android.app.Dialog) {
                            dialogFieldCache = f;
                            return (android.app.Dialog) v;
                        }
                    }
                    clz = clz.getSuperclass();
                }
            } catch (Exception ignored) {
                if(outer.log != null) outer.log.e("UI", "Reflect Dialog failed", ignored);
            }
            return null;
        }

        // 显示对话框
        void s() {
            isCancelled = false;
            if (webView != null && inputEdit == null) { // Headless/Injected mode (webView set, inputEdit not managed by P)
                initHtml();
                return;
            }
            if (d != null) { d.show(); return; }
            PluginView temp = u.buildVerticalLayout().build();
            View tempV = cail.O.getRealView(temp);
            // 修复：如果获取 View 失败，尝试显示错误信息
            if (tempV == null) {
                u.showToast("错误：无法获取UI上下文，可能不兼容当前MT版本");
                return;
            }
            Context ctx = tempV.getContext();
            boolean dk = u.isDarkTheme();
            int barBg = Color.parseColor(dk ? "#1E1E1E" : "#F8F8F8");
            int editBg = Color.parseColor(dk ? "#2D2D2D" : "#FFFFFF");
            int accentColor = u.colorAccent();
            PluginView bottomBar = u.buildHorizontalLayout().widthMatchParent().heightDp(60).paddingDp(12, 8, 12, 8).backgroundColor(barBg).addEditText("input").hint("输入您的问题...").layoutWeight(1.0f).textSize(14f).paddingDp(12, 8, 12, 8).marginBottomDp(4).backgroundColor(editBg).addButton("send").text("发送").widthDp(65).heightDp(36).marginLeftDp(10).marginBottomDp(4).backgroundColor(accentColor).textColor(Color.WHITE).build();
            inputEdit = bottomBar.requireViewById("input");
            View editV = cail.O.getRealView(inputEdit);
            if (editV != null) {
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setColor(editBg);
                gd.setCornerRadius(20);
                gd.setStroke(2, Color.parseColor(dk ? "#3D3D3D" : "#DDDDDD"));
                editV.setBackground(gd);
            }
            View sendV = cail.O.getRealView(bottomBar.requireViewById("send"));
            if (sendV != null) {
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setColor(accentColor);
                gd.setCornerRadius(18);
                sendV.setBackground(gd);
            }
            bottomBar.requireViewById("send").setOnClickListener(v -> {
                String txt = inputEdit.getText().toString().trim();
                if (!txt.isEmpty()) {
                    outer.a(u, "", txt, outer.currentSid != null ? outer.currentSid : outer.c(), this, null);
                    inputEdit.setText("");
                    try {
                        android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
                        View rv = cail.O.getRealView(inputEdit);
                        if (rv != null) imm.hideSoftInputFromWindow(rv.getWindowToken(), 0);
                    } catch (Exception ignored) {
                new L(outer.getContext()).e("UI", "Dialog resize failed", ignored);
            }
                }
            });
            android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
            int lockHeight = (int) (dm.heightPixels * 0.82);
            webView = new WebView(ctx);
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            WebSettings ws = webView.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setAllowFileAccess(true); // 允许访问本地 JS 缓存
            ws.setAllowContentAccess(true);
            ws.setGeolocationEnabled(false);
            ws.setCacheMode(WebSettings.LOAD_DEFAULT);
            ws.setDatabaseEnabled(true);
            webView.setBackgroundColor(0); // 设置背景透明
            PluginView container = u.buildVerticalLayout().widthMatchParent().build();
            try {
                LinearLayout host = (LinearLayout) cail.O.getRealView(container);
                if (host != null) {
                    host.setLayoutParams(new LinearLayout.LayoutParams(-1, lockHeight));
                    host.setMinimumHeight(lockHeight);
                    host.setOrientation(LinearLayout.VERTICAL);
                    host.setClipChildren(false);
                    host.setClipToPadding(false);
                    int leftPad = host.getPaddingLeft();
                    int rightPad = host.getPaddingRight();
                    LinearLayout.LayoutParams webLp = new LinearLayout.LayoutParams(-1, 0, 1.0f);
                    webLp.leftMargin = -leftPad;
                    webLp.rightMargin = -rightPad;
                    webView.setLayoutParams(webLp);
                    host.addView(webView);
                    View bbv = cail.O.getRealView(bottomBar);
                    if (bbv != null) {
                        LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(-1, -2);
                        bottomLp.leftMargin = -leftPad;
                        bottomLp.rightMargin = -rightPad;
                        bbv.setLayoutParams(bottomLp);
                        host.addView(bbv);
                    }
                } else {
                    // 修复：如果获取不到 Host，尝试通过 Dialog View 注入
                    outer.log.e("UI", "Host layout is null", null);
                    u.showToast("UI初始化失败: 无法获取宿主布局，请检查 MT 版本兼容性");
                }
            } catch (Exception ignored) {
                outer.log.e("UI", "Layout injection failed", ignored);
                u.showToast("UI初始化异常: " + ignored.getMessage());
            }
            
            // 增加导出按钮
            w.LiquidDialog db = new w.LiquidDialog(u).setTitle("AI文本分析助手").setPadding(0, 0, 0, 0).setView(container).setNeutralButton("退出", (x, y) -> c()).setPositiveButton("导出", (x, y) -> {
                // 导出当前对话为 HTML
                try {
                     File dir = new File("/sdcard/MT2/MT_AI/Exports");
                     dir.mkdirs();
                     String topic = outer.h.getTopic(outer.currentSid);
                     if(topic == null || topic.isEmpty()) topic = "Chat";
                     File file = new File(dir, topic.replaceAll("[\\\\/:*?\"<>|]", "_") + "_" + System.currentTimeMillis() + ".html");
                     String html = generateStaticHtml(outer.currentTree, topic, outer.getContext());
                     new FileOutputStream(file).write(html.getBytes(StandardCharsets.UTF_8));
                     u.showToast("已导出至: " + file.getAbsolutePath());
                     // 重新显示对话框，因为点击按钮会关闭
                     h.postDelayed(() -> s(), 100);
                } catch(Exception e) {
                    outer.log.e("IO", "Export failed", e);
                    u.showToast("导出失败: " + e.getMessage());
                }
            });
            if (outer.isHistoryDetail) {
                db.setNegativeButton("删除", (x, y) -> {
                    new w.LiquidDialog(u).setTitle("确认").setMessage("确定删除该对话？此操作不可恢复。").setPositiveButton("删除", (dd, ww) -> {
                        try {
                            String sid = outer.currentSid;
                            if (sid != null) outer.h.d(sid);
                            outer.currentSid = null;
                            outer.currentTree = new ArrayList<>();
                            outer.isHistoryDetail = false;
                            u.showToast("已删除");
                            h.postDelayed(() -> outer.h(u), 100);
                        } catch (Exception e) {
                            u.showToast("删除失败: " + e.getMessage());
                            outer.log.e("DB", "Delete session failed", e);
                            outer.isHistoryDetail = false;
                            h.postDelayed(() -> s(), 100);
                        }
                    }).setNegativeButton("取消", (dd, ww) -> {
                        h.postDelayed(() -> s(), 100);
                    }).show();
                });
            }
            d = db.setCancelable(false).show();
            
            try {
                android.app.Dialog rd = getInternalDialog(d);
                if (rd != null && rd.getWindow() != null) {
                    rd.getWindow().setLayout(-1, lockHeight);
                }
            } catch (Exception ignored) {
                 outer.log.e("UI", "Dialog window resize failed", ignored);
            }
            initHtml();
        }
        
        // 读取 Asset 为 Base64
        String getAssetAsBase64(String name) {
            return getAssetAsBase64(outer.getContext(), name);
        }

        static String getAssetAsBase64(PluginContext c, String name) {
            try (InputStream is = c.getAssetsAsStream(name)) {
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                byte[] b = new byte[4096];
                int r;
                while ((r = is.read(b)) != -1) os.write(b, 0, r);
                return Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) { 
                new L(c).e("IO", "Read Asset failed: " + name, e);
                return ""; 
            }
        }

        void initHtml() {
            boolean dk = u.isDarkTheme();
            String aiB = dk ? "#2C2C2C" : "#FFFFFF", usrB = dk ? "#005FB8" : "#0078D4", txtC = dk ? "#E0E0E0" : "#333333";
            String imgA = "data:image/png;base64," + getAssetAsBase64(outer.getContext(), "A.png");
            String imgU = "data:image/png;base64," + getAssetAsBase64(outer.getContext(), "U.png");
            String imgD = "data:image/png;base64," + getAssetAsBase64(outer.getContext(), "D.png");
            String imgR = "data:image/png;base64," + getAssetAsBase64(outer.getContext(), "R.png");
            
            // JS & CSS Libraries
            String markedUrl = getJsUrl("marked.min.js", "https://cdn.jsdelivr.net/npm/marked/marked.min.js");
            String hljsUrl = getJsUrl("highlight.min.js", "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js");
            String mermaidUrl = getJsUrl("mermaid.min.js", "https://cdn.jsdelivr.net/npm/mermaid@10.6.1/dist/mermaid.min.js");
            
            String hljsCss = dk ? "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css" : "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css";

            String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=no'>" + 
             "<link rel='stylesheet' href='" + hljsCss + "'>" +
             "<script src='" + markedUrl + "'></script>" +
             "<script src='" + hljsUrl + "'></script>" +
             "<script src='" + mermaidUrl + "'></script>" +
             "<style>" + 
             "html, body{ background-color: transparent; margin:0; padding:0; height:100%; overflow:hidden; font-family: -apple-system, sans-serif; }" + 
             "#chat-area{ height:100%; overflow-y:auto; padding: 10px; box-sizing:border-box; scroll-behavior: smooth; }" + 
             ".msg-row{ display: flex; flex-direction: column; margin-bottom: 10px; width: 100%; }" + 
             ".avatar{ width:32px; height:32px; border-radius:50%; margin-bottom:4px; box-shadow:0 2px 4px rgba(0,0,0,0.1); background-size: cover; background-position: center; }" + 
             ".ai .avatar, .assistant .avatar{ align-self: flex-start; background-image: url(" + imgA + "); }" + 
             ".user .avatar{ align-self: flex-end; background-image: url(" + imgU + "); }" + 
             ".msg-body{ display:flex; flex-direction: column; max-width: 100%; box-sizing: border-box; }" + 
             ".ai .msg-body, .assistant .msg-body{ align-self: flex-start; }" + 
             ".user .msg-body{ align-self: flex-end; }" + 
             ".bubble{ max-width: 100%; padding:8px 12px; border-radius:12px; font-size:13px; line-height:1.5; color:"+txtC+"; box-shadow:0 1px 3px rgba(0,0,0,0.05); word-wrap:break-word; overflow-wrap: break-word; box-sizing: border-box; position:relative; margin: 0; }" + 
             ".ai .bubble, .assistant .bubble{ background:"+aiB+"; border-top-left-radius: 2px; }" + 
             ".user .bubble{ background:"+usrB+"; align-self: flex-end; color:#FFFFFF; border-top-right-radius: 2px; }" + 
             ".think-container{ background: rgba(128,128,128,0.08); border-left: 3px solid #888; padding: 8px; margin: 6px 0; border-radius: 4px; }" + 
             ".think-title{ font-size: 10px; color: #888; font-weight: bold; margin-bottom: 4px; display: flex; align-items: center; }" + 
             ".think-title::before{ content:''; display:inline-block; width:6px; height:6px; background:#888; border-radius:50%; margin-right:4px; }" + 
             ".think-content{ font-size: 12px; color: #777; font-style: italic; line-height: 1.4; }" + 
             "pre{ background:rgba(0,0,0,0.06); padding:8px; border-radius:6px; overflow-x:auto; margin: 6px 0; max-width: 100%; box-sizing: border-box; position: relative; } code{ font-size:11px; font-family: Menlo, Monaco, Consolas, monospace; }" + 
             ".copy-btn { position: absolute; top: 4px; right: 4px; cursor: pointer; opacity: 0.6; background: rgba(128,128,128,0.2); border-radius: 4px; padding: 2px 6px; font-size: 10px; color: #888; user-select: none; } .copy-btn:hover { opacity: 1; background: rgba(128,128,128,0.4); }" +
             ".usage-info{ font-size:10px; color:#999; margin-top:4px; width:100%; display:flex; flex-direction:column; gap:6px; }" + 
             ".usage-bar{ width:100%; display:flex; align-items:center; justify-content:flex-end; gap: 6px; }" + 
             ".ai .usage-bar, .assistant .usage-bar{ justify-content: space-between; }" + 
             ".usage-left{ display:flex; align-items:center; justify-content:flex-start; min-width:0; }" + 
             ".usage-right{ display:flex; align-items:center; justify-content:flex-end; gap:6px; }" + 
             ".icon-btn { cursor:pointer; width: 16px; height: 16px; display: inline-block; background-size: contain; background-repeat: no-repeat; opacity: 0.6; transition: opacity 0.2s; }" +
             ".icon-btn:active { transform: scale(0.9); opacity: 1; }" +
             ".btn-del { background-image: url(" + imgD + "); }" +
             ".btn-regen { background-image: url(" + imgR + "); }" +
             ".branch-ctrl { display:flex; align-items:center; gap:6px; font-size:11px; color:#888; background: rgba(0,0,0,0.05); padding: 2px 5px; border-radius: 8px; }" +
             ".branch-btn { cursor:pointer; padding:2px 4px; font-weight: bold; }" +
             ".tokens { font-size: 9px; color: #999; font-style: italic; }" +
             ".topic-box { text-align: center; margin-bottom: 15px; }" +
             ".topic-content { display: inline-block; background: rgba(0,0,0,0.05); padding: 4px 12px; border-radius: 12px; font-size: 12px; color: #888; font-weight: bold; }" +
             ".mermaid { background: white; padding: 10px; border-radius: 8px; margin: 10px 0; }" +
             "pre { position: relative; z-index: 1; }" + // Ensure pre has z-index
             ".copy-btn { position: absolute; top: 4px; right: 4px; cursor: pointer; opacity: 0.8; background: rgba(128,128,128,0.3); border-radius: 4px; padding: 4px 8px; font-size: 10px; color: #666; user-select: none; z-index: 10; pointer-events: auto; }" + // Enhance button style and z-index
             ".copy-btn:hover { opacity: 1; background: rgba(128,128,128,0.5); }" +
             (isFloating ? ".copy-btn { display: none !important; }" : "") +
             "</style><script>" + 
             "var lastRole='', currentRaw='', autoScroll=true;" + 
             "function initScroll() { var c=document.getElementById('chat-area'); c.addEventListener('scroll', function(){ autoScroll = (c.scrollHeight - c.scrollTop - c.clientHeight) < 50; }); }" + 
             "window.onload = function() { initScroll(); mermaid.initialize({ startOnLoad: false, theme: '" + (dk ? "dark" : "default") + "' }); };" + 
             "window.onerror = function(msg, url, line) { sendCmd('log', '0', 'JS Error: '+msg); };" +
             "function copyCode(btn) { try { var code = btn.nextElementSibling ? btn.nextElementSibling.innerText : ''; sendCmd('log', '0', 'Copying code length: ' + code.length); sendCmd('copy', '0', encodeURIComponent(code)); } catch(e) { sendCmd('log', '0', 'Copy error: ' + e.message); } }" +
             "function simpleMD(t) { if(!t)return ''; return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/```([\\s\\S]*?)```/g,'<pre><div class=\"copy-btn\" onclick=\"copyCode(this)\">复制</div><code>$1</code></pre>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\\*\\*([^*]+)\\*\\*/g,'<strong>$1</strong>').replace(/\\n/g,'<br>'); }" +
             "if (typeof marked === 'undefined') { window.marked = { parse: simpleMD }; }" +
             "function sendCmd(cmd, id, extra) { prompt('cmd:'+cmd+':'+id+(extra?':'+extra:'')); }" +
             "function render(nodes) {" +
             "  var container = document.getElementById('chat-area');" +
             "  var existingRows = container.children;" +
             "  var newNodes = nodes.filter(function(n){ return n.role !== 'system'; });" +
             "  if(existingRows.length !== newNodes.length) {" +
             "     container.innerHTML = '';" +
             "     newNodes.forEach(function(n, idx){ appendNode(container, n, idx); });" +
             "     if(autoScroll) container.scrollTop = container.scrollHeight;" +
             "  } else {" +
             "     for(var i=0; i<newNodes.length; i++) {" +
             "        var n = newNodes[i];" +
             "        var row = existingRows[i];" +
             "        if(row.getAttribute('data-id') !== n.id) {" +
             "            container.innerHTML = '';" +
             "            newNodes.forEach(function(x, idx){ appendNode(container, x, idx); });" +
             "            if(autoScroll) container.scrollTop = container.scrollHeight;" +
             "            return;" +
             "        }" +
             "        updateNode(row, n, i);" +
             "     }" +
             "  }" +
             "  initLibs();" +
             "}" +
             "function appendNode(container, n, idx) {" +
             "    var row = document.createElement('div');" +
             "    row.className = 'msg-row ' + n.role;" +
             "    row.setAttribute('data-id', n.id);" +
             "    row.innerHTML = buildRowHtml(n, idx);" +
             "    container.appendChild(row);" +
             "    renderContent(row, n);" +
             "}" +
             "function updateNode(row, n, idx) {" +
             "    var bubble = row.querySelector('.bubble');" +
             "    var currentContent = bubble.getAttribute('data-content');" +
             "    var currentReasoning = bubble.getAttribute('data-reasoning');" +
             "    if(currentContent !== n.content || currentReasoning !== (n.reasoning || '')) {" +
             "        renderContent(row, n);" +
             "    }" +
             "    var usageInfo = row.querySelector('.usage-info');" +
             "    var newUsageHtml = buildUsageHtml(n, idx);" +
             "    if(usageInfo.innerHTML !== newUsageHtml) usageInfo.innerHTML = newUsageHtml;" +
             "}" +
             "function tokensHtml(pt, ct, tt) {" +
             "    pt = (pt || 0); ct = (ct || 0); tt = (tt || 0);" +
             "    return 'tokens: 提问: <b>' + pt + '</b> 回答: <b>' + ct + '</b> 总共: <b>' + tt + '</b>';" +
             "}" +
             "function buildUsageHtml(n, idx) {" +
             "    var branchCtrl = '';" +
             "    if(n.childCount > 1) { branchCtrl = '<div class=\"branch-ctrl\"><span class=\"branch-btn\" onclick=\"sendCmd(\\'switch\\',\\''+n.id+'\\',\\'prev\\')\">&lt;</span> '+ (n.idx+1) + '/' + n.childCount + ' <span class=\"branch-btn\" onclick=\"sendCmd(\\'switch\\',\\''+n.id+'\\',\\'next\\')\">&gt;</span></div>'; }" +
             "    var left = '';" +
             "    var right = '';" +
             "    if(n.role === 'user') {" +
             "        if(idx > 0) right = '<span class=\"icon-btn btn-del\" onclick=\"sendCmd(\\'del\\',\\''+n.id+'\\')\"></span>';" +
             "    } else {" +
             "        if(n.tt > 0) left = '<span class=\"tokens\">' + tokensHtml(n.pt, n.ct, n.tt) + '</span>';" +
             "        right = '<span class=\"icon-btn btn-regen\" onclick=\"sendCmd(\\'regen\\',\\''+n.id+'\\')\"></span><span class=\"icon-btn btn-del\" onclick=\"sendCmd(\\'del\\',\\''+n.id+'\\')\"></span>';" +
             "    }" +
             "    var bar = '<div class=\"usage-bar\"><span class=\"usage-left\">'+left+'</span><span class=\"usage-right\">'+right+'</span></div>';" +
             "    return branchCtrl + bar;" +
             "}" +
             "function buildRowHtml(n, idx) {" +
             "    var avatar = '<div class=\"avatar\"></div>';" +
             "    var bubble = '<div class=\"bubble\" data-content=\"\" data-reasoning=\"\"></div>';" +
             "    var usage = '<div class=\"usage-info\">' + buildUsageHtml(n, idx) + '</div>';" +
             "    var body = '<div class=\"msg-body\">' + bubble + usage + '</div>';" +
             "    return avatar + body;" +
             "}" +
             "function renderContent(row, n) {" +
             "    var b = row.querySelector('.bubble');" +
             "    var content = n.content || '...';" +
             "    b.setAttribute('data-content', content);" +
             "    b.setAttribute('data-reasoning', n.reasoning || '');" +
             "    var html = '';" +
             "    var cleanContent = content;" +
             "    var topicMatch = content.match(/^(?:Topic:|\\*\\*Topic\\*\\*:?)\\s*(.+)$/m);" +
             "    if(topicMatch && topicMatch.index === 0) {" +
             "        var topic = topicMatch[1];" +
             "        var topicDiv = document.createElement('div');" +
             "        topicDiv.className = 'topic-box';" +
             "        topicDiv.innerHTML = '<span class=\"topic-content\">Topic: ' + topic + '</span>';" +
             "        if(!row.querySelector('.topic-box')) row.insertBefore(topicDiv, row.firstChild);" +
             "        cleanContent = content.substring(topicMatch[0].length).trim();" +
             "    }" +
             "    if(n.reasoning && n.reasoning.length > 0) {" +
             "        html += '<div class=\"think-container\"><div class=\"think-title\">思考过程</div><div class=\"think-content\">' + escapeHtml(n.reasoning) + '</div></div>';" +
             "    }" +
             "    try { html += marked.parse(cleanContent); } catch(e) { html += simpleMD(cleanContent); }" +
             "    b.innerHTML = html;" +
             "}" +
             "function initLibs() {" +
             "   try { hljs.highlightAll(); } catch(e){}" +
             "   try { addCopyButtons(); } catch(e){}" +
             "   try { mermaid.run({querySelector: '.language-mermaid'}); } catch(e){}" +
             "}" +
             "function addCopyButtons() {" +
             "   var pres = document.querySelectorAll('pre');" +
             "   for(var i=0; i<pres.length; i++) {" +
             "       var pre = pres[i];" +
             "       if(pre.querySelector('.copy-btn')) continue;" +
             "       var btn = document.createElement('div');" +
             "       btn.className = 'copy-btn';" +
             "       btn.innerText = '复制';" +
             "       btn.onclick = function() { copyCode(this); };" +
             "       pre.insertBefore(btn, pre.firstChild);" +
             "   }" +
             "}" +
             "function escapeHtml(text) {" +
             "  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\"/g, '&quot;').replace(/'/g, '&#039;');" +
             "}" +
             "function stream(id, dContent, dReasoning, tokens) {" +
             "   var row = document.querySelector('.msg-row[data-id=\"'+id+'\"]');" +
             "   if(!row) return;" +
             "   var b = row.querySelector('.bubble');" +
             "   var c = b.getAttribute('data-content') || '';" +
             "   var r = b.getAttribute('data-reasoning') || '';" +
             "   if(dContent) c += decodeURIComponent(escape(window.atob(dContent)));" +
             "   if(dReasoning) r += decodeURIComponent(escape(window.atob(dReasoning)));" +
             "   b.setAttribute('data-content', c);" +
             "   b.setAttribute('data-reasoning', r);" +
             "   var html = '';" +
             "   var cleanContent = c;" +
             "   var topicMatch = c.match(/^(?:Topic:|\\*\\*Topic\\*\\*:?)\\s*(.+)$/m);" +
             "   if(topicMatch && topicMatch.index === 0) {" +
             "        var topic = topicMatch[1];" +
             "        if(!row.querySelector('.topic-box')) {" +
             "             var topicDiv = document.createElement('div');" +
             "             topicDiv.className = 'topic-box';" +
             "             topicDiv.innerHTML = '<span class=\"topic-content\">Topic: ' + topic + '</span>';" +
             "             row.insertBefore(topicDiv, row.firstChild);" +
             "        }" +
             "        cleanContent = c.substring(topicMatch[0].length).trim();" +
             "   }" +
             "   if(r.length > 0) html += '<div class=\"think-container\"><div class=\"think-title\">思考过程</div><div class=\"think-content\">' + escapeHtml(r) + '</div></div>';" +
             "   try { html += marked.parse(cleanContent); } catch(e) { html += simpleMD(cleanContent); }" +
             "   b.innerHTML = html;" +
             "   if(tokens) {" +
             "       var u = row.querySelector('.usage-info');" +
             "       var pt = 0, ct = 0, tt = 0;" +
             "       try { var parts = String(tokens).split('/'); pt = parseInt(parts[0]||'0'); ct = parseInt(parts[1]||'0'); tt = parseInt(parts[2]||'0'); } catch(e) {}" +
             "       var tSpan = u.querySelector('.tokens');" +
             "       if(!tSpan) {" +
             "           var left = u.querySelector('.usage-left');" +
             "           if(!left) {" +
             "               u.innerHTML = '<div class=\"usage-bar\"><span class=\"usage-left\"></span><span class=\"usage-right\"></span></div>';" +
             "               left = u.querySelector('.usage-left');" +
             "           }" +
             "           tSpan = document.createElement('span');" +
             "           tSpan.className = 'tokens';" +
             "           left.appendChild(tSpan);" +
             "       }" +
             "       tSpan.innerHTML = tokensHtml(pt, ct, tt);" +
             "   }" +
             "   initLibs();" +
             "   if(autoScroll) document.getElementById('chat-area').scrollTop = document.getElementById('chat-area').scrollHeight;" +
             "}" +
             "</script></head><body><div id='chat-area'></div></body></html>";
            
            webView.setWebChromeClient(new WebChromeClient() {
                public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                    if (message.startsWith("cmd:")) {
                        String[] parts = message.split(":", 4);
                        if (parts.length >= 3) {
                            String cmd = parts[1];
                            String id = parts[2];
                            String extra = parts.length > 3 ? parts[3] : null;
                            handleCmd(cmd, id, extra);
                        } else if (parts.length > 1 && parts[1].equals("log")) {
                             if(parts.length > 2 && outer.log != null) outer.log.d("WebView", parts[2]);
                        }
                        result.confirm();
                        return true;
                    }
                    return false;
                }
            });
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) { isLoaded = true; updateTree(); }
            });
            webView.loadDataWithBaseURL("https://chat.ai", html, "text/html", "utf-8", null);
        }

        String getJsUrl(String name, String cdn) {
            try {
                File dir = new File(outer.getContext().getFilesDir(), "js_cache");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, name);
                if (f.exists() && f.length() > 0) return "file://" + f.getAbsolutePath();
                
                new Thread(() -> downloadJs(cdn, f)).start();
            } catch (Exception e) {
                if(outer.log != null) outer.log.e("IO", "JS Cache check failed", e);
            }
            return cdn;
        }

        void downloadJs(String url, File f) {
            try {
                okhttp3.Request req = new okhttp3.Request.Builder().url(url).build();
                try (okhttp3.Response res = cail.O.getHttpClient().newCall(req).execute()) {
                    if (res.isSuccessful() && res.body() != null) {
                        try (FileOutputStream fos = new FileOutputStream(f)) {
                            fos.write(res.body().bytes());
                        }
                    }
                }
            } catch (Exception e) {
                if(outer.log != null) outer.log.e("IO", "JS Download failed: " + url, e);
            }
        }

        void handleCmd(String cmd, String id, String extra) {
            h.post(() -> {
                synchronized(outer) {
                    if ("copy".equals(cmd)) {
                         try {
                             if(outer.log != null) outer.log.d("UI", "Copy request received: " + (extra != null ? extra.length() : 0) + " chars");
                             String text = extra != null ? java.net.URLDecoder.decode(extra, "UTF-8") : "";
                             
                             boolean success = false;
                             try {
                                Object ctxObj = outer.getContext();
                                Context ctx = null;
                                if (ctxObj instanceof Context) ctx = (Context) ctxObj;
                                else if (ctxObj instanceof ContextWrapper) ctx = ((ContextWrapper)ctxObj).getBaseContext();
                                
                                // Priority: Floating Window View Context (as it might be active)
                                if (FloatingManager.instance != null && FloatingManager.instance.chatView != null) {
                                    ctx = FloatingManager.instance.chatView.getContext();
                                }
                                // Fallback: Global Context
                                if (ctx == null) ctx = outer.getGlobalContext();

                                if (ctx != null) {
                                    android.content.ClipboardManager cm = (android.content.ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                                    if (cm != null) {
                                        // Fix: Only clear identity if NOT in floating window mode (or if ctx is not from floating window)
                                        // If ctx came from FloatingManager (which has focus now), we should NOT clear identity.
                                        boolean isFloating = (FloatingManager.instance != null && FloatingManager.instance.chatView != null && ctx == FloatingManager.instance.chatView.getContext());
                                        long token = -1;
                                        if (!isFloating) {
                                            token = android.os.Binder.clearCallingIdentity();
                                        }
                                        try {
                                            android.content.ClipData clip = android.content.ClipData.newPlainText("AI Code", text);
                                            cm.setPrimaryClip(clip);
                                            success = true;
                                            if(outer.log != null) outer.log.d("UI", "Clipboard set via SystemService (Floating: " + isFloating + ")");
                                        } catch(Exception e) {
                                            if(outer.log != null) outer.log.e("UI", "Clipboard setPrimaryClip failed", e);
                                        } finally {
                                            if (token != -1) {
                                                android.os.Binder.restoreCallingIdentity(token);
                                            }
                                        }
                                    }
                                }
                            } catch (Throwable ex) {
                                if(outer.log != null) outer.log.e("UI", "Sys clipboard context failed", ex);
                            }
                             
                             if (!success) {
                                 // Fallback: Plugin API
                                 try {
                                     outer.getContext().setClipboardText(text);
                                     success = true;
                                     if(outer.log != null) outer.log.d("UI", "Clipboard set via PluginAPI");
                                 } catch (Exception e) {
                                     if(outer.log != null) outer.log.e("UI", "Plugin clipboard failed", e);
                                 }
                             }
                             
                             if (success) u.showToast("已复制到剪贴板");
                             else u.showToast("复制失败: 无法访问剪贴板");
                         } catch (Exception e) {
                             if(outer.log != null) outer.log.e("UI", "Copy flow failed", e);
                             u.showToast("复制异常: " + e.getMessage());
                         }
                         return;
                    }

                    Node target = outer.findNode(id);
                    if (target == null) return;
                    
                    if ("del".equals(cmd)) {
                        if (target.parentId != null) {
                            Node parent = outer.findNode(target.parentId);
                            if (parent != null) {
                                parent.children.remove(target);
                                if (parent.selectIndex >= parent.children.size()) parent.selectIndex = Math.max(0, parent.children.size() - 1);
                            }
                        } else {
                            outer.currentTree.remove(target);
                        }
                        updateTree();
                        outer.save();
                    } else if ("switch".equals(cmd)) {
                        // 分支切换逻辑
                        if (target.parentId != null) {
                            Node parent = outer.findNode(target.parentId);
                            if (parent != null) {
                                if ("prev".equals(extra)) parent.selectIndex = (parent.selectIndex - 1 + parent.children.size()) % parent.children.size();
                                else parent.selectIndex = (parent.selectIndex + 1) % parent.children.size();
                                updateTree();
                            }
                        }
                    } else if ("regen".equals(cmd)) {
                         if("assistant".equals(target.role)) {
                             outer.regenerate(P.this, target);
                         }
                    }
                }
            });
        }
        
        void updateTree() {
            if (!isLoaded || webView == null) return;
            try {
                List<Node> flat = outer.flatten(outer.currentTree);
                JSONArray arr = new JSONArray();
                for (Node n : flat) {
                    JSONObject j = n.toJson();
                    if (n.parentId != null) {
                         Node parent = outer.findNode(n.parentId);
                         if (parent != null) {
                             j.put("childCount", parent.children.size());
                             j.put("idx", parent.children.indexOf(n));
                         }
                    } else {
                        j.put("childCount", 0);
                        j.put("idx", 0);
                    }
                    arr.put(j);
                }
                String json = arr.toString();
                String b64 = Base64.encodeToString(json.getBytes("UTF-8"), Base64.NO_WRAP);
                webView.evaluateJavascript("render(JSON.parse(decodeURIComponent(escape(window.atob('" + b64 + "')))))", null);
            } catch (Exception ignored) {
                if(outer.log != null) outer.log.e("UI", "UpdateTree failed", ignored);
            }
        }

        // 流式更新内容
        void u(String t, String targetId) { 
             Node target;
             if (targetId != null) target = outer.findNode(targetId);
             else target = outer.findLastNode();
             
             if(target != null && "assistant".equals(target.role)) {
                 if(target.content == null) target.content = "";
                 target.content += t;
                 if(isLoaded && webView != null) {
                     String b64 = Base64.encodeToString(t.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                     webView.evaluateJavascript("stream('" + target.id + "', '" + b64 + "', null, null)", null);
                 }
             }
        }

        // 流式更新思考内容
        void uReasoning(String t, String targetId) { 
             Node target;
             if (targetId != null) target = outer.findNode(targetId);
             else target = outer.findLastNode();
             
             if(target != null && "assistant".equals(target.role)) {
                 if(target.reasoning == null) target.reasoning = "";
                 target.reasoning += t;
                 if(isLoaded && webView != null) {
                     String b64 = Base64.encodeToString(t.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                     webView.evaluateJavascript("stream('" + target.id + "', null, '" + b64 + "', null)", null);
                 }
             }
        }
        
        // 更新 Token 统计
        void uTokens(int p, int c, int t, String targetId) {
            Node target;
            if (targetId != null) target = outer.findNode(targetId);
            else target = outer.findLastNode();
            
            if (target != null) {
                target.promptTokens = p;
                target.completionTokens = c;
                target.totalTokens = t;
                if(isLoaded && webView != null) {
                    String tokens = p+"/"+c+"/"+t;
                    webView.evaluateJavascript("stream('" + target.id + "', null, null, '" + tokens + "')", null);
                }
            }
        }

        void p() {}

        void c() {
            isCancelled = true;
            h.removeCallbacksAndMessages(null);
            if (webView != null) {
                try {
                    ViewParent vp = webView.getParent();
                    if (vp instanceof ViewGroup) ((ViewGroup) vp).removeView(webView);
                    webView.stopLoading();
                    webView.clearHistory();
                    webView.loadUrl("about:blank");
                    webView.destroy();
                } catch (Exception ignored) {
                    new L(outer.getContext()).e("UI", "Cleanup failed", ignored);
                }
                webView = null;
            }
            if (d != null) { d.dismiss(); d = null; }
            if (onCancel != null) onCancel.run();
        }
        
        /**
         * 生成静态 HTML 文件
         * @param roots 对话树根节点列表
         * @param title 标题
         * @param c 插件上下文
         * @return HTML 字符串
         */
        public static String generateStaticHtml(List<Node> roots, String title, PluginContext c) {
             JSONArray arr = new JSONArray();
             try {
                 for(Node n : roots) arr.put(n.toJson());
             } catch(Exception e) {
                 new L(c).e("IO", "Gen HTML failed", e);
             }
             String jsonB64 = Base64.encodeToString(arr.toString().getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
             
             String imgA = "data:image/png;base64," + getAssetAsBase64(c, "A.png");
             String imgU = "data:image/png;base64," + getAssetAsBase64(c, "U.png");
             
             StringBuilder sb = new StringBuilder();
             sb.append("<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'><title>").append(title).append("</title>");
             sb.append("<script src='https://cdn.jsdelivr.net/npm/marked/marked.min.js'></script>");
             sb.append("<style>");
             sb.append("body{background:#F2F2F2;margin:0;padding:20px;font-family:-apple-system,sans-serif;}");
             sb.append("#chat-area{max-width:800px;margin:0 auto;}");
             sb.append(".msg-row{display:flex;flex-direction:column;margin-bottom:10px;width:100%;}");
             sb.append(".avatar{width:32px;height:32px;border-radius:50%;margin-bottom:4px;box-shadow:0 2px 4px rgba(0,0,0,0.1);background-size:cover;background-position:center;}");
             sb.append(".ai .avatar,.assistant .avatar{align-self:flex-start;background-image:url(").append(imgA).append(");}");
             sb.append(".user .avatar{align-self:flex-end;background-image:url(").append(imgU).append(");}");
             sb.append(".bubble{max-width:100%;padding:8px 12px;border-radius:12px;font-size:13px;line-height:1.5;color:#333;box-shadow:0 1px 3px rgba(0,0,0,0.05);word-wrap:break-word;position:relative;margin:0;background:#FFF;}");
             sb.append(".ai .bubble,.assistant .bubble{align-self:flex-start;border-top-left-radius:2px;}");
             sb.append(".user .bubble{background:#0078D4;align-self:flex-end;color:#FFFFFF;border-top-right-radius:2px;}");
             sb.append(".think-container{background:rgba(128,128,128,0.08);border-left:3px solid #888;padding:8px;margin:6px 0;border-radius:4px;}");
             sb.append(".think-title{font-size:10px;color:#888;font-weight:bold;margin-bottom:4px;}");
             sb.append(".think-content{font-size:12px;color:#777;font-style:italic;line-height:1.4;}");
             sb.append(".branch-ctrl{display:flex;align-items:center;gap:6px;font-size:11px;color:#888;background:rgba(0,0,0,0.05);padding:2px 5px;border-radius:8px;margin-top:5px;align-self:flex-start;}");
             sb.append(".branch-btn{cursor:pointer;padding:2px 4px;font-weight:bold;}");
             sb.append(".usage-info{font-size:10px;color:#999;margin-top:4px;display:flex;align-items:center;justify-content:flex-end;}");
             sb.append(".assistant .usage-info,.ai .usage-info{justify-content:flex-start;}");
             sb.append(".tokens{font-size:9px;color:#999;font-style:italic;}");
             sb.append(".topic-box{text-align:center;margin-bottom:15px;}");
             sb.append(".topic-content{display:inline-block;background:rgba(0,0,0,0.05);padding:4px 12px;border-radius:12px;font-size:12px;color:#888;font-weight:bold;}");
             sb.append("pre{background:rgba(0,0,0,0.06);padding:8px;border-radius:6px;overflow-x:auto;margin:6px 0;}code{font-size:11px;font-family:Menlo,Monaco,Consolas,monospace;}");
             sb.append("</style>");
             sb.append("<script>");
             sb.append("var rawData='").append(jsonB64).append("';");
             sb.append("var roots=[]; try{roots=JSON.parse(decodeURIComponent(escape(window.atob(rawData))));}catch(e){}");
             sb.append("function simpleMD(t){if(!t)return '';return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/```([\\s\\S]*?)```/g,'<pre><code>$1</code></pre>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\\*\\*([^*]+)\\*\\*/g,'<strong>$1</strong>').replace(/\\n/g,'<br>');}");
             sb.append("if(typeof marked==='undefined'){window.marked={parse:simpleMD};}");
             sb.append("function escapeHtml(text){return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#039;');}");
             sb.append("function flatten(nodes){var list=[];if(!nodes||nodes.length===0)return list;var curr=nodes[0];while(curr){list.push(curr);if(!curr.children||curr.children.length===0)break;var idx=curr.selectIndex||0;if(idx>=curr.children.length)idx=0;curr=curr.children[idx];}return list;}");
             sb.append("function findNode(nodes,id){for(var i=0;i<nodes.length;i++){if(nodes[i].id===id)return nodes[i];if(nodes[i].children){var f=findNode(nodes[i].children,id);if(f)return f;}}return null;}");
             sb.append("function switchBranch(id,dir){var n=findNode(roots,id);if(n&&n.parentId){var p=findNode(roots,n.parentId);if(p){if(dir==='prev')p.selectIndex=(p.selectIndex-1+p.children.length)%p.children.length;else p.selectIndex=(p.selectIndex+1)%p.children.length;render();}}}");
             sb.append("function render(){var list=flatten(roots);var c=document.getElementById('chat-area');c.innerHTML='';list.forEach(function(n){if(n.role==='system')return;appendNode(c,n);});}");
             sb.append("function tokensText(pt,ct,tt){pt=(pt||0);ct=(ct||0);tt=(tt||0);return 'tokens: 提问: '+pt+' 回答: '+ct+' 总共: '+tt;}");
             sb.append("function appendNode(c,n){var row=document.createElement('div');row.className='msg-row '+n.role;var h='';h+='<div class=\"avatar\"></div>';h+='<div class=\"bubble\">'+renderContent(n)+'</div>';if(n.role!=='user'){h+='<div class=\"usage-info\"><span class=\"tokens\">'+tokensText(n.pt,n.ct,n.tt)+'</span></div>';}if(n.parentId){var p=findNode(roots,n.parentId);if(p&&p.children.length>1){h+='<div class=\"branch-ctrl\"><span class=\"branch-btn\" onclick=\"switchBranch(\\''+n.id+'\\',\\'prev\\')\">&lt;</span> '+(p.children.indexOf(n)+1)+'/'+p.children.length+' <span class=\"branch-btn\" onclick=\"switchBranch(\\''+n.id+'\\',\\'next\\')\">&gt;</span></div>';}}row.innerHTML=h;c.appendChild(row);}");
             sb.append("function renderContent(n){var c=n.content||'...';var h='';var topicMatch=c.match(/^(?:Topic:|\\*\\*Topic\\*\\*:?)\\s*(.+)$/m);if(topicMatch&&topicMatch.index===0){h+='<div class=\"topic-box\"><span class=\"topic-content\">Topic: '+topicMatch[1]+'</span></div>';c=c.substring(topicMatch[0].length).trim();}if(n.reasoning){h+='<div class=\"think-container\"><div class=\"think-title\">思考过程</div><div class=\"think-content\">'+escapeHtml(n.reasoning)+'</div></div>';}try{h+=marked.parse(c);}catch(e){h+=simpleMD(c);}return h;}");
             sb.append("window.onload=render;");
             sb.append("</script></head><body><div id='chat-area'></div></body></html>");
             return sb.toString();
        }
    }
    
    /**
     * 重新回答逻辑
     * 创建新的分支节点，而不是覆盖
     */
    void regenerate(P p, Node target) {
         if(!c.compareAndSet(false, true)) { p.u.showToast("忙..."); return; }
         
         Node parent = findNode(target.parentId);
         if (parent != null) {
             // 创建新节点
             Node newNode = new Node(UUID.randomUUID().toString(), "assistant", "...", parent.id);
             parent.children.add(newNode);
             parent.selectIndex = parent.children.size() - 1; // 切换到新分支
             p.updateTree();
             
             // 发起请求
             String k = g(getContext());
             R r = new R(p.u, "", "", currentSid, k, p, newNode.id);
             E.execute(r);
         } else {
             // 如果没有父节点（理论上不可能，除非是根节点），回退到覆盖模式
             target.content = "...";
             target.reasoning = "";
             target.promptTokens = 0;
             target.completionTokens = 0;
             target.totalTokens = 0;
             p.updateTree();
             String k = g(getContext());
             R r = new R(p.u, "", "", currentSid, k, p, target.id);
             E.execute(r);
         }
    }

    // 新增：系统悬浮窗入口
    public void startSystemFloating(Context ctx) {
        FloatingManager.show(ctx, this);
    }
    
    public void stopSystemFloating() {
        if(FloatingManager.instance != null) FloatingManager.instance.close();
    }

    /**
     * 简单对话框辅助类 D
     */
    static class D {
        interface I {
            void y(String t, boolean n);
            void n();
        }
        static void a(PluginUI i, String s, String u, I c) {
            String d = s.length() > 50 ? s.substring(0, 50) + "..." : s;
            PluginView v = i.buildVerticalLayout().addTextView().text(d.isEmpty() ? "" : ("选中: " + d)).textSize(12).paddingVerticalDp(8).addEditText("i").text(u).hint("输入...").singleLine(false).build();
            new w.LiquidDialog(i).setTitle("AI").setView(v)
                .setPositiveButton("继续", (l, w) -> c.y(v.<PluginEditText>requireViewById("i").getText().toString(), false))
                .setNeutralButton("新对话", (l, w) -> c.y(v.<PluginEditText>requireViewById("i").getText().toString(), true))
                .setNegativeButton("取消", (l, w) -> c.n()).show();
        }
    }

    static class SimplePluginUI implements PluginUI {
        public PluginContext getContext() { return null; }
        public void showToast(CharSequence msg) {}
        public void showToast(CharSequence msg, Object... formatArgs) {}
        public void showToastL(CharSequence msg) {}
        public void showToastL(CharSequence msg, Object... formatArgs) {}
        public void cancelToast() {}
        public PluginUI disableStrictIdMode() { return this; }
        public PluginUI setStrictIdModeEnabled(boolean enabled) { return this; }
        public boolean isStrictIdModeEnabled() { return false; }
        public PluginUI defaultStyle(Style style) { return this; }
        public bin.mt.plugin.api.ui.builder.PluginRootLayoutBuilder buildHorizontalLayout() { return null; }
        public bin.mt.plugin.api.ui.builder.PluginRootLayoutBuilder buildVerticalLayout() { return null; }
        public bin.mt.plugin.api.ui.builder.PluginRootLayoutBuilder buildFrameLayout() { return null; }
        public PluginDialog.Builder buildDialog() { return null; }
        public bin.mt.plugin.api.ui.menu.PluginPopupMenu createPopupMenu(bin.mt.plugin.api.ui.PluginView anchor) { return null; }
        public void showMessage(CharSequence title, CharSequence message) {}
        public void showErrorMessage(Throwable e) {}
        public void showPreference(Class<? extends bin.mt.plugin.api.preference.PluginPreference> clazz) {}
        public boolean isDarkTheme() { return false; }
        public int colorPrimary() { return 0; }
        public int colorAccent() { return 0; }
        public int colorDivider() { return 0; }
        public int colorError() { return 0; }
        public int colorWarning() { return 0; }
        public int colorText() { return 0; }
        public int colorTextSecondary() { return 0; }
        public android.content.res.ColorStateList colorTextStateList() { return null; }
        public android.content.res.ColorStateList colorTextSecondaryStateList() { return null; }
        public int dialogPaddingHorizontal() { return 0; }
        public int dialogPaddingVertical() { return 0; }
        public Drawable selectableItemBackground() { return null; }
        public Drawable selectableItemBackgroundBorderless() { return null; }
        public int dp2px(float dp) { return 0; }
        public int sp2px(float sp) { return 0; }
        public Style getStyle() { return null; }
    }

    // 系统悬浮窗管理器
    public static class FloatingManager {
        static FloatingManager instance;
        private final Context context;
        private final WindowManager windowManager;
        private View iconView;
        private View chatView;
        private View contentRoot;
        private final O logic;
        private final PluginContext pluginContext;
        private android.webkit.WebView webView;
        private android.widget.EditText inputEdit;
        private WindowManager.LayoutParams iconParams;
        private WindowManager.LayoutParams chatParams;
        
        // Auto-snap & Transparency
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Runnable snapRunnable = this::snapToEdge;
        
        // Base dimensions for scaling
        private int baseWidth = 0;
        private int baseHeight = 0;
        
        // Chat state
        private List<Node> currentTree = new ArrayList<>();
        private String currentSid;
        private P taskP;
        
        // UI Components
        private ListView historyList;
        private FrameLayout webContainer;
        private LinearLayout inputArea;
        private ScrollView settingsView;
        
        public static void show(Context ctx, O logic) {
            if (instance == null) {
                PluginContext pc = logic.getContext();
                if (pc == null && w.weakContext != null) pc = w.weakContext.get();
                if (pc == null && ctx instanceof PluginContext) pc = (PluginContext) ctx;
                instance = new FloatingManager(ctx.getApplicationContext(), logic, pc);
            }
            instance.showIcon();
        }
        
        private FloatingManager(Context ctx, O logic, PluginContext pc) {
            this.context = ctx;
            this.logic = logic;
            this.pluginContext = pc;
            this.windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        }
        
        public void close() {
            saveChat();
            removeIcon();
            removeChat();
            instance = null;
        }

        private void removeIcon() {
            if (iconView != null) {
                try { windowManager.removeView(iconView); } catch(Exception e){
                    if(logic.log != null) logic.log.e("Float", "Remove icon failed", e);
                }
                iconView = null;
            }
        }

        private void removeChat() {
            if (chatView != null) {
                try { windowManager.removeView(chatView); } catch(Exception e){
                     if(logic.log != null) logic.log.e("Float", "Remove chat failed", e);
                }
                chatView = null;
                if (webView != null) { webView.destroy(); webView = null; }
                settingsView = null;
            }
        }
        
        public void showIcon() {
            if (iconView != null) return;
            removeChat();
            
            android.widget.ImageView iv = new android.widget.ImageView(context);
            w.LiquidGlassDrawable bg = new w.LiquidGlassDrawable(200);
            iv.setBackground(bg);
            
            // Task 9: Use A.png from assets
            try (InputStream is = pluginContext.getAssetsAsStream("A.png")) {
                Bitmap bmp = BitmapFactory.decodeStream(is);
                iv.setImageBitmap(bmp);
            } catch (Exception e) {
                Drawable dr = bin.mt.plugin.api.drawable.MaterialIcons.get("smart_toy");
                if (Build.VERSION.SDK_INT >= 21) dr.setTint(Color.DKGRAY);
                iv.setImageDrawable(dr);
                if(logic.log != null) logic.log.e("Float", "Load icon failed", e);
            }

            iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
            iv.setPadding(30, 30, 30, 30);
            
            iconView = iv;
            
            iconParams = new WindowManager.LayoutParams();
            iconParams.width = 160;
            iconParams.height = 160;
            if (Build.VERSION.SDK_INT >= 26) iconParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            else iconParams.type = WindowManager.LayoutParams.TYPE_PHONE;
            iconParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
            iconParams.format = android.graphics.PixelFormat.TRANSLUCENT;
            iconParams.gravity = Gravity.TOP | Gravity.START;
            
            // Task 10: Load saved position
            SharedPreferences sp = pluginContext.getPreferences();
            iconParams.x = sp.getInt("float_x", 0);
            iconParams.y = sp.getInt("float_y", 300);
            
            iv.setOnTouchListener(new View.OnTouchListener() {
                float initialX, initialY, initialTouchX, initialTouchY;
                long downTime;
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = iconParams.x;
                            initialY = iconParams.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            downTime = System.currentTimeMillis();
                            bg.setPressed(true);
                            
                            // Task 9: Cancel auto-snap and reset alpha
                            handler.removeCallbacks(snapRunnable);
                            v.setAlpha(1.0f);
                            
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            iconParams.x = (int) (initialX + (event.getRawX() - initialTouchX));
                            iconParams.y = (int) (initialY + (event.getRawY() - initialTouchY));
                            windowManager.updateViewLayout(iconView, iconParams);
                            return true;
                        case MotionEvent.ACTION_UP:
                            bg.setPressed(false);
                            // Task 10: Save position on release
                            pluginContext.getPreferences().edit().putInt("float_x", iconParams.x).putInt("float_y", iconParams.y).apply();
                            
                            if (System.currentTimeMillis() - downTime < 200 && Math.abs(event.getRawX() - initialTouchX) < 10) {
                                showChat();
                            } else {
                                // Task 9: Schedule auto-snap
                                handler.postDelayed(snapRunnable, 3000);
                            }
                            return true;
                    }
                    return false;
                }
            });
            
            try {
                windowManager.addView(iconView, iconParams);
                // Initial schedule
                handler.postDelayed(snapRunnable, 3000);
            } catch (Throwable e) {
                new L(pluginContext).e("Float", "Show icon failed", e);
                Toast.makeText(context, "Float Icon Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        
        // Task 9: Auto-snap implementation
        private void snapToEdge() {
            if (iconView == null) return;
            try {
                android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
                int screenWidth = dm.widthPixels;
                int centerX = iconParams.x + iconParams.width / 2;
                int targetX;
                
                if (centerX < screenWidth / 2) {
                    targetX = 0 - iconParams.width / 2; // Show half on left
                } else {
                    targetX = screenWidth - iconParams.width / 2; // Show half on right
                }
                
                // Simple animation using ValueAnimator
                ValueAnimator va = ValueAnimator.ofInt(iconParams.x, targetX);
                va.setDuration(300);
                va.addUpdateListener(animation -> {
                    if (iconView == null) return;
                    iconParams.x = (int) animation.getAnimatedValue();
                    try {
                        windowManager.updateViewLayout(iconView, iconParams);
                    } catch (Exception e) {
                        if(logic.log != null) logic.log.e("Float", "Snap update failed", e);
                    }
                });
                va.start();
                
                // Become semi-transparent
                iconView.animate().alpha(0.5f).setDuration(300).start();
                
            } catch (Exception e) {
                if(logic.log != null) logic.log.e("Float", "Snap failed", e);
            }
        }
        
        // ScaleLayout Inner Class
        private class ScaleLayout extends FrameLayout {
            public ScaleLayout(Context context) { super(context); }
            @Override
            public boolean onTouchEvent(MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                    restorePassThrough();
                    return true;
                }
                return super.onTouchEvent(event);
            }

            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                if (contentRoot != null && baseWidth > 0 && baseHeight > 0) {
                    float sx = (float) w / baseWidth;
                    float sy = (float) h / baseHeight;
                    contentRoot.setScaleX(sx);
                    contentRoot.setScaleY(sy);
                }
            }
            
            // Task 9 Fix: Handle Back Key when focused
            @Override
            public boolean dispatchKeyEvent(android.view.KeyEvent event) {
                if (event.getKeyCode() == android.view.KeyEvent.KEYCODE_BACK && event.getAction() == android.view.KeyEvent.ACTION_UP) {
                    if ((chatParams.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
                        // We have focus (typing), so Back should hide keyboard and restore pass-through
                        restorePassThrough();
                        return true; // Consumed
                    }
                }
                return super.dispatchKeyEvent(event);
            }
        }
        
        // Task 9 Fix: Helper to restore pass-through state
        private void restorePassThrough() {
             if ((chatParams.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
                 chatParams.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                 try {
                     windowManager.updateViewLayout(chatView, chatParams);
                     
                     // Generic focus clearing
                     View focused = chatView.findFocus();
                     if (focused != null) {
                         focused.clearFocus();
                         android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                         if (imm != null) imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
                     } else if (inputEdit != null) {
                         // Fallback
                         android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                         if (imm != null) imm.hideSoftInputFromWindow(inputEdit.getWindowToken(), 0);
                     }
                 } catch (Exception e) {
                     if(logic.log != null) logic.log.e("Float", "Restore pass-through failed", e);
                 }
             }
        }

        private void enableInput(android.widget.EditText et) {
            et.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if ((chatParams.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
                        chatParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                        try {
                            windowManager.updateViewLayout(chatView, chatParams);
                            v.requestFocus();
                            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) imm.showSoftInput(v, 0);
                        } catch (Exception e) {
                            if(logic.log != null) logic.log.e("Float", "Focus request failed", e);
                        }
                    }
                }
                return false;
            });
        }

        public void showChat() {
            removeIcon();
            handler.removeCallbacks(snapRunnable);
            
            if (baseWidth == 0 || baseHeight == 0) {
                 android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
                 baseWidth = (int)(dm.widthPixels * 0.9);
                 baseHeight = (int)(dm.heightPixels * 0.6);
            }

            LinearLayout root = new LinearLayout(context);
            root.setOrientation(LinearLayout.VERTICAL);
            w.LiquidGlassDrawable bg = new w.LiquidGlassDrawable(245);
            root.setBackground(bg);
            root.setPadding(20, 20, 20, 20);
            this.contentRoot = root;
            
            // Header
            LinearLayout header = new LinearLayout(context);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);
            
            TextView title = new TextView(context);
            title.setText("AI 助手");
            title.setTextColor(Color.BLACK);
            title.setTextSize(14);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            header.addView(title, titleLp);
            
            header.addView(createHeaderBtn("新建", v -> createNewChat()));
            header.addView(createHeaderBtn("历史", v -> showHistory()));
            header.addView(createHeaderBtn("设置", v -> openSettings(null)));
            header.addView(createHeaderBtn("最小化", v -> showIcon()));
            header.addView(createHeaderBtn("关闭", v -> closeSystemFloating()));
            
            root.addView(header);
            
            // Container
            FrameLayout contentFrame = new FrameLayout(context);
            LinearLayout.LayoutParams cfLp = new LinearLayout.LayoutParams(-1, 0, 1.0f);
            cfLp.topMargin = 10;
            cfLp.bottomMargin = 10;
            root.addView(contentFrame, cfLp);
            
            webContainer = new FrameLayout(context);
            contentFrame.addView(webContainer, new FrameLayout.LayoutParams(-1, -1));
            
            historyList = new ListView(context);
            historyList.setVisibility(View.GONE);
            historyList.setBackgroundColor(Color.parseColor("#F5F5F5"));
            contentFrame.addView(historyList, new FrameLayout.LayoutParams(-1, -1));
            
            // Input area
            inputArea = new LinearLayout(context);
            inputArea.setOrientation(LinearLayout.HORIZONTAL);
            EditText et = new EditText(context);
            et.setHint("输入问题...");
            et.setTextSize(14);
            et.setBackgroundColor(Color.parseColor("#F0F0F0"));
            et.setPadding(15, 15, 15, 15);
            et.setMinHeight(100);
            LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            inputArea.addView(et, etLp);
            inputEdit = et;
            
            TextView sendBtn = new TextView(context);
            sendBtn.setText("发送");
            sendBtn.setTextColor(Color.WHITE);
            sendBtn.setBackgroundColor(Color.parseColor("#2196F3"));
            sendBtn.setPadding(30, 15, 30, 15);
            sendBtn.setGravity(Gravity.CENTER);
            sendBtn.setOnClickListener(v -> sendMsg());
            inputArea.addView(sendBtn);
            
            root.addView(inputArea);
            
            ScaleLayout scaleLayout = new ScaleLayout(context);
            scaleLayout.addView(root, new FrameLayout.LayoutParams(baseWidth, baseHeight));
            root.setPivotX(0);
            root.setPivotY(0);
            chatView = scaleLayout;
            
            if (chatParams == null) {
                chatParams = new WindowManager.LayoutParams();
                chatParams.width = baseWidth;
                chatParams.height = baseHeight;
                if (Build.VERSION.SDK_INT >= 26) chatParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                else chatParams.type = WindowManager.LayoutParams.TYPE_PHONE;
                // Task 9 Fix: Default to NOT_FOCUSABLE so Back Key passes through to underlying app
                chatParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR;
                chatParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
                chatParams.format = android.graphics.PixelFormat.TRANSLUCENT;
                chatParams.gravity = Gravity.CENTER;
            }
            
            // Task 9 Fix: Dynamic Focus Logic
            // When user taps input, remove NOT_FOCUSABLE to allow typing
            enableInput(inputEdit);
            
            header.setOnTouchListener(new View.OnTouchListener() {
                float initialX, initialY, initialTouchX, initialTouchY;
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = chatParams.x;
                            initialY = chatParams.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            chatParams.x = (int) (initialX + (event.getRawX() - initialTouchX));
                            chatParams.y = (int) (initialY + (event.getRawY() - initialTouchY));
                            windowManager.updateViewLayout(chatView, chatParams);
                            return true;
                    }
                    return false;
                }
            });
            
            root.setOnTouchListener(new View.OnTouchListener() {
                float initialTouchX, initialTouchY;
                int initialWidth, initialHeight;
                boolean isResizing = false;

                public boolean onTouch(View v, MotionEvent event) {
                    float x = event.getX();
                    float y = event.getY();
                    int w = baseWidth;
                    int h = baseHeight;
                    int cornerSize = 200;
                    
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            if (y > h - cornerSize && (x < cornerSize || x > w - cornerSize)) {
                                isResizing = true;
                                initialTouchX = event.getRawX();
                                initialTouchY = event.getRawY();
                                initialWidth = chatParams.width;
                                initialHeight = chatParams.height;
                                return true;
                            }
                            return false;
                        case MotionEvent.ACTION_MOVE:
                            if (isResizing) {
                                float dy = event.getRawY() - initialTouchY;
                                float ratio = (float) initialWidth / initialHeight;
                                int newHeight = (int) (initialHeight + dy);
                                if (newHeight < 300) newHeight = 300;
                                int newWidth = (int) (newHeight * ratio);
                                chatParams.width = newWidth;
                                chatParams.height = newHeight;
                                try {
                                    windowManager.updateViewLayout(chatView, chatParams);
                                } catch (Exception e) {
                                    if(logic.log != null) logic.log.e("Float", "Chat resize failed", e);
                                }
                                return true;
                            }
                            return false;
                        case MotionEvent.ACTION_UP:
                            isResizing = false;
                            return true;
                    }
                    return false;
                }
            });

            try {
                windowManager.addView(chatView, chatParams);
                
                if (currentSid == null) {
                    currentSid = "C_" + System.currentTimeMillis();
                    currentTree = new ArrayList<>();
                    // currentTree.add(new Node(UUID.randomUUID().toString(), "system", "System Floating Window Mode", null));
                }
                
                initWebView(webContainer);
            } catch (Exception e) {
                if(logic.log != null) logic.log.e("Float", "Show chat failed", e);
            }
        }
        
        private TextView createHeaderBtn(String text, View.OnClickListener l) {
             TextView btn = new TextView(context);
             btn.setText(text);
             btn.setTextColor(Color.DKGRAY);
             btn.setPadding(15, 10, 15, 10);
             btn.setTextSize(12);
             btn.setOnClickListener(l);
             return btn;
        }
        
        private void saveChat() {
             try {
                 // 确保当前会话信息已同步到 logic
                 logic.currentSid = currentSid;
                 logic.currentTree = currentTree;
                 
                 // 直接调用插件内部的保存逻辑
                 logic.save();
                 
                 logic.log.d("Float", "saveChat executed for " + currentSid);
             } catch(Exception e) {
                 if(logic.log != null) logic.log.e("Float", "Save chat failed", e);
             }
        }
        
        private void createNewChat() {
             saveChat();
             currentSid = "C_" + System.currentTimeMillis();
             currentTree = new ArrayList<>();
             // currentTree.add(new Node(UUID.randomUUID().toString(), "system", "System Floating Window Mode", null));
             
             // Task: Sync logic state immediately to avoid showing old chat in WebView
             logic.currentSid = currentSid;
             logic.currentTree = currentTree;
             
             historyList.setVisibility(View.GONE);
             if (settingsView != null) settingsView.setVisibility(View.GONE);
             webContainer.setVisibility(View.VISIBLE);
             inputArea.setVisibility(View.VISIBLE);
             
             initWebView(webContainer);
        }
        
        private void openSettings(Class<?> cls) {
            showSettings();
        }

        private void showSettings() {
             saveChat();
             
             webContainer.setVisibility(View.GONE);
             inputArea.setVisibility(View.GONE);
             historyList.setVisibility(View.GONE);
             if (settingsView != null) {
                 settingsView.setVisibility(View.VISIBLE);
                 return;
             }
             
             Context ctx = context;
             ScrollView sv = new ScrollView(ctx);
             sv.setBackgroundColor(Color.parseColor("#F5F5F5"));
             LinearLayout ll = new LinearLayout(ctx);
             ll.setOrientation(LinearLayout.VERTICAL);
             ll.setPadding(30, 30, 30, 30);
             sv.addView(ll);
             
             // Initialize w.P if empty
             w.initProviders();
             
             SharedPreferences sp = logic.getContext().getPreferences();
             
             // API Provider
             TextView tvP = new TextView(ctx); tvP.setText("服务提供商"); tvP.setTextColor(Color.BLACK); ll.addView(tvP);
             Spinner spinP = new Spinner(ctx);
             List<String> pNames = new ArrayList<>();
             for (w.p p : w.P) pNames.add(p.n);
             pNames.add("Custom");
             ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_dropdown_item, pNames);
             spinP.setAdapter(adapter);
             ll.addView(spinP);
             
             // URL
             TextView tvU = new TextView(ctx); tvU.setText("API 地址"); tvU.setTextColor(Color.BLACK); tvU.setPadding(0, 20, 0, 0); ll.addView(tvU);
             EditText etU = new EditText(ctx); etU.setText(cail.O.gUrl(logic.getContext())); etU.setHint("https://..."); 
             etU.setBackgroundColor(Color.WHITE); etU.setPadding(10, 10, 10, 10);
             enableInput(etU);
             ll.addView(etU);
             
             // Key
             TextView tvK = new TextView(ctx); tvK.setText("API Key"); tvK.setTextColor(Color.BLACK); tvK.setPadding(0, 20, 0, 0); ll.addView(tvK);
             EditText etK = new EditText(ctx); 
             etK.setText(cail.O.g(logic.getContext())); 
             etK.setHint("sk-..."); etK.setBackgroundColor(Color.WHITE); etK.setPadding(10, 10, 10, 10);
             enableInput(etK);
             ll.addView(etK);
             
             // Model
             TextView tvM = new TextView(ctx); tvM.setText("模型名称"); tvM.setTextColor(Color.BLACK); tvM.setPadding(0, 20, 0, 0); ll.addView(tvM);
             EditText etM = new EditText(ctx); etM.setText(sp.getString(cail.O._0, "deepseek-ai/DeepSeek-V3")); 
             etM.setBackgroundColor(Color.WHITE); etM.setPadding(10, 10, 10, 10);
             enableInput(etM);
             ll.addView(etM);
             
             // Prompt
             TextView tvPrompt = new TextView(ctx); tvPrompt.setText("系统提示词 (Prompt)"); tvPrompt.setTextColor(Color.BLACK); tvPrompt.setPadding(0, 20, 0, 0); ll.addView(tvPrompt);
             EditText etPrompt = new EditText(ctx); etPrompt.setText(sp.getString(cail.O.l, "分析文本：\n\n{text}")); 
             etPrompt.setBackgroundColor(Color.WHITE); etPrompt.setPadding(10, 10, 10, 10); etPrompt.setMinLines(3);
             enableInput(etPrompt);
             ll.addView(etPrompt);

             // Params (JSON)
             TextView tvParams = new TextView(ctx); tvParams.setText("API 参数 (JSON)"); tvParams.setTextColor(Color.BLACK); tvParams.setPadding(0, 20, 0, 0); ll.addView(tvParams);
             EditText etParams = new EditText(ctx); etParams.setText(sp.getString(cail.O.i, "{}")); 
             etParams.setBackgroundColor(Color.WHITE); etParams.setPadding(10, 10, 10, 10); etParams.setMinLines(3);
             enableInput(etParams);
             ll.addView(etParams);

             // Task 8 Fix: Add missing switches
             CheckBox swAutoKv = new CheckBox(ctx);
             swAutoKv.setText("自动保存密钥到保管箱");
             swAutoKv.setTextColor(Color.BLACK);
             swAutoKv.setChecked(sp.getBoolean("api_auto_kv", false));
             swAutoKv.setPadding(0, 20, 0, 20);
             ll.addView(swAutoKv);

             // Key Vault Button
             TextView btnKv = new TextView(ctx);
             btnKv.setText("从保管箱选择密钥");
             btnKv.setTextColor(Color.WHITE);
             btnKv.setBackgroundColor(Color.parseColor("#FF9800"));
             btnKv.setPadding(30, 20, 30, 20);
             btnKv.setGravity(Gravity.CENTER);
             LinearLayout.LayoutParams lpKv = new LinearLayout.LayoutParams(-1, -2);
             lpKv.topMargin = 20;
             ll.addView(btnKv, lpKv);
             
             btnKv.setOnClickListener(v -> {
                 showKeyVault(etU, etK, etM);
             });

             // Calculate initial spinner selection based on current URL
             String currentUrl = etU.getText().toString().trim();
             int selIndex = pNames.size() - 1; // Default to Custom
             for (int i = 0; i < w.P.size(); i++) {
                 if (w.P.get(i).u.equals(currentUrl)) {
                     selIndex = i;
                     break;
                 }
             }
             spinP.setSelection(selIndex);

             // Spinner Listener (Task 8 Fix: Update Model too, delay to avoid overwriting initial values)
             spinP.post(() -> spinP.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                 boolean isFirst = true;
                 public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                     if (isFirst) { isFirst = false; return; }
                     if (position < w.P.size()) {
                         w.p p = w.P.get(position);
                         etU.setText(p.u);
                         if (p.m != null && p.m.length > 0) {
                             etM.setText(p.m[0]);
                         }
                     }
                 }
                 public void onNothingSelected(android.widget.AdapterView<?> parent) {}
             }));

             // Save Button
             TextView btnSave = new TextView(ctx);
             btnSave.setText("保存配置");
             btnSave.setTextColor(Color.WHITE);
             btnSave.setBackgroundColor(Color.parseColor("#4CAF50"));
             btnSave.setPadding(30, 20, 30, 20);
             btnSave.setGravity(Gravity.CENTER);
             LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(-1, -2);
             lpBtn.topMargin = 40;
             ll.addView(btnSave, lpBtn);
             
             btnSave.setOnClickListener(v -> {
                 try {
                     String u = etU.getText().toString().trim();
                     String k = etK.getText().toString().trim();
                     String m = etM.getText().toString().trim();
                     String pr = etPrompt.getText().toString().trim();
                     String pa = etParams.getText().toString().trim();
                     
                     // Validate JSON
                     try {
                         if (!pa.isEmpty()) new JSONObject(pa);
                     } catch (Exception e) {
                         Toast.makeText(ctx, "JSON 参数格式错误", Toast.LENGTH_SHORT).show();
                         return;
                     }
                     if (pa.isEmpty()) pa = "{}";
                     
                     cail.O.sUrl(pluginContext, u);
                      cail.O.s(pluginContext, k);
                      sp.edit()
                        .putString(cail.O._0, m)
                        .putString(cail.O.l, pr)
                        .putString(cail.O.i, pa)
                        .putBoolean("api_auto_kv", swAutoKv.isChecked())
                        .apply();
                     
                     if (swAutoKv.isChecked() && !k.isEmpty()) {
                         try {
                             String kvStr = sp.getString("kv_d", "[]");
                             JSONArray kv = new JSONArray(kvStr);
                             boolean exists = false;
                             for(int i=0; i<kv.length(); i++) {
                                 if (kv.getJSONObject(i).optString("k").equals(k)) { exists = true; break; }
                             }
                             if (!exists) {
                                 JSONObject n = new JSONObject();
                                 String pName = "自定义";
                                 for (w.p p : w.P) if (p.u.equals(u)) { pName = p.n; break; }
                                 n.put("n", pName);
                                 n.put("r", new java.text.SimpleDateFormat("MM-dd HH:mm").format(new Date()));
                                 n.put("k", k);
                                 kv.put(n);
                                 sp.edit().putString("kv_d", kv.toString()).apply();
                             }
                         } catch (Exception e) {
                             new O.L(pluginContext).e("UI", "Auto save kv failed", e);
                         }
                     }
                     
                     Toast.makeText(ctx, "保存成功", Toast.LENGTH_SHORT).show();
                      loadHistory(currentSid); // Return to current chat
                  } catch (Exception e) {
                     Toast.makeText(ctx, "保存失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                 }
             });
             
             // Add to contentFrame
             FrameLayout contentFrame = (FrameLayout) webContainer.getParent();
             contentFrame.addView(sv, new FrameLayout.LayoutParams(-1, -1));
             settingsView = sv;
        }

        // Task 8 Fix: Key Vault UI for Floating Window
        private void showKeyVault(EditText etU, EditText etK, EditText etM) {
             try {
                 JSONArray a = new JSONArray(logic.getContext().getPreferences().getString("kv_d", "[]"));
                 if (a.length() == 0) {
                     Toast.makeText(context, "保管箱为空", Toast.LENGTH_SHORT).show();
                     return;
                 }
                 
                 final android.app.Dialog d = new android.app.Dialog(context);
                 d.requestWindowFeature(Window.FEATURE_NO_TITLE);
                 if (Build.VERSION.SDK_INT >= 26) d.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
                 else d.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
                 
                 LinearLayout dl = new LinearLayout(context);
                 dl.setOrientation(LinearLayout.VERTICAL);
                 dl.setBackgroundColor(Color.WHITE);
                 dl.setPadding(30, 30, 30, 30);
                 
                 TextView t = new TextView(context);
                 t.setText("选择密钥");
                 t.setTextSize(18);
                 t.setTextColor(Color.BLACK);
                 dl.addView(t);
                 
                 ListView lv = new ListView(context);
                 List<String> items = new ArrayList<>();
                 for (int i = 0; i < a.length(); i++) {
                     JSONObject o = a.getJSONObject(i);
                     items.add(o.optString("n") + " - " + o.optString("r"));
                 }
                 ArrayAdapter<String> adp = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, items);
                 lv.setAdapter(adp);
                 dl.addView(lv, new LinearLayout.LayoutParams(-1, 500)); // Fixed height
                 
                 lv.setOnItemClickListener((p, v, pos, id) -> {
                     try {
                         JSONObject o = a.getJSONObject(pos);
                         etK.setText(o.optString("k"));
                         // Try to match provider to set URL/Model? 
                         // Logic.kv doesn't store URL/Model explicitly unless encoded?
                         // Actually w.p stores u/m. But kv stores 'n' (name).
                         // We can try to find provider by name 'n'.
                         String n = o.optString("n");
                         for(w.p prov : w.P) {
                             if(prov.n.equals(n)) {
                                 etU.setText(prov.u);
                                 if(prov.m != null && prov.m.length > 0) etM.setText(prov.m[0]);
                                 break;
                             }
                         }
                         Toast.makeText(context, "已填入", Toast.LENGTH_SHORT).show();
                         d.dismiss();
                     } catch(Exception e) {}
                 });
                 
                 d.setContentView(dl);
                 d.show();
                 
             } catch (Exception e) {
                 if(logic.log != null) logic.log.e("Float", "KV show failed", e);
             }
        }


        private void closeSystemFloating() {
             saveChat();
             logic.getContext().getPreferences().edit().putBoolean("global_float_window", false).apply();
             logic.stopSystemFloating();
        }
        
        private void showHistory() {
             saveChat();
             
             webContainer.setVisibility(View.GONE);
             inputArea.setVisibility(View.GONE);
             if (settingsView != null) settingsView.setVisibility(View.GONE);
             historyList.setVisibility(View.VISIBLE);
             
             List<Map<String, String>> l = logic.h.l(50, 0);
             List<String> items = new ArrayList<>();
             List<String> ids = new ArrayList<>();
             SimpleDateFormat f = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
             for (Map<String, String> m : l) {
                 ids.add(m.get("session_id"));
                 items.add(f.format(new Date(Long.parseLong(m.get("update_time")))) + " - " + m.get("topic"));
             }
             
             ArrayAdapter<String> adapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, items);
             historyList.setAdapter(adapter);
             
             historyList.setOnItemClickListener((parent, view, position, id) -> {
                 loadHistory(ids.get(position));
             });
        }
        
        private void loadHistory(String sid) {
             logic.currentSid = sid;
             logic.currentTree = logic.h.g(sid);
             currentSid = sid;
             currentTree = logic.currentTree;
             
             if (currentTree.isEmpty()) {
                 // currentTree.add(new Node(UUID.randomUUID().toString(), "system", "System Floating Window Mode", null));
             }
             
             historyList.setVisibility(View.GONE);
             if (settingsView != null) settingsView.setVisibility(View.GONE);
             webContainer.setVisibility(View.VISIBLE);
             inputArea.setVisibility(View.VISIBLE);
             
             initWebView(webContainer);
        }
        
        private void initWebView(FrameLayout container) {
            try {
                if (webView == null) {
                // Task 9: Use ContextThemeWrapper with a style that supports Action Mode
                // Using Theme.DeviceDefault.Light.Dialog.NoActionBar or similar to ensure text selection menu works
                Context themedCtx = new android.view.ContextThemeWrapper(context, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
                webView = new WebView(themedCtx);
                webView.setFocusable(true);
                webView.setFocusableInTouchMode(true);
                webView.setLongClickable(true); // Enable long click
                
                webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                WebSettings ws = webView.getSettings();
                ws.setJavaScriptEnabled(true);
                ws.setDomStorageEnabled(true);
                ws.setAllowFileAccess(true);
                ws.setAllowContentAccess(true);
                ws.setDatabaseEnabled(true);
                ws.setCacheMode(WebSettings.LOAD_DEFAULT);
                ws.setSupportZoom(false); // Task 9: Disable zoom to prevent accidental scaling issues
                webView.setBackgroundColor(0);
                
                // Task 9: Request focus
                webView.requestFocus();

                // Task 9 Fix: Ensure window is focusable when touching WebView to allow Action Mode
                webView.setOnTouchListener((v, event) -> {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        if ((chatParams.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
                            chatParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                            try {
                                windowManager.updateViewLayout(chatView, chatParams);
                            } catch (Exception e) {
                                if(logic.log != null) logic.log.e("Float", "Focus update failed", e);
                            }
                        }
                    }
                    return false;
                });

                container.addView(webView, new FrameLayout.LayoutParams(-1, -1));
            }
            
            logic.currentSid = currentSid;
            logic.currentTree = currentTree;
            logic.isHistoryDetail = false;
            
            PluginUI fakeUI = new SimplePluginUI() {
                public PluginContext getContext() { return pluginContext; }
                public boolean isDarkTheme() { return false; }
                public int colorAccent() { return Color.parseColor("#2196F3"); }
                public void showToast(CharSequence s) { Toast.makeText(context, s, Toast.LENGTH_SHORT).show(); }
                public int sp2px(float sp) { return (int)(sp * context.getResources().getDisplayMetrics().scaledDensity + 0.5f); }
                public int dp2px(float dp) { return (int)(dp * context.getResources().getDisplayMetrics().density + 0.5f); }
            };
            
            taskP = new P(logic, fakeUI, () -> {}, () -> {}) {
                @Override
                void p() {
                    super.p();
                    saveChat();
                }
            };
            taskP.isFloating = true;
            taskP.webView = webView;
            taskP.isLoaded = true;
            
            taskP.initHtml();
            } catch (Throwable e) { // Task 10: Catch Throwable
                if(logic.log != null) logic.log.e("Float", "Init WebView failed", e);
                Toast.makeText(context, "WebView Init Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        
        private void sendMsg() {
            String text = inputEdit.getText().toString().trim();
            if(text.isEmpty()) return;
            inputEdit.setText("");
            
            // Task 9 Fix: Restore pass-through after sending
            restorePassThrough();
            
            logic.currentSid = currentSid;
            logic.currentTree = currentTree;
            
            logic.a(taskP.u, text, "", currentSid, taskP, null);
            // Task 10: Sync currentTree reference as logic.a might have swapped it (if it was new chat)
            currentTree = logic.currentTree;
        }
    }
}
