package cail;

import androidx.annotation.NonNull;
import bin.mt.plugin.api.editor.*;
import bin.mt.plugin.api.ui.PluginUI;
import bin.mt.plugin.api.drawable.MaterialIcons;
import android.graphics.drawable.Drawable;

/**
 * 文本编辑器浮动菜单类 l
 * 继承自 BaseTextEditorFloatingMenu，实现编辑器悬浮菜单功能
 * 作为插件的主要快捷入口，提供在文本编辑器中直接调用的能力
 * 保持了混淆的命名风格
 */
public class l extends BaseTextEditorFloatingMenu {
    
    // 核心逻辑实例，用于处理具体的业务功能
    O o;

    /**
     * 初始化方法
     * 在插件加载时调用，初始化核心逻辑对象 O
     * 确保后续操作有可用的逻辑处理实例
     */
    protected void init() {
        super.init();
        w.weakContext = new java.lang.ref.WeakReference<>(getContext());
        o = new O();
        o.init(getContext());
    }

    /**
     * 获取菜单名称
     * @return 菜单在界面上显示的名称
     */
    @NonNull 
    public String name() {
        return "AI文本分析";
    }

    /**
     * 获取菜单图标
     * @return Material Design 风格的图标，这里使用智能玩具图标
     */
    @NonNull 
    public Drawable icon() {
        return MaterialIcons.get("smart_toy");
    }

    /**
     * 判断菜单是否启用
     * 根据核心逻辑的启用状态来决定菜单是否可用
     * @param e 编辑器实例
     * @return true 表示启用，false 表示禁用
     */
    public boolean isEnabled(@NonNull TextEditor e) {
        return o.isEnabled();
    }

    /**
     * 是否支持选中文本
     * 声明此功能支持在选中文本的状态下使用
     * @return true 表示支持
     */
    public boolean supportSelectText() {
        return true;
    }

    /**
     * 检查菜单是否可见
     * 根据核心逻辑的启用状态来决定菜单是否显示
     * @param e 编辑器实例
     * @return true 表示可见，false 表示隐藏
     */
    public boolean checkVisible(@NonNull TextEditor e) {
        return o.isEnabled();
    }

    /**
     * 菜单点击事件处理
     * 当用户点击浮动菜单时触发，执行文本分析功能
     * @param i 插件UI接口，用于显示界面元素
     * @param e 编辑器实例，用于获取选中的文本
     */
    public void onMenuClick(@NonNull PluginUI i, @NonNull TextEditor e) {
        try {
            String s = e.getSelectedText();
            // 检查是否选中文本，未选中则提示用户
            if (s == null || s.isEmpty()) {
                i.showToast("请先选中文本");
                return;
            }
            // 调用核心逻辑执行功能
            o.doFunction(i, e, null);
        } catch (Throwable t) {
            i.showToast("启动失败: " + t.getMessage());
            new O.L(i.getContext()).e("Menu", "Click failed", t);
        }
    }
}
