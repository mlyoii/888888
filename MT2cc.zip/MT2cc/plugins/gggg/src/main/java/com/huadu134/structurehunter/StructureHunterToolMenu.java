package com.huadu134.structurehunter;

import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import bin.mt.plugin.api.drawable.MaterialIcons;
import bin.mt.plugin.api.editor.BaseTextEditorToolMenu;
import bin.mt.plugin.api.editor.BufferedText;
import bin.mt.plugin.api.editor.TextEditor;
import bin.mt.plugin.api.ui.PluginButton;
import bin.mt.plugin.api.ui.PluginEditText;
import bin.mt.plugin.api.ui.PluginEditTextWatcher;
import bin.mt.plugin.api.ui.PluginTextView;
import bin.mt.plugin.api.ui.PluginUI;
import bin.mt.plugin.api.ui.PluginView;
import bin.mt.plugin.api.ui.dialog.PluginDialog;

public class StructureHunterToolMenu extends BaseTextEditorToolMenu {

    @NonNull
    @Override
    public String name() {
        return "结构猎手";
    }

    @NonNull
    @Override
    public Drawable icon() {
        return MaterialIcons.get("account_tree");
    }

    @Override
    public boolean isEnabled() {
        return StructureHunterPreference.isEnabled(getContext().getPreferences());
    }

    @Override
    public boolean checkVisible(@NonNull TextEditor editor) {
        return editor.length() > 0;
    }

    @Override
    public void onPluginButtonClick(@NonNull PluginUI pluginUI) {
        pluginUI.showMessage(
                "结构猎手",
                "浏览当前文件中的结构节点，并快速跳转。\n\n"
                        + "支持：\n"
                        + "1. 关键字过滤\n"
                        + "2. 编号直跳\n"
                        + "3. 列表浏览\n"
                        + "4. 上一个 / 下一个\n"
                        + "5. 复制当前节点信息"
        );
    }

    @Override
    public void onMenuClick(@NonNull PluginUI pluginUI, @NonNull TextEditor editor) {
        final SharedPreferences preferences = pluginUI.getContext().getPreferences();
        final List<StructureHunterNode> allNodes = new ArrayList<>(StructureHunterScanner.scan(editor));

        if (allNodes.isEmpty()) {
            pluginUI.showToast("没有发现可识别的结构节点");
            return;
        }

        PluginView view = pluginUI.buildVerticalLayout()
                .paddingHorizontal(pluginUI.dialogPaddingHorizontal())
                .paddingTop(pluginUI.dialogPaddingVertical() / 2)

                .addTextView("title")
                    .text("结构猎手")
                    .textSize(17)

                .addTextView("meta")
                    .text("准备中")
                    .textSize(12)
                    .marginTopDp(6)

                .addEditBox("keyword")
                    .hint("关键字过滤，例如类名、方法名、标签名、id")
                    .singleLine(true)
                    .marginTopDp(12)

                .addEditBox("index")
                    .hint("编号直跳，例如 1")
                    .singleLine(true)
                    .marginTopDp(8)

                .addTextView("section")
                    .text("当前节点")
                    .textSize(13)
                    .marginTopDp(14)

                .addTextView("currentMain")
                    .text("准备就绪")
                    .textSize(14)
                    .marginTopDp(6)

                .addTextView("currentSub")
                    .text("")
                    .textSize(11)
                    .marginTopDp(4)

                .addTextView("currentPreview")
                    .text("")
                    .textSize(12)
                    .marginTopDp(8)

                .addHorizontalLayout("actions")
                    .marginTopDp(14)
                    .children(layout -> layout
                            .addButton("open").text("列表")
                            .addButton("prev").text("上一个")
                            .addButton("next").text("下一个")
                            .addButton("copy").text("复制")
                            .addButton("rescan").text("重扫")
                    )

                .addTextView("foot")
                    .text("可过滤、直跳，也可打开结果列表浏览。")
                    .textSize(11)
                    .marginTopDp(10)

                .build();

        PluginDialog dialog = pluginUI.buildDialog()
                .setTitle("结构浏览")
                .setView(view)
                .setPositiveButton("关闭", null)
                .show();

        PluginTextView meta = view.requireViewById("meta");
        PluginEditText keyword = view.requireViewById("keyword");
        PluginEditText index = view.requireViewById("index");
        PluginTextView currentMain = view.requireViewById("currentMain");
        PluginTextView currentSub = view.requireViewById("currentSub");
        PluginTextView currentPreview = view.requireViewById("currentPreview");
        PluginButton open = view.requireViewById("open");
        PluginButton prev = view.requireViewById("prev");
        PluginButton next = view.requireViewById("next");
        PluginButton copy = view.requireViewById("copy");
        PluginButton rescan = view.requireViewById("rescan");

        final int[] currentIndex = new int[]{0};

        Runnable refresh = () -> {
            List<StructureHunterNode> displayed = computeDisplayedNodes(preferences, allNodes, textOf(keyword));

            if (displayed.isEmpty()) {
                currentIndex[0] = 0;
                meta.setText(
                        detectFileType(editor) + "  ·  " +
                                allNodes.size() + " 项  ·  0 显示"
                );
                currentMain.setText("没有匹配结果");
                currentSub.setText("");
                currentPreview.setText("");
                return;
            }

            int selected = resolveSelectedIndex(index, displayed.size(), currentIndex[0]);
            if (selected < 0) {
                selected = Math.max(0, Math.min(currentIndex[0], displayed.size() - 1));
            }
            currentIndex[0] = selected;

            StructureHunterNode node = displayed.get(currentIndex[0]);
            boolean showLine = StructureHunterPreference.shouldShowLine(preferences);

            meta.setText(
                    detectFileType(editor) + "  ·  " +
                            allNodes.size() + " 项  ·  " +
                            displayed.size() + " 显示  ·  " +
                            "第 " + (currentIndex[0] + 1) + " 项"
            );

            currentMain.setText(node.toCardTitle());
            currentSub.setText(node.toCardMeta(showLine, currentIndex[0]));
            currentPreview.setText(node.toCardPreview());
        };

        keyword.addTextChangedListener(new PluginEditTextWatcher.Simple() {
            @Override
            public void afterTextChanged(PluginEditText editText, Editable s) {
                currentIndex[0] = 0;
                refresh.run();
            }
        });

        index.addTextChangedListener(new PluginEditTextWatcher.Simple() {
            @Override
            public void afterTextChanged(PluginEditText editText, Editable s) {
                refresh.run();
            }
        });

        open.setOnClickListener(v -> {
            List<StructureHunterNode> displayed = computeDisplayedNodes(preferences, allNodes, textOf(keyword));
            if (displayed.isEmpty()) {
                pluginUI.showToast("没有匹配结果");
                return;
            }

            String input = textOf(index).trim();
            if (!input.isEmpty()) {
                int selected = resolveSelectedIndex(index, displayed.size(), currentIndex[0]);
                if (selected < 0) {
                    pluginUI.showToast("请输入 1 到 " + displayed.size() + " 之间的编号");
                    return;
                }

                currentIndex[0] = selected;
                jumpToNode(editor, displayed.get(currentIndex[0]));
                if (StructureHunterPreference.shouldAutoClose(preferences)) {
                    dialog.dismiss();
                } else {
                    refresh.run();
                }
                return;
            }

            showResultListDialog(pluginUI, editor, preferences, displayed, index, currentIndex, refresh, dialog);
        });

        prev.setOnClickListener(v -> {
            List<StructureHunterNode> displayed = computeDisplayedNodes(preferences, allNodes, textOf(keyword));
            if (displayed.isEmpty()) {
                pluginUI.showToast("没有匹配结果");
                return;
            }

            currentIndex[0] = moveToPrevious(currentIndex[0], displayed.size());
            index.setText(String.valueOf(currentIndex[0] + 1));
            jumpToNode(editor, displayed.get(currentIndex[0]));

            if (StructureHunterPreference.shouldAutoClose(preferences)) {
                dialog.dismiss();
            } else {
                refresh.run();
            }
        });

        next.setOnClickListener(v -> {
            List<StructureHunterNode> displayed = computeDisplayedNodes(preferences, allNodes, textOf(keyword));
            if (displayed.isEmpty()) {
                pluginUI.showToast("没有匹配结果");
                return;
            }

            currentIndex[0] = moveToNext(currentIndex[0], displayed.size());
            index.setText(String.valueOf(currentIndex[0] + 1));
            jumpToNode(editor, displayed.get(currentIndex[0]));

            if (StructureHunterPreference.shouldAutoClose(preferences)) {
                dialog.dismiss();
            } else {
                refresh.run();
            }
        });

        copy.setOnClickListener(v -> {
            List<StructureHunterNode> displayed = computeDisplayedNodes(preferences, allNodes, textOf(keyword));
            if (displayed.isEmpty()) {
                pluginUI.showToast("没有匹配结果");
                return;
            }

            StructureHunterNode node = displayed.get(Math.max(0, Math.min(currentIndex[0], displayed.size() - 1)));
            showCopyDialog(pluginUI, preferences, node, currentIndex[0]);
        });

        rescan.setOnClickListener(v -> {
            allNodes.clear();
            allNodes.addAll(StructureHunterScanner.scan(editor));
            currentIndex[0] = 0;
            refresh.run();
            pluginUI.showToast("已重新扫描");
        });

        refresh.run();
        keyword.requestFocusAndShowIME();
    }

    private void showResultListDialog(@NonNull PluginUI pluginUI,
                                      @NonNull TextEditor editor,
                                      @NonNull SharedPreferences preferences,
                                      @NonNull List<StructureHunterNode> displayed,
                                      @NonNull PluginEditText indexEditText,
                                      @NonNull int[] currentIndexHolder,
                                      @NonNull Runnable refreshParent,
                                      @NonNull PluginDialog parentDialog) {
        boolean showLine = StructureHunterPreference.shouldShowLine(preferences);
        CharSequence[] items = buildResultItems(displayed, showLine);

        int checkedIndex = currentIndexHolder[0];
        if (checkedIndex < 0 || checkedIndex >= displayed.size()) {
            checkedIndex = 0;
        }

        PluginDialog resultDialog = pluginUI.buildDialog()
                .setTitle("结构结果")
                .setSingleChoiceItems(items, checkedIndex, (dialog, which) -> {
                    if (which < 0 || which >= displayed.size()) {
                        return;
                    }

                    currentIndexHolder[0] = which;
                    indexEditText.setText(String.valueOf(which + 1));
                    jumpToNode(editor, displayed.get(which));

                    if (StructureHunterPreference.shouldAutoClose(preferences)) {
                        dialog.dismiss();
                        parentDialog.dismiss();
                    } else {
                        refreshParent.run();
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("关闭", null)
                .setNegativeButton("回首", null)
                .setNeutralButton("复制", null)
                .show();

        resultDialog.getNegativeButton().setOnClickListener(v -> {
            currentIndexHolder[0] = 0;
            indexEditText.setText("1");
            jumpToNode(editor, displayed.get(0));
            refreshParent.run();
            resultDialog.dismiss();
        });

        resultDialog.getNeutralButton().setOnClickListener(v -> {
            StructureHunterNode node = displayed.get(Math.max(0, Math.min(currentIndexHolder[0], displayed.size() - 1)));
            resultDialog.dismiss();
            showCopyDialog(pluginUI, preferences, node, currentIndexHolder[0]);
        });
    }

    private void showCopyDialog(@NonNull PluginUI pluginUI,
                                @NonNull SharedPreferences preferences,
                                @NonNull StructureHunterNode node,
                                int index) {
        String[] actions = new String[]{
                "复制当前节点",
                "复制标题",
                "复制行号"
        };

        pluginUI.buildDialog()
                .setTitle("复制")
                .setItems(actions, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            copyText(node.toDisplayText(StructureHunterPreference.shouldShowLine(preferences), false, index));
                            pluginUI.showToast("已复制当前节点");
                            break;
                        case 1:
                            copyText(node.safeTitle());
                            pluginUI.showToast("已复制标题");
                            break;
                        case 2:
                            copyText(String.valueOf(node.line + 1));
                            pluginUI.showToast("已复制行号");
                            break;
                        default:
                            break;
                    }
                    dialog.dismiss();
                })
                .setPositiveButton("关闭", null)
                .show();
    }

    @NonNull
    private List<StructureHunterNode> computeDisplayedNodes(@NonNull SharedPreferences preferences,
                                                            @NonNull List<StructureHunterNode> allNodes,
                                                            String keyword) {
        List<StructureHunterNode> filtered = filter(allNodes, keyword);
        return displayedNodes(preferences, filtered);
    }

    @NonNull
    private CharSequence[] buildResultItems(@NonNull List<StructureHunterNode> displayed, boolean showLine) {
        CharSequence[] items = new CharSequence[displayed.size()];
        for (int i = 0; i < displayed.size(); i++) {
            items[i] = displayed.get(i).toCompactText(showLine, i);
        }
        return items;
    }

    private void copyText(@NonNull String text) {
        getContext().setClipboardText(text);
    }

    private int moveToPrevious(int current, int size) {
        if (size <= 0) return 0;
        return current <= 0 ? size - 1 : current - 1;
    }

    private int moveToNext(int current, int size) {
        if (size <= 0) return 0;
        return current >= size - 1 ? 0 : current + 1;
    }

    @NonNull
    private String textOf(@NonNull PluginEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString();
    }

    @NonNull
    private List<StructureHunterNode> filter(@NonNull List<StructureHunterNode> source, String keyword) {
        if (TextUtils.isEmpty(keyword)) {
            return new ArrayList<>(source);
        }

        String key = keyword.toLowerCase(Locale.ROOT);
        List<StructureHunterNode> out = new ArrayList<>();
        for (StructureHunterNode node : source) {
            if (node.title.toLowerCase(Locale.ROOT).contains(key)
                    || node.type.toLowerCase(Locale.ROOT).contains(key)) {
                out.add(node);
            }
        }
        return out;
    }

    @NonNull
    private List<StructureHunterNode> displayedNodes(@NonNull SharedPreferences preferences,
                                                     @NonNull List<StructureHunterNode> nodes) {
        int max = StructureHunterPreference.getMaxResult(preferences);
        int count = Math.min(nodes.size(), max);
        return new ArrayList<>(nodes.subList(0, count));
    }

    private int resolveSelectedIndex(@NonNull PluginEditText indexEditText, int displayedSize, int fallbackIndex) {
        String text = textOf(indexEditText).trim();
        if (text.isEmpty()) {
            return displayedSize > 0 ? Math.max(0, Math.min(fallbackIndex, displayedSize - 1)) : -1;
        }

        int input = parseIndex(text);
        if (input <= 0 || input > displayedSize) {
            return -1;
        }
        return input - 1;
    }

    private int parseIndex(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    @NonNull
    private String detectFileType(@NonNull TextEditor editor) {
        String fileName = editor.getFileName();
        if (fileName == null) {
            return "未知";
        }

        String lower = fileName.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".java")) return "Java";
        if (lower.endsWith(".kt") || lower.endsWith(".kts")) return "Kotlin";
        if (lower.endsWith(".gradle.kts")) return "Gradle KTS";
        if (lower.endsWith(".gradle")) return "Gradle";
        if (lower.endsWith(".smali")) return "Smali";
        if (lower.endsWith(".xml")) return "XML";
        if (lower.endsWith(".html")) return "HTML";
        if (lower.endsWith(".svg")) return "SVG";
        if (lower.endsWith(".json") || lower.endsWith(".json5")) return "JSON";
        if (lower.endsWith(".yaml") || lower.endsWith(".yml")) return "YAML";
        if (lower.endsWith(".properties")) return "Properties";
        if (lower.endsWith(".md") || lower.endsWith(".markdown")) return "Markdown";
        return "文本";
    }

    private void jumpToNode(@NonNull TextEditor editor, @NonNull StructureHunterNode node) {
        int lineStart = editor.getPositionFromLineColumn(node.line, 0);
        if (lineStart >= 0) {
            BufferedText text = editor.getBufferedText();
            int lineEnd = text.findLineEnd(lineStart);
            editor.setSelection(lineStart, lineEnd);
        } else {
            editor.setSelection(node.start, node.end);
        }
        editor.requestFocus();
        editor.ensureSelectionVisibleInCenter(true);
    }
}
