package com.huadu134.structurehunter;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bin.mt.plugin.api.editor.TextEditor;

public final class StructureHunterScanner {

    private static final String ANNO_PREFIX = "(?:\\s*@[^\\n]+\\n)*\\s*";

    private static final Pattern JAVA_PACKAGE = Pattern.compile(
            "(?m)^\\s*package\\s+([\\w.]+)\\s*;"
    );

    private static final Pattern JAVA_IMPORT = Pattern.compile(
            "(?m)^\\s*import\\s+(?:static\\s+)?([\\w.*]+)\\s*;"
    );

    private static final Pattern JAVA_TYPE = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|protected|private|abstract|final|static|sealed|non-sealed)\\s+)*" +
                    "(?:class|interface|enum|record)\\s+([A-Za-z_][A-Za-z0-9_]*)"
    );

    private static final Pattern JAVA_ANNOTATION_TYPE = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|protected|private|abstract|static)\\s+)*" +
                    "@interface\\s+([A-Za-z_][A-Za-z0-9_]*)"
    );

    private static final Pattern JAVA_METHOD = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|protected|private|static|final|abstract|synchronized|native|default|strictfp)\\s+)*" +
                    "(?:<[^>]+>\\s+)?" +
                    "(?:[\\w\\[\\]<>?,.@]+\\s+)+" +
                    "([A-Za-z_][A-Za-z0-9_]*)\\s*\\([^;{}]*\\)\\s*(?:throws\\s+[^{]+)?\\{?$"
    );

    private static final Pattern KOTLIN_PACKAGE = Pattern.compile(
            "(?m)^\\s*package\\s+([\\w.]+)\\s*$"
    );

    private static final Pattern KOTLIN_IMPORT = Pattern.compile(
            "(?m)^\\s*import\\s+([\\w.*]+)\\s*$"
    );

    private static final Pattern KOTLIN_TYPE = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|private|internal|protected|sealed|data|open|abstract|enum|annotation|value)\\s+)*" +
                    "(?:class|interface|object)\\s+([A-Za-z_][A-Za-z0-9_]*)"
    );

    private static final Pattern KOTLIN_DATA_OBJECT = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|private|internal|protected)\\s+)?data\\s+object\\s+([A-Za-z_][A-Za-z0-9_]*)"
    );

    private static final Pattern KOTLIN_COMPANION = Pattern.compile(
            "(?m)^\\s*companion\\s+object(?:\\s+([A-Za-z_][A-Za-z0-9_]*))?"
    );

    private static final Pattern KOTLIN_FUN = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|private|internal|protected|inline|suspend|operator|infix|tailrec|override|open|abstract|final|const|external|lateinit)\\s+)*" +
                    "fun\\s+(?:<[^>]+>\\s+)?" +
                    "(?:[A-Za-z_][A-Za-z0-9_]*\\.)?([A-Za-z_][A-Za-z0-9_]*)\\s*\\("
    );

    private static final Pattern KOTLIN_PROP = Pattern.compile(
            "(?m)^" + ANNO_PREFIX +
                    "(?:(?:public|private|internal|protected|lateinit|const|override|open|final)\\s+)*" +
                    "(?:val|var)\\s+([A-Za-z_][A-Za-z0-9_]*)\\b"
    );

    private static final Pattern SMALI_CLASS = Pattern.compile(
            "(?m)^\\s*\\.class\\s+.*?\\s+([A-Za-z0-9_$/-]+;)\\s*$"
    );

    private static final Pattern SMALI_SUPER = Pattern.compile(
            "(?m)^\\s*\\.super\\s+([A-Za-z0-9_$/-]+;)\\s*$"
    );

    private static final Pattern SMALI_FIELD = Pattern.compile(
            "(?m)^\\s*\\.field\\s+.*?\\s+([A-Za-z0-9_$-]+):"
    );

    private static final Pattern SMALI_METHOD = Pattern.compile(
            "(?m)^\\s*\\.method\\s+.*?\\s+([<>A-Za-z0-9_$-]+)\\("
    );

    private static final Pattern XML_TAG = Pattern.compile(
            "<([A-Za-z_][\\w.:-]*)(?:\\s|>|/)"
    );

    private static final Pattern XML_ATTR_ID = Pattern.compile(
            "\\b(?:android:)?id\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_NAME = Pattern.compile(
            "\\bname\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_TITLE = Pattern.compile(
            "\\btitle\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_KEY = Pattern.compile(
            "\\bkey\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_TEXT = Pattern.compile(
            "\\b(?:android:)?text\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_HINT = Pattern.compile(
            "\\b(?:android:)?hint\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_SRC = Pattern.compile(
            "\\b(?:android:)?src\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern XML_ATTR_LAYOUT = Pattern.compile(
            "\\blayout_[a-zA-Z0-9_]+\\s*=\\s*\"([^\"]+)\""
    );

    private static final Pattern JSON_KEY = Pattern.compile(
            "(?m)^\\s*\"([^\"]+)\"\\s*:"
    );

    private static final Pattern MARKDOWN_HEADING = Pattern.compile(
            "(?m)^(#{1,6})\\s+(.+?)\\s*$"
    );

    private static final Pattern PROPERTIES_KEY = Pattern.compile(
            "(?m)^\\s*([A-Za-z0-9_.-]+)\\s*(?:=|:)"
    );

    private static final Pattern YAML_KEY = Pattern.compile(
            "(?m)^(\\s*)([A-Za-z0-9_.\"'/-]+)\\s*:\\s*(?:#.*)?$"
    );

    private static final Pattern GRADLE_KTS_BLOCK = Pattern.compile(
            "(?m)^\\s*(plugins|dependencies|android|signingConfigs|buildTypes|productFlavors|sourceSets|repositories|kotlinOptions|compileOptions)\\s*\\{"
    );

    private static final Pattern GRADLE_GROOVY_BLOCK = Pattern.compile(
            "(?m)^\\s*(plugins|dependencies|android|signingConfigs|buildTypes|productFlavors|sourceSets|repositories|defaultConfig)\\s*\\{"
    );

    private static final Pattern GRADLE_DEP = Pattern.compile(
            "(?m)^\\s*(implementation|api|compileOnly|runtimeOnly|testImplementation|androidTestImplementation|debugImplementation|kapt|classpath)\\b"
    );

    private static final Pattern GRADLE_ASSIGN = Pattern.compile(
            "(?m)^\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*(?:=|\\()"
    );

    private static final Set<String> JAVA_METHOD_BLACKLIST = new HashSet<>();
    private static final Set<String> KOTLIN_MEMBER_BLACKLIST = new HashSet<>();

    static {
        Collections.addAll(JAVA_METHOD_BLACKLIST,
                "if", "for", "while", "switch", "catch", "return", "throw", "new");
        Collections.addAll(KOTLIN_MEMBER_BLACKLIST,
                "if", "for", "while", "when", "return", "throw");
    }

    private StructureHunterScanner() {
    }

    @NonNull
    public static List<StructureHunterNode> scan(@NonNull TextEditor editor) {
        String content = editor.getBufferedText().toString();
        List<StructureHunterNode> nodes = detectAndScan(editor, content);
        deduplicate(nodes);
        sortNodes(nodes);
        return nodes;
    }

    @NonNull
    private static List<StructureHunterNode> detectAndScan(@NonNull TextEditor editor, @NonNull String content) {
        String fileName = editor.getFileName();
        String lowerName = fileName == null ? "" : fileName.toLowerCase();

        if (lowerName.endsWith(".java")) return scanJava(editor, content);
        if (lowerName.endsWith(".kt") || lowerName.endsWith(".kts")) {
            if (lowerName.endsWith("build.gradle.kts") || lowerName.endsWith(".gradle.kts")) {
                return scanGradleKts(editor, content);
            }
            return scanKotlin(editor, content);
        }
        if (lowerName.endsWith(".gradle")) return scanGradleGroovy(editor, content);
        if (lowerName.endsWith(".smali")) return scanSmali(editor, content);
        if (lowerName.endsWith(".xml") || lowerName.endsWith(".html") || lowerName.endsWith(".svg")) return scanXml(editor, content);
        if (lowerName.endsWith(".json") || lowerName.endsWith(".json5")) return scanJson(editor, content);
        if (lowerName.endsWith(".md") || lowerName.endsWith(".markdown")) return scanMarkdown(editor, content);
        if (lowerName.endsWith(".yaml") || lowerName.endsWith(".yml")) return scanYaml(editor, content);
        if (lowerName.endsWith(".properties")) return scanProperties(editor, content);

        String trimmed = content.trim();

        if (trimmed.startsWith(".class") || trimmed.contains("\n.method ")) {
            List<StructureHunterNode> smali = scanSmali(editor, content);
            if (!smali.isEmpty()) return smali;
        }

        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            List<StructureHunterNode> json = scanJson(editor, content);
            if (!json.isEmpty()) return json;
        }

        if (trimmed.startsWith("<")) {
            List<StructureHunterNode> xml = scanXml(editor, content);
            if (!xml.isEmpty()) return xml;
        }

        if (content.startsWith("# ") || content.contains("\n# ")) {
            List<StructureHunterNode> md = scanMarkdown(editor, content);
            if (!md.isEmpty()) return md;
        }

        if (content.contains(" fun ") || content.contains("\nfun ")
                || content.contains("\nval ") || content.contains("\nvar ")
                || content.contains("companion object")) {
            List<StructureHunterNode> kt = scanKotlin(editor, content);
            if (!kt.isEmpty()) return kt;
        }

        if (content.contains("\nimplementation") || content.contains("\nandroid {") || content.contains("\nplugins {")) {
            List<StructureHunterNode> gradle = scanGradleGroovy(editor, content);
            if (!gradle.isEmpty()) return gradle;
        }

        if (content.contains(":") && content.contains("\n")) {
            List<StructureHunterNode> yaml = scanYaml(editor, content);
            if (!yaml.isEmpty()) return yaml;
        }

        return scanJava(editor, content);
    }

    @NonNull
    private static List<StructureHunterNode> scanJava(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        addMatches(editor, content, list, JAVA_PACKAGE, "包", 0, null);
        addMatches(editor, content, list, JAVA_IMPORT, "导入", 0, null);
        addMatches(editor, content, list, JAVA_TYPE, "类型", 0, null);
        addMatches(editor, content, list, JAVA_ANNOTATION_TYPE, "注解", 0, null);
        addJavaConstructors(editor, content, list);
        addMatches(editor, content, list, JAVA_METHOD, "方法", 1, JAVA_METHOD_BLACKLIST);
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanKotlin(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        addMatches(editor, content, list, KOTLIN_PACKAGE, "包", 0, null);
        addMatches(editor, content, list, KOTLIN_IMPORT, "导入", 0, null);
        addMatches(editor, content, list, KOTLIN_TYPE, "类型", 0, null);
        addMatches(editor, content, list, KOTLIN_DATA_OBJECT, "类型", 0, null);
        addCompanionMatches(editor, content, list);
        addMatches(editor, content, list, KOTLIN_FUN, "函数", 1, KOTLIN_MEMBER_BLACKLIST);
        addMatches(editor, content, list, KOTLIN_PROP, "属性", 1, KOTLIN_MEMBER_BLACKLIST);
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanSmali(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        addMatches(editor, content, list, SMALI_CLASS, "类", 0, null);
        addMatches(editor, content, list, SMALI_SUPER, "父类", 0, null);
        addMatches(editor, content, list, SMALI_FIELD, "字段", 1, null);
        addMatches(editor, content, list, SMALI_METHOD, "方法", 1, null);
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanXml(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        addMatches(editor, content, list, XML_ATTR_ID, "id", 1, null);
        addMatches(editor, content, list, XML_ATTR_NAME, "name", 1, null);
        addMatches(editor, content, list, XML_ATTR_TITLE, "title", 1, null);
        addMatches(editor, content, list, XML_ATTR_KEY, "key", 1, null);
        addMatches(editor, content, list, XML_ATTR_TEXT, "text", 1, null);
        addMatches(editor, content, list, XML_ATTR_HINT, "hint", 1, null);
        addMatches(editor, content, list, XML_ATTR_SRC, "src", 1, null);
        addMatches(editor, content, list, XML_ATTR_LAYOUT, "layout", 1, null);
        addXmlTags(editor, content, list);
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanJson(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        Matcher matcher = JSON_KEY.matcher(content);
        while (matcher.find()) {
            String key = cleanTitle(matcher.group(1));
            if (key.isEmpty()) continue;
            int start = matcher.start(1);
            int line = lineFromPosition(editor, start);
            int level = indentLevel(content, start);
            list.add(new StructureHunterNode("键", key, start, matcher.end(1), line, level));
        }
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanMarkdown(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        Matcher matcher = MARKDOWN_HEADING.matcher(content);
        while (matcher.find()) {
            String title = cleanTitle(matcher.group(2));
            if (title.isEmpty()) continue;
            int start = matcher.start(2);
            int line = lineFromPosition(editor, start);
            int level = Math.max(0, matcher.group(1).length() - 1);
            list.add(new StructureHunterNode("标题", title, start, matcher.end(2), line, level));
        }
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanProperties(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        Matcher matcher = PROPERTIES_KEY.matcher(content);
        while (matcher.find()) {
            String key = cleanTitle(matcher.group(1));
            if (key.isEmpty()) continue;
            int start = matcher.start(1);
            int line = lineFromPosition(editor, start);
            list.add(new StructureHunterNode("键", key, start, matcher.end(1), line, 0));
        }
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanYaml(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        Matcher matcher = YAML_KEY.matcher(content);
        while (matcher.find()) {
            String key = cleanYamlKey(matcher.group(2));
            if (key.isEmpty() || key.startsWith("-")) continue;
            int start = matcher.start(2);
            int line = lineFromPosition(editor, start);
            int level = indentFromWhitespace(matcher.group(1));
            list.add(new StructureHunterNode("键", key, start, matcher.end(2), line, level));
        }
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanGradleKts(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        addMatches(editor, content, list, GRADLE_KTS_BLOCK, "块", 0, null);
        addMatches(editor, content, list, GRADLE_DEP, "依赖", 1, null);
        addMatches(editor, content, list, GRADLE_ASSIGN, "配置", 1, null);
        return list;
    }

    @NonNull
    private static List<StructureHunterNode> scanGradleGroovy(@NonNull TextEditor editor, @NonNull String content) {
        List<StructureHunterNode> list = new ArrayList<>();
        addMatches(editor, content, list, GRADLE_GROOVY_BLOCK, "块", 0, null);
        addMatches(editor, content, list, GRADLE_DEP, "依赖", 1, null);
        addMatches(editor, content, list, GRADLE_ASSIGN, "配置", 1, null);
        return list;
    }

    private static void addMatches(@NonNull TextEditor editor,
                                   @NonNull String content,
                                   @NonNull List<StructureHunterNode> out,
                                   @NonNull Pattern pattern,
                                   @NonNull String type,
                                   int level,
                                   Set<String> blacklist) {
        Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            String title = cleanTitle(matcher.group(1));
            if (title.isEmpty()) {
                continue;
            }
            if (blacklist != null && blacklist.contains(title)) {
                continue;
            }
            int start = matcher.start(1);
            int line = lineFromPosition(editor, start);
            out.add(new StructureHunterNode(type, title, start, matcher.end(1), line, level));
        }
    }

    private static void addJavaConstructors(@NonNull TextEditor editor,
                                            @NonNull String content,
                                            @NonNull List<StructureHunterNode> out) {
        Set<String> typeNames = new HashSet<>();
        Matcher typeMatcher = JAVA_TYPE.matcher(content);
        while (typeMatcher.find()) {
            String typeName = cleanTitle(typeMatcher.group(1));
            if (!typeName.isEmpty()) {
                typeNames.add(typeName);
            }
        }

        for (String typeName : typeNames) {
            Pattern constructorPattern = Pattern.compile(
                    "(?m)^" + ANNO_PREFIX +
                            "(?:(?:public|protected|private)\\s+)?"
                            + Pattern.quote(typeName) +
                            "\\s*\\([^;{}]*\\)\\s*(?:throws\\s+[^{]+)?\\{?$"
            );
            Matcher matcher = constructorPattern.matcher(content);
            while (matcher.find()) {
                int start = matcher.start();
                int nameStart = content.indexOf(typeName, start);
                if (nameStart < 0) continue;
                int line = lineFromPosition(editor, nameStart);
                out.add(new StructureHunterNode("构造", typeName, nameStart, nameStart + typeName.length(), line, 1));
            }
        }
    }

    private static void addCompanionMatches(@NonNull TextEditor editor,
                                            @NonNull String content,
                                            @NonNull List<StructureHunterNode> out) {
        Matcher matcher = KOTLIN_COMPANION.matcher(content);
        while (matcher.find()) {
            String title = cleanTitle(matcher.group(1));
            if (title.isEmpty()) {
                title = "companion";
            }
            int start = matcher.start();
            int line = lineFromPosition(editor, start);
            out.add(new StructureHunterNode("伴生对象", title, start, matcher.end(), line, 0));
        }
    }

    private static void addXmlTags(@NonNull TextEditor editor,
                                   @NonNull String content,
                                   @NonNull List<StructureHunterNode> out) {
        Matcher matcher = XML_TAG.matcher(content);
        while (matcher.find()) {
            String tag = cleanTitle(matcher.group(1));
            if (tag.isEmpty()) {
                continue;
            }
            int start = matcher.start(1);
            int lt = matcher.start();
            if (lt + 1 < content.length()) {
                char next = content.charAt(lt + 1);
                if (next == '/' || next == '!' || next == '?') {
                    continue;
                }
            }
            int line = lineFromPosition(editor, start);
            out.add(new StructureHunterNode("标签", tag, start, matcher.end(1), line, 0));
        }
    }

    private static void sortNodes(@NonNull List<StructureHunterNode> nodes) {
        Collections.sort(nodes, (a, b) -> {
            int byPriority = Integer.compare(typePriority(a.type), typePriority(b.type));
            if (byPriority != 0) return byPriority;

            int byLevel = Integer.compare(a.level, b.level);
            if (byLevel != 0) return byLevel;

            return Integer.compare(a.start, b.start);
        });
    }

    private static int typePriority(String type) {
        if ("id".equals(type)) return 0;
        if ("name".equals(type)) return 1;
        if ("title".equals(type)) return 2;
        if ("key".equals(type)) return 3;
        if ("text".equals(type)) return 4;
        if ("hint".equals(type)) return 5;
        if ("src".equals(type)) return 6;
        if ("layout".equals(type)) return 7;
        if ("标题".equals(type)) return 8;
        if ("类型".equals(type)) return 9;
        if ("类".equals(type)) return 10;
        if ("注解".equals(type)) return 11;
        if ("构造".equals(type)) return 12;
        if ("伴生对象".equals(type)) return 13;
        if ("方法".equals(type) || "函数".equals(type)) return 14;
        if ("属性".equals(type) || "字段".equals(type)) return 15;
        if ("块".equals(type)) return 16;
        if ("依赖".equals(type)) return 17;
        if ("配置".equals(type)) return 18;
        if ("包".equals(type)) return 19;
        if ("导入".equals(type)) return 20;
        if ("标签".equals(type)) return 21;
        if ("父类".equals(type)) return 22;
        if ("键".equals(type)) return 23;
        return 99;
    }

    private static void deduplicate(@NonNull List<StructureHunterNode> nodes) {
        Set<String> seen = new HashSet<>();
        List<StructureHunterNode> unique = new ArrayList<>();
        for (StructureHunterNode node : nodes) {
            String key = node.type + "|" + node.title + "|" + node.start + "|" + node.end;
            if (seen.add(key)) {
                unique.add(node);
            }
        }
        nodes.clear();
        nodes.addAll(unique);
    }

    @NonNull
    private static String cleanTitle(String text) {
        if (text == null) return "";
        return text.trim();
    }

    @NonNull
    private static String cleanYamlKey(String text) {
        String value = cleanTitle(text);
        if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
            value = value.substring(1, value.length() - 1).trim();
        }
        return value;
    }

    private static int lineFromPosition(@NonNull TextEditor editor, int position) {
        int[] lc = editor.getLineColumnFromPosition(position);
        return lc == null ? 0 : lc[0];
    }

    private static int indentLevel(@NonNull String content, int pos) {
        int lineStart = content.lastIndexOf('\n', Math.max(0, pos - 1));
        lineStart = lineStart < 0 ? 0 : lineStart + 1;

        int spaces = 0;
        for (int i = lineStart; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == ' ') {
                spaces++;
            } else if (c == '\t') {
                spaces += 4;
            } else {
                break;
            }
        }
        return Math.max(0, spaces / 2);
    }

    private static int indentFromWhitespace(String whitespace) {
        int spaces = 0;
        for (int i = 0; i < whitespace.length(); i++) {
            char c = whitespace.charAt(i);
            if (c == ' ') {
                spaces++;
            } else if (c == '\t') {
                spaces += 4;
            }
        }
        return Math.max(0, spaces / 2);
    }
}