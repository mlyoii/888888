package com.huadu134.structurehunter;

import android.content.SharedPreferences;

import bin.mt.plugin.api.PluginContext;
import bin.mt.plugin.api.preference.PluginPreference;

public class StructureHunterPreference implements PluginPreference {

    public static final String KEY_ENABLE = "structure_hunter_enable";
    public static final String KEY_MAX_RESULT = "structure_hunter_max_result";
    public static final String KEY_SHOW_LINE = "structure_hunter_show_line";
    public static final String KEY_AUTO_CLOSE = "structure_hunter_auto_close";
    public static final String KEY_HIDE_PACKAGE = "structure_hunter_hide_package";
    public static final String KEY_HIDE_IMPORT = "structure_hunter_hide_import";
    public static final String KEY_PRIMARY_ONLY = "structure_hunter_primary_only";
    public static final String KEY_DEFAULT_SORT = "structure_hunter_default_sort";

    public static final String DEFAULT_MAX_RESULT = "80";
    public static final String SORT_PRIORITY = "priority";
    public static final String SORT_SOURCE = "source";

    public StructureHunterPreference() {
    }

    @Override
    public void onBuild(PluginContext context, Builder builder) {
        builder.title("结构猎手设置");
        builder.subtitle("控制结构浏览器的显示、过滤和排序行为");

        builder.addHeader("基础");

        builder.addSwitch("启用结构猎手", KEY_ENABLE)
                .summaryOn("已启用")
                .summaryOff("已禁用")
                .defaultValue(true);

        builder.addList("最大显示结果数", KEY_MAX_RESULT)
                .summary("控制主界面和结果列表最多显示多少条结果")
                .defaultValue(DEFAULT_MAX_RESULT)
                .addItem("20 条", "20")
                .addItem("50 条", "50")
                .addItem("80 条", "80")
                .addItem("120 条", "120")
                .addItem("200 条", "200");

        builder.addSwitch("显示行号", KEY_SHOW_LINE)
                .summaryOn("当前节点和结果列表中显示行号")
                .summaryOff("当前节点和结果列表中不显示行号")
                .defaultValue(true);

        builder.addSwitch("跳转后自动关闭", KEY_AUTO_CLOSE)
                .summaryOn("跳转后关闭结构浏览窗口")
                .summaryOff("跳转后保留结构浏览窗口")
                .defaultValue(false);

        builder.addList("默认排序方式", KEY_DEFAULT_SORT)
                .summary("设置结构结果默认按什么方式浏览")
                .defaultValue(SORT_PRIORITY)
                .addItem("按结构优先级", SORT_PRIORITY)
                .addItem("按源码顺序", SORT_SOURCE);

        builder.addHeader("过滤");

        builder.addSwitch("隐藏包声明", KEY_HIDE_PACKAGE)
                .summaryOn("结果中不显示包声明")
                .summaryOff("结果中显示包声明")
                .defaultValue(false);

        builder.addSwitch("隐藏导入", KEY_HIDE_IMPORT)
                .summaryOn("结果中不显示导入")
                .summaryOff("结果中显示导入")
                .defaultValue(true);

        builder.addSwitch("只看主要结构", KEY_PRIMARY_ONLY)
                .summaryOn("仅显示类型、方法、字段、标题、id 等主要结构")
                .summaryOff("显示全部结构")
                .defaultValue(false);

        builder.addHeader("支持范围");

        builder.addText("当前支持的文件结构")
                .summary("Java、Kotlin、smali、XML、JSON、Markdown、YAML、Properties、Gradle");

        builder.addHeader("说明");

        builder.addText("当前版本说明")
                .summary("支持关键字过滤、编号直跳、结果列表浏览、复制当前节点、只看当前类型和排序切换。");
    }

    public static boolean isEnabled(SharedPreferences preferences) {
        return preferences.getBoolean(KEY_ENABLE, true);
    }

    public static int getMaxResult(SharedPreferences preferences) {
        String value = preferences.getString(KEY_MAX_RESULT, DEFAULT_MAX_RESULT);
        try {
            return Integer.parseInt(value);
        } catch (Throwable ignore) {
            return Integer.parseInt(DEFAULT_MAX_RESULT);
        }
    }

    public static boolean shouldShowLine(SharedPreferences preferences) {
        return preferences.getBoolean(KEY_SHOW_LINE, true);
    }

    public static boolean shouldAutoClose(SharedPreferences preferences) {
        return preferences.getBoolean(KEY_AUTO_CLOSE, false);
    }

    public static boolean shouldHidePackage(SharedPreferences preferences) {
        return preferences.getBoolean(KEY_HIDE_PACKAGE, false);
    }

    public static boolean shouldHideImport(SharedPreferences preferences) {
        return preferences.getBoolean(KEY_HIDE_IMPORT, true);
    }

    public static boolean shouldPrimaryOnly(SharedPreferences preferences) {
        return preferences.getBoolean(KEY_PRIMARY_ONLY, false);
    }

    public static int getDefaultSortMode(SharedPreferences preferences) {
        String value = preferences.getString(KEY_DEFAULT_SORT, SORT_PRIORITY);
        return SORT_SOURCE.equals(value) ? 1 : 0;
    }
}
