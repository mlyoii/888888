package com.huadu134.structurehunter;

import androidx.annotation.NonNull;

public class StructureHunterNode {
    public final String type;
    public final String title;
    public final int start;
    public final int end;
    public final int line;
    public final int level;

    public StructureHunterNode(String type, String title, int start, int end, int line, int level) {
        this.type = type == null ? "" : type;
        this.title = title == null ? "" : title;
        this.start = start;
        this.end = end;
        this.line = Math.max(0, line);
        this.level = Math.max(0, level);
    }

    @NonNull
    public String safeTitle() {
        String value = title.trim();
        return value.isEmpty() ? "(未命名)" : value;
    }

    @NonNull
    public String getDisplayText(boolean showLine) {
        return toDisplayText(showLine, false, -1);
    }

    @NonNull
    public String toDisplayText(boolean showLine, boolean selected, int index) {
        StringBuilder sb = new StringBuilder();

        if (selected) {
            sb.append(">> ");
        } else {
            sb.append("   ");
        }

        if (index >= 0) {
            sb.append(index + 1).append(". ");
        }

        for (int i = 0; i < level; i++) {
            sb.append("  ");
        }

        sb.append("[").append(type).append("] ").append(safeTitle());

        if (showLine) {
            sb.append("  (第 ").append(line + 1).append(" 行)");
        }

        return sb.toString();
    }

    @NonNull
    public String toCompactText(boolean showLine, int index) {
        StringBuilder sb = new StringBuilder();

        if (index >= 0) {
            sb.append(index + 1).append(". ");
        }

        sb.append("[").append(type).append("] ").append(safeTitle());

        if (showLine) {
            sb.append("  @").append(line + 1);
        }

        return sb.toString();
    }

    @NonNull
    public String toCardTitle() {
        return "[" + type + "] " + safeTitle();
    }

    @NonNull
    public String toCardMeta(boolean showLine, int index) {
        if (showLine) {
            return "第 " + (line + 1) + " 行";
        }
        if (index >= 0) {
            return "第 " + (index + 1) + " 项";
        }
        return "";
    }

    @NonNull
    public String toCardPreview() {
        StringBuilder sb = new StringBuilder();

        if (level > 0) {
            sb.append("层级：").append(level).append('\n');
        }

        sb.append("类型：").append(type).append('\n');
        sb.append("标题：").append(safeTitle());

        return sb.toString();
    }
}