# Structure Hunter for MT Plugin V3

基于 MT Plugin V3 API 的“结构猎人”增强版源码骨架。

## 这版新增

- JSON 结构树分析
- JSON 字段路径清单
- XML 结构分析
- URL Query / Form 表单参数分析
- YAML 风格缩进结构预览
- Java / Bean / 伪代码结构提取
- 结果一键复制到剪贴板
- 编辑器快捷功能 `StructureHunterEditorFunction`

## 建议注册的入口

- 设置页入口：`bin.mt.plugin.structurehunter.StructureHunterPreference`
- 编辑器快捷功能：`bin.mt.plugin.structurehunter.editor.StructureHunterEditorFunction`

## 已对齐的 API 习惯

- `PluginPreference#onBuild`
- `PluginUI#buildVerticalLayout()`
- `PluginUI#buildDialog()`
- `PluginView#requireViewById()`
- `PluginContext#getClipboardText()` / `setClipboardText()` / `showToast()` / `log()`
- `BaseTextEditorFunction`

## 当前策略

- 先按内容特征自动判断：JSON / XML / URL参数 / YAML / Java样式文本
- JSON 会同时输出“结构树”和“字段路径”
- XML 会输出节点、属性、文本摘要
- URL 参数支持完整 URL、query string、`a=1&b=2` 表单文本

## 后续可继续扩展

- 真正的 YAML 解析器
- XML 命名空间与属性路径模式
- 生成 DTO / 字段文档
- 接口请求体 / 响应体对照分析
- 直接写回编辑器注释模板
