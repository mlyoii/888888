package tools;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 验证 .mtl 格式，行为尽量贴近宿主解析逻辑。
 */
public final class MtlValidator {

    private MtlValidator() {
    }

    public static void validate(File file) throws IOException, MtlValidationException {
        List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
        parse(lines, file.getPath());
    }

    public static List<String> validateAll(List<File> files) {
        List<String> errors = new ArrayList<>();
        for (File file : files) {
            try {
                validate(file);
            } catch (MtlValidationException e) {
                errors.add(e.getMessage());
            } catch (IOException e) {
                errors.add("Failed to read file: " + file.getPath() + " - " + e.getMessage());
            }
        }
        return errors;
    }

    private static void parse(List<String> lines, String filePath) throws MtlValidationException {
        Map<String, String> values = new HashMap<>();
        for (int lineNumber = 1; lineNumber <= lines.size(); lineNumber++) {
            String line = lines.get(lineNumber - 1);
            if (isCommentOrEmpty(line)) {
                continue;
            }

            int separator = line.indexOf(": ");
            if (separator < 0) {
                throw error(filePath, lineNumber, "Parse local string failed: " + line);
            }

            String key = line.substring(0, separator);
            if (containsWhitespace(key)) {
                throw error(filePath, lineNumber, "Key cannot contain spaces: " + line);
            }
            if (values.containsKey(key)) {
                throw error(filePath, lineNumber, "Duplicate key error: '" + key + "'");
            }

            StringBuilder value = new StringBuilder();
            String current = line.substring(separator + 2);
            while (parseValue(current, value, filePath, lineNumber)) {
                lineNumber++;
                if (lineNumber > lines.size()) {
                    break;
                }
                current = lines.get(lineNumber - 1);
            }
            values.put(key, value.toString());
        }
    }

    private static boolean isCommentOrEmpty(String line) {
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == ' ' || c == '\t') {
                continue;
            }
            return c == '#';
        }
        return true;
    }

    private static boolean containsWhitespace(String value) {
        return value.indexOf(' ') >= 0 || value.indexOf('\t') >= 0;
    }

    /** @return 是否需要读取下一行继续拼接 */
    private static boolean parseValue(String line, StringBuilder out, String filePath, int lineNumber)
            throws MtlValidationException {
        if (line.isEmpty()) {
            return false;
        }
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c != '\\') {
                out.append(c);
                continue;
            }

            i++;
            if (i >= line.length()) {
                return true;
            }

            char escape = line.charAt(i);
            switch (escape) {
                case 'n':
                    out.append('\n');
                    break;
                case 'r':
                    out.append('\r');
                    break;
                case 't':
                    out.append('\t');
                    break;
                case '\\':
                    out.append('\\');
                    break;
                case 'u':
                case 'U':
                    if (i + 4 >= line.length()) {
                        throw error(filePath, lineNumber, "Invalid Unicode escape: \\" + line.substring(i));
                    }
                    String hex = line.substring(i + 1, i + 5);
                    try {
                        out.append((char) Integer.parseInt(hex, 16));
                    } catch (NumberFormatException e) {
                        throw error(filePath, lineNumber, "Invalid Unicode escape: \\" + escape + hex);
                    }
                    i += 4;
                    break;
                default:
                    throw error(filePath, lineNumber, "Invalid escape: \\" + escape);
            }
        }
        return false;
    }

    private static MtlValidationException error(String filePath, int lineNumber, String message) {
        return new MtlValidationException(message + " (in " + filePath + "  line: " + lineNumber + ")");
    }

    public static class MtlValidationException extends Exception {
        public MtlValidationException(String message) {
            super(message);
        }
    }
}
