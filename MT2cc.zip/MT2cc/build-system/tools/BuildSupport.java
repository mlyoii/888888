package tools;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

final class BuildSupport {

    private BuildSupport() {
    }

    static String readText(File file) throws IOException {
        return Files.readString(file.toPath(), StandardCharsets.UTF_8);
    }

    static void writeText(File file, String text) throws IOException {
        File parent = file.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }
        Files.writeString(file.toPath(), text, StandardCharsets.UTF_8);
    }


    static boolean writeTextIfChanged(File file, String text) throws IOException {
        String normalized = normalizeNewlines(text);
        if (file.isFile()) {
            String old = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            if (normalizeNewlines(old).equals(normalized)) {
                return false;
            }
        }
        File parent = file.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }
        Files.writeString(file.toPath(), normalized, StandardCharsets.UTF_8);
        return true;
    }

    static void copyFile(File src, File dst) throws IOException {
        File parent = dst.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }
        Files.copy(src.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    static void recreateDirectory(File dir) throws IOException {
        deleteRecursively(dir);
        if (!dir.mkdirs() && !dir.isDirectory()) {
            throw new IOException("Failed to create directory: " + dir.getPath());
        }
    }

    static void ensureDirectory(File dir) throws IOException {
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Failed to create directory: " + dir.getPath());
        }
    }

    static void deleteRecursively(File file) throws IOException {
        if (file == null || !file.exists()) {
            return;
        }
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) {
                deleteRecursively(child);
            }
        }
        if (!file.delete()) {
            throw new IOException("Failed to delete: " + file.getPath());
        }
    }

    static List<File> listFilesRecursively(File root) {
        List<File> files = new ArrayList<>();
        collect(root, files);
        return files;
    }


    private static String normalizeNewlines(String s) {
        return s.replace("\r\n", "\n").replace("\r", "\n");
    }

    private static void collect(File file, List<File> out) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isFile()) {
            out.add(file);
            return;
        }
        File[] children = file.listFiles();
        if (children == null) {
            return;
        }
        for (File child : children) {
            collect(child, out);
        }
    }
}
