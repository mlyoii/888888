package tools;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * Small CLI helper for manual MT plugin builds.
 *
 * Commands:
 *  - prepare         : generate manifest_raw.json and manifest.json
 *  - extract-strings : optional source/assets transformation
 *  - validate        : validate mtl, interfaces, generate keep rules
 *  - output-name     : print final mtp filename
 */
public final class MtPluginTool {

    private MtPluginTool() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            fail(usage());
        }

        String command = args[0];
        String[] tail = slice(args, 1);

        switch (command) {
            case "prepare":
                runPrepare(PrepareArgs.parse(tail));
                return;
            case "extract-strings":
                runExtractStrings(ExtractStringsArgs.parse(tail));
                return;
            case "validate":
                runValidate(ValidateArgs.parse(tail));
                return;
            case "output-name":
                runOutputName(OutputNameArgs.parse(tail));
                return;
            default:
                fail("Unknown command: " + command + "\n" + usage());
        }
    }

    private static void runPrepare(PrepareArgs cli) throws Exception {
        MTPluginConfig config = MTPluginConfig.load(new File(cli.configPath));
        JSONObject manifestRaw = config.toManifestJson(cli.minAndroidVersion);
        writeText(cli.outManifestRaw, manifestRaw.toString(2) + "\n");
        writeText(cli.outManifest, manifestRaw.toString(2) + "\n");
        System.out.println("[OK] Manifest generated: " + cli.outManifest);
    }

    private static void runExtractStrings(ExtractStringsArgs cli) throws Exception {
        StringExtractor.execute(
                new File(cli.srcDir),
                new File(cli.srcOutDir),
                new File(cli.assetsGenDir),
                new File(cli.manifestIn),
                new File(cli.manifestOut)
        );
    }

    private static void runValidate(ValidateArgs cli) throws Exception {
        MTPluginConfig config = MTPluginConfig.load(new File(cli.configPath));

        if (!cli.mtlDirs.isEmpty()) {
            validateMtl(cli.mtlDirs);
        }

        if (cli.outKeep != null) {
            writeKeepRules(cli.outKeep, config.buildKeepRules());
        }

        if (cli.classesDir != null) {
            validateInterfaces(config, cli.classesDir, cli.classpath);
        }
    }

    private static void runOutputName(OutputNameArgs cli) throws Exception {
        MTPluginConfig config = MTPluginConfig.load(new File(cli.configPath));
        System.out.println(config.buildOutputName());
    }

    private static void validateMtl(List<String> directories) {
        List<File> mtlFiles = new ArrayList<>();
        for (String dir : directories) {
            collectMtlFiles(new File(dir), mtlFiles);
        }

        List<String> errors = MtlValidator.validateAll(mtlFiles);
        if (!errors.isEmpty()) {
            StringBuilder message = new StringBuilder("MTL validation failed:\n");
            for (String error : errors) {
                message.append("  - ").append(error).append('\n');
            }
            fail(message.toString().trim());
        }
    }

    private static void validateInterfaces(MTPluginConfig config, String classesDir, List<String> classpath) throws Exception {
        List<URL> urls = new ArrayList<>();
        urls.add(new File(classesDir).toURI().toURL());
        for (String entry : classpath) {
            urls.add(new File(entry).toURI().toURL());
        }

        try (URLClassLoader classLoader = new URLClassLoader(urls.toArray(new URL[0]), MtPluginTool.class.getClassLoader())) {
            InterfaceValidator validator = new InterfaceValidator(classLoader);
            List<String> errors = validator.validate(
                    config.getMainPreference(),
                    config.getInterfaces().toArray(new String[0])
            );
            if (!errors.isEmpty()) {
                StringBuilder message = new StringBuilder("Interface validation failed:\n");
                for (String error : errors) {
                    message.append("  - ").append(error).append('\n');
                }
                fail(message.toString().trim());
            }
        }
    }

    private static void collectMtlFiles(File file, List<File> out) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isFile()) {
            if (file.getName().endsWith(".mtl")) {
                out.add(file);
            }
            return;
        }
        File[] children = file.listFiles();
        if (children == null) {
            return;
        }
        for (File child : children) {
            collectMtlFiles(child, out);
        }
    }

    private static void writeText(String path, String text) throws IOException {
        File file = new File(path);
        if (BuildSupport.writeTextIfChanged(file, text)) {
            System.out.println("[OK] Wrote: " + path);
        } else {
            System.out.println("[OK] Unchanged: " + path);
        }
    }

    private static void writeKeepRules(String path, String text) throws IOException {
        File file = new File(path);
        if (BuildSupport.writeTextIfChanged(file, text)) {
            System.out.println("[OK] Keep rules generated: " + path);
        } else {
            System.out.println("[OK] Keep rules unchanged: " + path);
        }
    }

    private static String requireValue(String[] args, int index, String flag) {
        if (index >= args.length) {
            fail("Missing value for " + flag);
        }
        return args[index];
    }

    private static String[] slice(String[] array, int from) {
        String[] result = new String[Math.max(0, array.length - from)];
        if (result.length > 0) {
            System.arraycopy(array, from, result, 0, result.length);
        }
        return result;
    }

    private static String usage() {
        return "Usage:\n"
                + "  MtPluginTool prepare --config <file> --out-manifest-raw <file> --out-manifest <file> [--min-android <api>]\n"
                + "  MtPluginTool extract-strings --src <dir> --src-out <dir> --assets-out <dir> --manifest-in <file> --manifest-out <file>\n"
                + "  MtPluginTool validate --config <file> [--validate-mtl <dir> ...] [--classes <dir> --classpath <path> ...] [--out-keep <file>]\n"
                + "  MtPluginTool output-name --config <file>";
    }

    private static void fail(String message) {
        throw new IllegalArgumentException(message);
    }

    private static final class PrepareArgs {
        String configPath;
        String outManifestRaw;
        String outManifest;
        int minAndroidVersion;

        static PrepareArgs parse(String[] args) {
            PrepareArgs parsed = new PrepareArgs();
            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                switch (arg) {
                    case "--config":
                        parsed.configPath = requireValue(args, ++i, arg);
                        break;
                    case "--out-manifest-raw":
                        parsed.outManifestRaw = requireValue(args, ++i, arg);
                        break;
                    case "--out-manifest":
                        parsed.outManifest = requireValue(args, ++i, arg);
                        break;
                    case "--min-android":
                        parsed.minAndroidVersion = Integer.parseInt(requireValue(args, ++i, arg));
                        break;
                    default:
                        fail("Unknown argument for prepare: " + arg);
                }
            }
            if (parsed.configPath == null || parsed.outManifestRaw == null || parsed.outManifest == null) {
                fail("Invalid prepare arguments.\n" + usage());
            }
            return parsed;
        }
    }

    private static final class ExtractStringsArgs {
        String srcDir;
        String srcOutDir;
        String assetsGenDir;
        String manifestIn;
        String manifestOut;

        static ExtractStringsArgs parse(String[] args) {
            ExtractStringsArgs parsed = new ExtractStringsArgs();
            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                switch (arg) {
                    case "--src":
                        parsed.srcDir = requireValue(args, ++i, arg);
                        break;
                    case "--src-out":
                        parsed.srcOutDir = requireValue(args, ++i, arg);
                        break;
                    case "--assets-out":
                        parsed.assetsGenDir = requireValue(args, ++i, arg);
                        break;
                    case "--manifest-in":
                        parsed.manifestIn = requireValue(args, ++i, arg);
                        break;
                    case "--manifest-out":
                        parsed.manifestOut = requireValue(args, ++i, arg);
                        break;
                    default:
                        fail("Unknown argument for extract-strings: " + arg);
                }
            }
            if (parsed.srcDir == null || parsed.srcOutDir == null || parsed.assetsGenDir == null
                    || parsed.manifestIn == null || parsed.manifestOut == null) {
                fail("Invalid extract-strings arguments.\n" + usage());
            }
            return parsed;
        }
    }

    private static final class ValidateArgs {
        String configPath;
        String classesDir;
        String outKeep;
        final List<String> classpath = new ArrayList<>();
        final List<String> mtlDirs = new ArrayList<>();

        static ValidateArgs parse(String[] args) {
            ValidateArgs parsed = new ValidateArgs();
            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                switch (arg) {
                    case "--config":
                        parsed.configPath = requireValue(args, ++i, arg);
                        break;
                    case "--classes":
                        parsed.classesDir = requireValue(args, ++i, arg);
                        break;
                    case "--out-keep":
                        parsed.outKeep = requireValue(args, ++i, arg);
                        break;
                    case "--classpath":
                        while (i + 1 < args.length && !args[i + 1].startsWith("--")) {
                            parsed.classpath.add(args[++i]);
                        }
                        break;
                    case "--validate-mtl":
                        while (i + 1 < args.length && !args[i + 1].startsWith("--")) {
                            parsed.mtlDirs.add(args[++i]);
                        }
                        break;
                    default:
                        fail("Unknown argument for validate: " + arg);
                }
            }
            if (parsed.configPath == null) {
                fail("Invalid validate arguments.\n" + usage());
            }
            return parsed;
        }
    }

    private static final class OutputNameArgs {
        String configPath;

        static OutputNameArgs parse(String[] args) {
            OutputNameArgs parsed = new OutputNameArgs();
            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                if ("--config".equals(arg)) {
                    parsed.configPath = requireValue(args, ++i, arg);
                } else {
                    fail("Unknown argument for output-name: " + arg);
                }
            }
            if (parsed.configPath == null) {
                fail("Invalid output-name arguments.\n" + usage());
            }
            return parsed;
        }
    }
}
