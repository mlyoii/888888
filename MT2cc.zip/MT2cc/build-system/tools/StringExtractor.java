package tools;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;

/**
 * 安全优先的字符串提取器：
 * 1. 将 manifest 中 name / description 的中文替换为 {key}
 * 2. 将 Java 源码中“已识别的 UI 调用位点”上的中文字符串替换为 {key}
 * 3. 将 return "中文" 这类简单返回值替换为 getContext().getString("key")
 * 4. 生成 assets/strings.mtl
 * 5. 对无法安全改写的中文字符串保留原样，并输出 skipped 报告
 */
public final class StringExtractor {

    private static final Set<String> UI_STRING_METHODS = new LinkedHashSet<>(Arrays.asList(
            "text",
            "hint",
            "title",
            "subtitle",
            "summary",
            "summaryOn",
            "summaryOff",
            "addHeader",
            "addText",
            "addList",
            "setTitle",
            "setMessage",
            "setPositiveButton",
            "setNegativeButton",
            "setNeutralButton",
            "setText",
            "showToast",
            "showMessage",
            "addItem",
            "setItems",
            "setSingleChoiceItems"
    ));

    private static final Set<String> FIRST_ARG_ONLY_METHODS = new LinkedHashSet<>(Arrays.asList(
            "setPositiveButton",
            "setNegativeButton",
            "setNeutralButton",
            "addItem",
            "addList"
    ));

    private final Map<String, String> keyToValue = new LinkedHashMap<>();
    private final Map<String, String> valueToKey = new HashMap<>();
    private final List<String> skipped = new ArrayList<>();

    private final File srcDir;
    private final File dstDir;
    private final File assetsDir;
    private final File manifestIn;
    private final File manifestOut;

    private StringExtractor(File srcDir, File dstDir, File assetsDir, File manifestIn, File manifestOut) {
        this.srcDir = srcDir;
        this.dstDir = dstDir;
        this.assetsDir = assetsDir;
        this.manifestIn = manifestIn;
        this.manifestOut = manifestOut;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 5) {
            throw new IllegalArgumentException(
                    "Usage: StringExtractor <src_dir> <dst_dir> <assets_dir> <manifest_in> <manifest_out>");
        }
        execute(new File(args[0]), new File(args[1]), new File(args[2]), new File(args[3]), new File(args[4]));
    }

    public static void execute(File srcDir, File dstDir, File assetsDir, File manifestIn, File manifestOut) throws Exception {
        if (!srcDir.isDirectory()) {
            throw new IllegalArgumentException("Source directory not found: " + srcDir.getPath());
        }
        new StringExtractor(srcDir, dstDir, assetsDir, manifestIn, manifestOut).run();
    }

    private void run() throws Exception {
        BuildSupport.recreateDirectory(dstDir);
        BuildSupport.ensureDirectory(assetsDir);
        if (manifestOut.getParentFile() != null) {
            BuildSupport.ensureDirectory(manifestOut.getParentFile());
        }

        rewriteSources();
        rewriteManifest();
        generateMtlFile();
        generateSkippedReport();

        System.out.println("[OK] String extraction completed: " + keyToValue.size() + " string(s)");
        if (!skipped.isEmpty()) {
            System.out.println("[WARN] Skipped " + skipped.size() + " unsupported string literal(s), see string-extractor-skipped.txt");
        }
    }

    private void rewriteSources() throws IOException {
        List<File> files = BuildSupport.listFilesRecursively(srcDir);
        Path base = srcDir.toPath();
        for (File src : files) {
            Path relative = base.relativize(src.toPath());
            File dst = new File(dstDir, relative.toString());
            if (src.getName().endsWith(".java")) {
                rewriteJavaFile(src, dst);
            } else {
                BuildSupport.copyFile(src, dst);
            }
        }
    }

    private void rewriteJavaFile(File src, File dst) throws IOException {
        String code = BuildSupport.readText(src);
        BuildSupport.writeText(dst, rewriteJavaCode(code, src.getPath()));
    }

    private String rewriteJavaCode(String code, String filePath) {
        StringBuilder out = new StringBuilder(code.length() + 64);
        int i = 0;
        while (i < code.length()) {
            char c = code.charAt(i);
            if (c == '"') {
                int end = findStringLiteralEnd(code, i + 1);
                String raw = code.substring(i + 1, end - 1);
                out.append(rewriteStringLiteral(raw, code, i, end, filePath));
                i = end;
                continue;
            }
            if (c == '\'') {
                int end = findCharLiteralEnd(code, i + 1);
                out.append(code, i, end);
                i = end;
                continue;
            }
            if (c == '/' && i + 1 < code.length()) {
                char next = code.charAt(i + 1);
                if (next == '/') {
                    int end = findLineCommentEnd(code, i + 2);
                    out.append(code, i, end);
                    i = end;
                    continue;
                }
                if (next == '*') {
                    int end = findBlockCommentEnd(code, i + 2);
                    out.append(code, i, end);
                    i = end;
                    continue;
                }
            }
            out.append(c);
            i++;
        }
        return out.toString();
    }

    private String rewriteStringLiteral(String rawLiteral, String code, int literalStart, int literalEnd, String filePath) {
        String value = unescapeJavaString(rawLiteral);
        if (!containsChinese(value)) {
            return '"' + rawLiteral + '"';
        }

        if (isConcatenatedStringLiteral(code, literalStart, literalEnd)) {
            skipped.add(filePath + ": [拼接跳过] " + shortPreview(value));
            return '"' + rawLiteral + '"';
        }

        String key = keyFor(value);
        CallContext call = inferCallContext(code, literalStart);

        if (call != null && isUiLocalizedArgument(call)) {
            return "\"{" + key + "}\"";
        }

        if (isSimpleReturnContext(code, literalStart)) {
            return "getContext().getString(\"" + key + "\")";
        }

        skipped.add(filePath + ": " + shortPreview(value));
        return '"' + rawLiteral + '"';
    }

    private boolean isConcatenatedStringLiteral(String code, int literalStart, int literalEnd) {
        int left = skipWhitespaceBackward(code, literalStart - 1);
        int right = skipWhitespaceForward(code, literalEnd);

        if (left >= 0 && code.charAt(left) == '+') {
            return true;
        }
        if (right < code.length() && code.charAt(right) == '+') {
            return true;
        }
        return false;
    }

    private int skipWhitespaceBackward(String code, int index) {
        int i = index;
        while (i >= 0 && Character.isWhitespace(code.charAt(i))) {
            i--;
        }
        return i;
    }

    private int skipWhitespaceForward(String code, int index) {
        int i = index;
        while (i < code.length() && Character.isWhitespace(code.charAt(i))) {
            i++;
        }
        return i;
    }

    private boolean isUiLocalizedArgument(CallContext call) {
        if (!UI_STRING_METHODS.contains(call.methodName)) {
            return false;
        }

        if (FIRST_ARG_ONLY_METHODS.contains(call.methodName)) {
            return call.argIndex == 0;
        }

        if ("showMessage".equals(call.methodName)) {
            return call.argIndex == 0 || call.argIndex == 1;
        }

        if ("setItems".equals(call.methodName) || "setSingleChoiceItems".equals(call.methodName)) {
            return false;
        }

        return true;
    }

    private boolean isSimpleReturnContext(String code, int literalStart) {
        int start = Math.max(0, literalStart - 40);
        String prefix = code.substring(start, literalStart);
        return prefix.matches("(?s).*(^|\\W)return\\s*$");
    }

    private CallContext inferCallContext(String code, int literalStart) {
        int i = literalStart - 1;
        while (i >= 0 && Character.isWhitespace(code.charAt(i))) {
            i--;
        }
        if (i < 0) {
            return null;
        }
        if (code.charAt(i) != '(' && code.charAt(i) != ',') {
            return null;
        }

        int argIndex = 0;
        int depthParen = 0;
        int depthBracket = 0;
        int depthBrace = 0;
        boolean inDoubleQuote = false;
        boolean inSingleQuote = false;
        boolean escaping = false;
        int openParen = -1;

        for (int p = i; p >= 0; p--) {
            char ch = code.charAt(p);

            if (inDoubleQuote) {
                if (escaping) {
                    escaping = false;
                } else if (ch == '\\') {
                    escaping = true;
                } else if (ch == '"') {
                    inDoubleQuote = false;
                }
                continue;
            }

            if (inSingleQuote) {
                if (escaping) {
                    escaping = false;
                } else if (ch == '\\') {
                    escaping = true;
                } else if (ch == '\'') {
                    inSingleQuote = false;
                }
                continue;
            }

            if (ch == '"') {
                inDoubleQuote = true;
                continue;
            }
            if (ch == '\'') {
                inSingleQuote = true;
                continue;
            }

            if (ch == ')') {
                depthParen++;
                continue;
            }
            if (ch == ']') {
                depthBracket++;
                continue;
            }
            if (ch == '}') {
                depthBrace++;
                continue;
            }
            if (ch == '(') {
                if (depthParen == 0 && depthBracket == 0 && depthBrace == 0) {
                    openParen = p;
                    break;
                }
                depthParen--;
                continue;
            }
            if (ch == '[' && depthBracket > 0) {
                depthBracket--;
                continue;
            }
            if (ch == '{' && depthBrace > 0) {
                depthBrace--;
                continue;
            }
            if (ch == ',' && depthParen == 0 && depthBracket == 0 && depthBrace == 0) {
                argIndex++;
            }
        }

        if (openParen < 0) {
            return null;
        }

        int end = openParen - 1;
        while (end >= 0 && Character.isWhitespace(code.charAt(end))) {
            end--;
        }
        if (end < 0) {
            return null;
        }

        int start = end;
        while (start >= 0) {
            char ch = code.charAt(start);
            if (Character.isJavaIdentifierPart(ch) || ch == '.') {
                start--;
            } else {
                break;
            }
        }

        String chain = code.substring(start + 1, end + 1);
        if (chain.isEmpty()) {
            return null;
        }

        int dot = chain.lastIndexOf('.');
        String methodName = dot >= 0 ? chain.substring(dot + 1) : chain;
        if (methodName.isEmpty()) {
            return null;
        }

        return new CallContext(methodName, argIndex);
    }

    private int findStringLiteralEnd(String code, int start) {
        boolean escaping = false;
        for (int i = start; i < code.length(); i++) {
            char c = code.charAt(i);
            if (escaping) {
                escaping = false;
                continue;
            }
            if (c == '\\') {
                escaping = true;
                continue;
            }
            if (c == '"') {
                return i + 1;
            }
        }
        return code.length();
    }

    private int findCharLiteralEnd(String code, int start) {
        boolean escaping = false;
        for (int i = start; i < code.length(); i++) {
            char c = code.charAt(i);
            if (escaping) {
                escaping = false;
                continue;
            }
            if (c == '\\') {
                escaping = true;
                continue;
            }
            if (c == '\'') {
                return i + 1;
            }
        }
        return code.length();
    }

    private int findLineCommentEnd(String code, int start) {
        int i = start;
        while (i < code.length() && code.charAt(i) != '\n') {
            i++;
        }
        return i;
    }

    private int findBlockCommentEnd(String code, int start) {
        int i = start;
        while (i + 1 < code.length()) {
            if (code.charAt(i) == '*' && code.charAt(i + 1) == '/') {
                return i + 2;
            }
            i++;
        }
        return code.length();
    }

    private void rewriteManifest() throws IOException {
        if (!manifestIn.isFile()) {
            return;
        }
        JSONObject manifest = new JSONObject(stripComments(BuildSupport.readText(manifestIn)));
        replaceManifestField(manifest, "name");
        replaceManifestField(manifest, "description");
        BuildSupport.writeText(manifestOut, manifest.toString(2) + "\n");
    }

    private void replaceManifestField(JSONObject json, String field) {
        if (!json.has(field)) {
            return;
        }
        String value = json.optString(field, null);
        if (value == null || !containsChinese(value)) {
            return;
        }
        json.put(field, "{" + keyFor(value) + "}");
    }

    private String keyFor(String text) {
        String normalized = text.trim();
        String existing = valueToKey.get(normalized);
        if (existing != null) {
            return existing;
        }
        String key = buildStableKey(normalized);
        while (keyToValue.containsKey(key) && !normalized.equals(keyToValue.get(key))) {
            key = key + "_";
        }
        keyToValue.put(key, normalized);
        valueToKey.put(normalized, key);
        return key;
    }

    private String buildStableKey(String text) {
        CRC32 crc32 = new CRC32();
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        crc32.update(bytes, 0, bytes.length);
        long value = crc32.getValue();
        return "s_" + Long.toHexString(value);
    }

    private void generateMtlFile() throws IOException {
        File out = new File(assetsDir, "strings.mtl");
        StringBuilder content = new StringBuilder();
        List<Map.Entry<String, String>> entries = new ArrayList<>(keyToValue.entrySet());
        entries.sort(Comparator.comparing(Map.Entry::getKey));
        for (Map.Entry<String, String> entry : entries) {
            content.append(entry.getKey())
                    .append(": ")
                    .append(escapeMtlValue(entry.getValue()))
                    .append('\n');
        }
        BuildSupport.writeText(out, content.toString());
    }

    private void generateSkippedReport() throws IOException {
        if (skipped.isEmpty()) {
            return;
        }
        File out = new File(dstDir, "string-extractor-skipped.txt");
        StringBuilder sb = new StringBuilder();
        sb.append("以下中文字符串未被自动替换，因为当前工具无法确认其安全上下文。\n");
        sb.append("你可以手工改成 getContext().getString(\"key\")，或补充规则后再次执行。\n\n");
        for (String line : skipped) {
            sb.append("- ").append(line).append('\n');
        }
        BuildSupport.writeText(out, sb.toString());
    }

    private static String escapeMtlValue(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static String stripComments(String input) {
        StringBuilder out = new StringBuilder(input.length());
        boolean inString = false;
        boolean escaping = false;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            char next = i + 1 < input.length() ? input.charAt(i + 1) : 0;
            if (!inString && c == '/' && next == '/') {
                while (i < input.length() && input.charAt(i) != '\n') {
                    i++;
                }
                if (i < input.length()) {
                    out.append('\n');
                }
                continue;
            }
            if (!inString && c == '/' && next == '*') {
                i += 2;
                while (i + 1 < input.length() && !(input.charAt(i) == '*' && input.charAt(i + 1) == '/')) {
                    i++;
                }
                i++;
                continue;
            }
            out.append(c);
            if (inString) {
                if (escaping) {
                    escaping = false;
                } else if (c == '\\') {
                    escaping = true;
                } else if (c == '"') {
                    inString = false;
                }
            } else if (c == '"') {
                inString = true;
            }
        }
        return out.toString();
    }

    private static boolean containsChinese(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (isChineseChar(text.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    private static boolean isChineseChar(char c) {
        Character.UnicodeBlock block = Character.UnicodeBlock.of(c);
        return Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS.equals(block)
                || Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS.equals(block)
                || Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A.equals(block)
                || Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION.equals(block)
                || Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS.equals(block)
                || (c >= 0x4E00 && c <= 0x9FFF);
    }

    private static String unescapeJavaString(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch != '\\') {
                out.append(ch);
                continue;
            }
            char next = (i == text.length() - 1) ? '\\' : text.charAt(i + 1);
            if (next >= '0' && next <= '7') {
                StringBuilder octal = new StringBuilder().append(next);
                i++;
                for (int j = 0; j < 2 && i + 1 < text.length(); j++) {
                    char more = text.charAt(i + 1);
                    if (more < '0' || more > '7') {
                        break;
                    }
                    octal.append(more);
                    i++;
                }
                out.append((char) Integer.parseInt(octal.toString(), 8));
                continue;
            }
            switch (next) {
                case '\\': out.append('\\'); break;
                case 'b': out.append('\b'); break;
                case 'f': out.append('\f'); break;
                case 'n': out.append('\n'); break;
                case 'r': out.append('\r'); break;
                case 't': out.append('\t'); break;
                case '"': out.append('"'); break;
                case '\'': out.append('\''); break;
                case 'u':
                    if (i + 5 < text.length()) {
                        String hex = text.substring(i + 2, i + 6);
                        try {
                            out.append((char) Integer.parseInt(hex, 16));
                            i += 5;
                            break;
                        } catch (NumberFormatException ignored) {
                        }
                    }
                    out.append('u');
                    break;
                default:
                    out.append(next);
                    break;
            }
            i++;
        }
        return out.toString();
    }

    private static String shortPreview(String text) {
        String s = text.replace('\n', ' ').trim();
        return s.length() <= 40 ? s : s.substring(0, 40) + "...";
    }

    private static final class CallContext {
        final String methodName;
        final int argIndex;

        CallContext(String methodName, int argIndex) {
            this.methodName = methodName;
            this.argIndex = argIndex;
        }
    }
}