package tools;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 校验 mt-config.json 中声明的 mainPreference / interfaces。
 */
public class InterfaceValidator {

    private static final String TRANSLATION_ENGINE = "bin.mt.plugin.api.translation.TranslationEngine";
    private static final String TEXT_EDITOR_FUNCTION = "bin.mt.plugin.api.editor.TextEditorFunction";
    private static final String TEXT_EDITOR_FLOATING_MENU = "bin.mt.plugin.api.editor.TextEditorFloatingMenu";
    private static final String TEXT_EDITOR_TOOL_MENU = "bin.mt.plugin.api.editor.TextEditorToolMenu";
    private static final String PLUGIN_PREFERENCE = "bin.mt.plugin.api.preference.PluginPreference";

    private static final String[] VALID_INTERFACE_TYPES = {
            TRANSLATION_ENGINE,
            TEXT_EDITOR_FUNCTION,
            TEXT_EDITOR_FLOATING_MENU,
            TEXT_EDITOR_TOOL_MENU
    };

    private final URLClassLoader classLoader;

    public InterfaceValidator(URLClassLoader classLoader) {
        this.classLoader = classLoader;
    }

    public List<String> validate(String mainPreference, String[] interfaces) {
        List<String> errors = new ArrayList<>();
        validateInterfaces(interfaces, errors);
        validateMainPreferenceIfPresent(mainPreference, errors);
        return errors;
    }

    private void validateInterfaces(String[] interfaces, List<String> errors) {
        if (interfaces == null || interfaces.length == 0) {
            return;
        }

        Set<String> seen = new LinkedHashSet<>();
        for (int i = 0; i < interfaces.length; i++) {
            String className = safeTrim(interfaces[i]);
            String field = "interfaces[" + i + "]";
            if (className == null) {
                errors.add(field + " is empty.");
                continue;
            }
            if (!seen.add(className)) {
                errors.add(field + " = \"" + className + "\"\n    Error: Duplicate class declaration.");
                continue;
            }
            try {
                validateInterface(className, field);
            } catch (InterfaceValidationException e) {
                errors.add(e.getMessage());
            }
        }
    }

    private void validateMainPreferenceIfPresent(String mainPreference, List<String> errors) {
        String className = safeTrim(mainPreference);
        if (className == null) {
            return;
        }
        try {
            validateMainPreference(className);
        } catch (InterfaceValidationException e) {
            errors.add(e.getMessage());
        }
    }

    private void validateInterface(String className, String configField) throws InterfaceValidationException {
        Class<?> clazz = loadAndCheckClass(className, configField);

        for (String interfaceName : VALID_INTERFACE_TYPES) {
            Class<?> interfaceClass = tryLoad(interfaceName);
            if (interfaceClass != null && interfaceClass.isAssignableFrom(clazz)) {
                return;
            }
        }

        throw new InterfaceValidationException(
                configField + " = \"" + className + "\"\n" +
                "    Error: Class does not implement a supported MT plugin interface.\n" +
                "    Supported types:\n" +
                "      - TranslationEngine\n" +
                "      - TextEditorFunction\n" +
                "      - TextEditorFloatingMenu\n" +
                "      - TextEditorToolMenu"
        );
    }

    private void validateMainPreference(String className) throws InterfaceValidationException {
        Class<?> clazz = loadAndCheckClass(className, "mainPreference");
        Class<?> pluginPreferenceClass = tryLoad(PLUGIN_PREFERENCE);
        if (pluginPreferenceClass == null) {
            throw new InterfaceValidationException(
                    "mainPreference = \"" + className + "\"\n" +
                    "    Error: PluginPreference not found in classpath."
            );
        }
        if (!pluginPreferenceClass.isAssignableFrom(clazz)) {
            throw new InterfaceValidationException(
                    "mainPreference = \"" + className + "\"\n" +
                    "    Error: Class must implement PluginPreference."
            );
        }
    }

    private Class<?> loadAndCheckClass(String className, String configField) throws InterfaceValidationException {
        Class<?> clazz;
        try {
            clazz = Class.forName(className, false, classLoader);
        } catch (ClassNotFoundException e) {
            throw new InterfaceValidationException(
                    configField + " = \"" + className + "\"\n" +
                    "    Error: Class not found."
            );
        }

        int modifiers = clazz.getModifiers();
        if (!Modifier.isPublic(modifiers)) {
            throw new InterfaceValidationException(configField + " = \"" + className + "\"\n    Error: Class must be public.");
        }
        if (Modifier.isAbstract(modifiers)) {
            throw new InterfaceValidationException(configField + " = \"" + className + "\"\n    Error: Class cannot be abstract.");
        }
        if (Modifier.isInterface(modifiers)) {
            throw new InterfaceValidationException(configField + " = \"" + className + "\"\n    Error: Must be a class, not an interface.");
        }

        try {
            Constructor<?> constructor = clazz.getConstructor();
            if (!Modifier.isPublic(constructor.getModifiers())) {
                throw new InterfaceValidationException(configField + " = \"" + className + "\"\n    Error: No public no-arg constructor.");
            }
        } catch (NoSuchMethodException e) {
            throw new InterfaceValidationException(configField + " = \"" + className + "\"\n    Error: No public no-arg constructor.");
        }
        return clazz;
    }

    private Class<?> tryLoad(String className) {
        try {
            return Class.forName(className, false, classLoader);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    private static String safeTrim(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    public static class InterfaceValidationException extends Exception {
        public InterfaceValidationException(String message) {
            super(message);
        }
    }
}
