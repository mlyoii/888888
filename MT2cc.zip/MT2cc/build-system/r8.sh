#!/usr/bin/env bash
set -euo pipefail
IFS=$'
	'
shopt -s nullglob

MODE="release"
EXTRACT_STRINGS=false

for arg in "$@"; do
  case "$arg" in
    debug) MODE="debug" ;;
    release) MODE="release" ;;
    --extract-strings) EXTRACT_STRINGS=true ;;
    *)
      echo "用法:"
      echo "  bash ../../build-system/r8.sh"
      echo "  bash ../../build-system/r8.sh debug"
      echo "  bash ../../build-system/r8.sh --extract-strings"
      echo "  bash ../../build-system/r8.sh debug --extract-strings"
      exit 1
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WORKSPACE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PLUGIN_DIR="$(pwd)"

BUILD_DIR="$PLUGIN_DIR/build"
DIST_DIR="$PLUGIN_DIR/dist"
TOOLS_DIR="$BUILD_DIR/tools"
CLASSES_DIR="$BUILD_DIR/classes"
DEX_DIR="$BUILD_DIR/dex"
AAR_LIB_DIR="$BUILD_DIR/aar_libs"
DICT_DIR="$BUILD_DIR/dict"
SRC_MOD_DIR="$BUILD_DIR/src_mod"
ASSETS_GEN_DIR="$BUILD_DIR/assets"

CONFIG_FILE="$PLUGIN_DIR/mt-config.json"
TOOLS_JSON_JAR="$SCRIPT_DIR/tools/libs/json.jar"
PLUGIN_LIBS_DIR="$PLUGIN_DIR/libs"
SHARED_LIBS_DIR="$WORKSPACE_DIR/shared/libs"
OUT_NAME=""
MIN_ANDROID="0"

ANDROID_HOME="${ANDROID_HOME:-}"
ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-}"
JAVA_HOME="${JAVA_HOME:-}"

BUILD_TOOL_VER=""
PLATFORM_VER=""
ANDROID_JAR=""
R8_JAR=""
JAVA_BIN=""
JAVAC_BIN=""
COMPILE_CP=""
TOOL_CP=""

log() { printf '[%s] %s
' "$1" "$2"; }
die() { printf '[错误] %s
' "$1" >&2; exit 1; }

join_by_colon() {
  local out=""
  local item
  for item in "$@"; do
    [ -n "$item" ] || continue
    if [ -z "$out" ]; then out="$item"; else out="$out:$item"; fi
  done
  printf '%s' "$out"
}

detect_java() {
  if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
    JAVA_BIN="$JAVA_HOME/bin/java"
    JAVAC_BIN="$JAVA_HOME/bin/javac"
    return
  fi
  if command -v java >/dev/null 2>&1 && command -v javac >/dev/null 2>&1; then
    JAVA_BIN="$(command -v java)"
    JAVAC_BIN="$(command -v javac)"
    return
  fi
  die "未找到 JDK，请安装 OpenJDK 或设置 JAVA_HOME"
}

detect_android_sdk() {
  local project_sdk="$WORKSPACE_DIR/env/android-sdk"
  if [ -d "$project_sdk" ]; then ANDROID_HOME="$project_sdk"; return; fi
  if [ -n "${ANDROID_HOME:-}" ] && [ -d "$ANDROID_HOME" ]; then return; fi
  if [ -n "${ANDROID_SDK_ROOT:-}" ] && [ -d "$ANDROID_SDK_ROOT" ]; then ANDROID_HOME="$ANDROID_SDK_ROOT"; return; fi
  die "未找到 Android SDK（已尝试 env/android-sdk, ANDROID_HOME, ANDROID_SDK_ROOT）"
}

collect_jars() {
  local dir="$1"
  [ -d "$dir" ] || return 0
  local f
  for f in "$dir"/*.jar; do
    [ -e "$f" ] || continue
    printf '%s
' "$f"
  done
}

run_java() { "$JAVA_BIN" -Dfile.encoding=UTF-8 "$@"; }
run_javac() { "$JAVAC_BIN" -J-Dfile.encoding=UTF-8 "$@"; }

prepare_env() {
  detect_java
  detect_android_sdk
  [ -d "$ANDROID_HOME/build-tools" ] || die "build-tools 不存在: $ANDROID_HOME/build-tools"
  [ -d "$ANDROID_HOME/platforms" ] || die "platforms 不存在: $ANDROID_HOME/platforms"
  [ -f "$CONFIG_FILE" ] || die "未找到配置文件: $CONFIG_FILE"
  [ -f "$TOOLS_JSON_JAR" ] || die "未找到: $TOOLS_JSON_JAR"

  BUILD_TOOL_VER=$(find "$ANDROID_HOME/build-tools" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sed 's#.*/##' | sort -V | tail -n1)
  [ -n "$BUILD_TOOL_VER" ] || die "未找到 Android build-tools"
  PLATFORM_VER=$(find "$ANDROID_HOME/platforms" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sed 's#.*/##' | sort -V | tail -n1)
  [ -n "$PLATFORM_VER" ] || die "未找到 Android platforms"
  ANDROID_JAR="$ANDROID_HOME/platforms/$PLATFORM_VER/android.jar"
  [ -f "$ANDROID_JAR" ] || die "android.jar 不存在: $ANDROID_JAR"
  R8_JAR="$ANDROID_HOME/build-tools/$BUILD_TOOL_VER/lib/r8.jar"
  [ -f "$R8_JAR" ] || R8_JAR="$ANDROID_HOME/build-tools/$BUILD_TOOL_VER/lib/d8.jar"
  [ -f "$R8_JAR" ] || die "未找到 r8.jar 或 d8.jar"
  TOOL_CP="$(join_by_colon "$TOOLS_DIR" "$TOOLS_JSON_JAR")"
  mkdir -p "$DIST_DIR"
  log 环境 "WORKSPACE=$WORKSPACE_DIR"
  log 环境 "PLUGIN_DIR=$PLUGIN_DIR"
  log 环境 "ANDROID_HOME=$ANDROID_HOME"
  log 环境 "JAVA_BIN=$JAVA_BIN"
  log 环境 "JAVAC_BIN=$JAVAC_BIN"
  log 环境 "Build Tools: $BUILD_TOOL_VER"
  log 环境 "Platform: $PLATFORM_VER"
  log 环境 "模式: $MODE"
  log 环境 "提取字符串: $EXTRACT_STRINGS"
}

reset_build() {
  rm -rf "$BUILD_DIR"
  mkdir -p "$TOOLS_DIR" "$CLASSES_DIR" "$DEX_DIR" "$AAR_LIB_DIR" "$DICT_DIR" "$SRC_MOD_DIR" "$ASSETS_GEN_DIR"
}

extract_aar_from_dir() {
  local source_dir="$1"
  local aar name tmpdir outjar
  [ -d "$source_dir" ] || return 0
  for aar in "$source_dir"/*.aar; do
    [ -e "$aar" ] || continue
    name="$(basename "$aar")"
    outjar="$AAR_LIB_DIR/$name.jar"
    tmpdir="$BUILD_DIR/aar_unpack_${name%.aar}"
    rm -rf "$tmpdir"
    mkdir -p "$tmpdir"
    cp -f "$aar" "$tmpdir/input.zip"
    ( cd "$tmpdir" && jar xf input.zip classes.jar >/dev/null 2>&1 || true )
    if [ -f "$tmpdir/classes.jar" ]; then
      mv -f "$tmpdir/classes.jar" "$outjar"
      log AAR "已提取 $name"
    else
      log 警告 "$name 中未找到 classes.jar"
    fi
    rm -rf "$tmpdir"
  done
}

extract_aar_libs() {
  extract_aar_from_dir "$PLUGIN_LIBS_DIR"
  extract_aar_from_dir "$SHARED_LIBS_DIR"
}

compile_tools() {
  run_javac -encoding UTF-8 -cp "$TOOLS_JSON_JAR" -d "$TOOLS_DIR"     "$SCRIPT_DIR/tools/BuildSupport.java"     "$SCRIPT_DIR/tools/MTPluginConfig.java"     "$SCRIPT_DIR/tools/StringExtractor.java"     "$SCRIPT_DIR/tools/MtPluginTool.java"     "$SCRIPT_DIR/tools/MtlValidator.java"     "$SCRIPT_DIR/tools/InterfaceValidator.java"
}

generate_manifest() {
  run_java -cp "$TOOL_CP" tools.MtPluginTool prepare     --config "$CONFIG_FILE"     --min-android "$MIN_ANDROID"     --out-manifest-raw "$BUILD_DIR/manifest_raw.json"     --out-manifest "$BUILD_DIR/manifest.json"

  MIN_ANDROID=$(grep -o '"minAndroidVersion"[[:space:]]*:[[:space:]]*[0-9]\+' "$BUILD_DIR/manifest_raw.json" | grep -o '[0-9]\+' | head -n1)
  [ -n "$MIN_ANDROID" ] || die "无法从 manifest_raw.json 读取 minAndroidVersion"
  OUT_NAME="$(run_java -cp "$TOOL_CP" tools.MtPluginTool output-name --config "$CONFIG_FILE" | tail -n1)"
  [ -n "$OUT_NAME" ] || die "无法根据 pluginID 生成输出文件名"
}

run_string_extractor() {
  run_java -cp "$TOOL_CP" tools.MtPluginTool extract-strings     --src "$PLUGIN_DIR/src"     --src-out "$SRC_MOD_DIR"     --assets-out "$ASSETS_GEN_DIR"     --manifest-in "$BUILD_DIR/manifest_raw.json"     --manifest-out "$BUILD_DIR/manifest.json"
}

validate_resources() {
  if [ "$EXTRACT_STRINGS" = true ]; then
    run_java -cp "$TOOL_CP" tools.MtPluginTool validate --config "$CONFIG_FILE" --validate-mtl "$PLUGIN_DIR/assets" "$ASSETS_GEN_DIR"
  else
    run_java -cp "$TOOL_CP" tools.MtPluginTool validate --config "$CONFIG_FILE" --validate-mtl "$PLUGIN_DIR/assets"
  fi
}

build_compile_classpath() {
  local entries=("." "$ANDROID_JAR")
  local f
  while IFS= read -r f; do [ -n "$f" ] && entries+=("$f"); done < <(collect_jars "$SHARED_LIBS_DIR")
  while IFS= read -r f; do [ -n "$f" ] && entries+=("$f"); done < <(collect_jars "$PLUGIN_LIBS_DIR")
  while IFS= read -r f; do [ -n "$f" ] && entries+=("$f"); done < <(collect_jars "$AAR_LIB_DIR")
  COMPILE_CP="$(join_by_colon "${entries[@]}")"
}

compile_sources() {
  local src_root="$PLUGIN_DIR/src"
  [ "$EXTRACT_STRINGS" = true ] && src_root="$SRC_MOD_DIR"
  find "$src_root" -name '*.java' | sort > "$BUILD_DIR/sources.txt"
  [ -s "$BUILD_DIR/sources.txt" ] || die "未找到可编译的 Java 文件"
  build_compile_classpath
  run_javac -encoding UTF-8 -Xlint:none -cp "$COMPILE_CP" -d "$CLASSES_DIR" @"$BUILD_DIR/sources.txt"
}

validate_interfaces_and_keep() {
  local args=(validate --config "$CONFIG_FILE" --classes "$CLASSES_DIR" --out-keep "$BUILD_DIR/mt-plugin-keep.pro" --classpath "$ANDROID_JAR")
  local f
  while IFS= read -r f; do [ -n "$f" ] && args+=("$f"); done < <(collect_jars "$SHARED_LIBS_DIR")
  while IFS= read -r f; do [ -n "$f" ] && args+=("$f"); done < <(collect_jars "$PLUGIN_LIBS_DIR")
  while IFS= read -r f; do [ -n "$f" ] && args+=("$f"); done < <(collect_jars "$AAR_LIB_DIR")
  run_java -cp "$TOOL_CP" tools.MtPluginTool "${args[@]}"
}

package_program_jar() { jar -cf "$BUILD_DIR/program_code.jar" -C "$CLASSES_DIR" .; }

run_release_r8() {
  cat > "$DICT_DIR/dict.txt" <<'DICT'
o
O
DICT
  local DICT_FILE="$DICT_DIR/dict.txt"
  cat > "$BUILD_DIR/r8-rules.pro" <<EOF_RULES
-obfuscationdictionary "$DICT_FILE"
-classobfuscationdictionary "$DICT_FILE"
-packageobfuscationdictionary "$DICT_FILE"
-overloadaggressively
-repackageclasses ''
-allowaccessmodification
-keepattributes !*
-dontnote **
-dontwarn **
-ignorewarnings
EOF_RULES
  local r8_inputs=("$BUILD_DIR/program_code.jar")
  local r8_libs=(--lib "$ANDROID_JAR")
  local lib_only_keywords=("api-" "okhttp" "okio" "kotlin" "android.jar" "annotation")
  local f file k is_lib
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    file="$(basename "$f")"
    is_lib=false
    for k in "${lib_only_keywords[@]}"; do
      if [[ "$file" == *"$k"* ]]; then is_lib=true; break; fi
    done
    if $is_lib; then log 库引用 "$file"; r8_libs+=(--lib "$f"); else log 打包混淆 "$file"; r8_inputs+=("$f"); fi
  done < <(
    collect_jars "$SHARED_LIBS_DIR"
    collect_jars "$PLUGIN_LIBS_DIR"
    collect_jars "$AAR_LIB_DIR"
  )
  local r8_cmd=("$JAVA_BIN" -Dfile.encoding=UTF-8 -cp "$R8_JAR" com.android.tools.r8.R8 --release --min-api "$MIN_ANDROID" --output "$DEX_DIR")
  r8_cmd+=("${r8_libs[@]}")
  r8_cmd+=(--pg-conf "$BUILD_DIR/r8-rules.pro")
  [ -f "$BUILD_DIR/mt-plugin-keep.pro" ] && r8_cmd+=(--pg-conf "$BUILD_DIR/mt-plugin-keep.pro")
  r8_cmd+=("${r8_inputs[@]}")
  "${r8_cmd[@]}" > "$BUILD_DIR/r8.log" 2>&1 || die "R8 执行失败，详见 $BUILD_DIR/r8.log"
  [ -f "$DEX_DIR/classes.dex" ] || die "R8 未产出 classes.dex"
}

run_debug_d8() {
  local d8_inputs=("$BUILD_DIR/program_code.jar")
  local f
  while IFS= read -r f; do [ -n "$f" ] && d8_inputs+=("$f"); done < <(
    collect_jars "$SHARED_LIBS_DIR"
    collect_jars "$PLUGIN_LIBS_DIR"
    collect_jars "$AAR_LIB_DIR"
  )
  local d8_cmd=("$JAVA_BIN" -Dfile.encoding=UTF-8 -cp "$R8_JAR" com.android.tools.r8.D8 --min-api "$MIN_ANDROID" --lib "$ANDROID_JAR" --output "$DEX_DIR")
  d8_cmd+=("${d8_inputs[@]}")
  "${d8_cmd[@]}" > "$BUILD_DIR/d8.log" 2>&1 || die "D8 执行失败，详见 $BUILD_DIR/d8.log"
  [ -f "$DEX_DIR/classes.dex" ] || die "D8 未产出 classes.dex"
}

run_r8() {
  if [ "$MODE" = "debug" ]; then log 模式 "DEBUG（D8）"; run_debug_d8; else log 模式 "RELEASE（R8）"; run_release_r8; fi
}

assemble_mtp() {
  rm -rf "$DEX_DIR/META-INF"
  mkdir -p "$DEX_DIR/assets"
  cp -f "$BUILD_DIR/manifest.json" "$DEX_DIR/manifest.json"
  [ -f "$PLUGIN_DIR/icon.png" ] && cp -f "$PLUGIN_DIR/icon.png" "$DEX_DIR/"
  [ -f "$PLUGIN_DIR/icon.jpg" ] && cp -f "$PLUGIN_DIR/icon.jpg" "$DEX_DIR/"
  [ -d "$PLUGIN_DIR/assets" ] && cp -rf "$PLUGIN_DIR/assets/." "$DEX_DIR/assets/"
  if [ "$EXTRACT_STRINGS" = true ] && [ -d "$ASSETS_GEN_DIR" ]; then cp -rf "$ASSETS_GEN_DIR"/. "$DEX_DIR/assets/"; fi
  local items=(classes.dex manifest.json assets)
  [ -f "$DEX_DIR/icon.png" ] && items+=(icon.png)
  [ -f "$DEX_DIR/icon.jpg" ] && items+=(icon.jpg)
  ( cd "$DEX_DIR" && jar -cMf "$DIST_DIR/$OUT_NAME" "${items[@]}" )
  [ -f "$DIST_DIR/$OUT_NAME" ] || die "未生成 $DIST_DIR/$OUT_NAME"
}

print_summary() {
  local size="$(wc -c < "$DIST_DIR/$OUT_NAME")"
  echo
  echo "=========================================="
  echo "[成功] 插件已生成: $DIST_DIR/$OUT_NAME"
  echo "[模式] $MODE"
  echo "[提取字符串] $EXTRACT_STRINGS"
  echo "[体积] ${size} 字节"
  echo "[内容] classes.dex + manifest.json + icon + assets/"
  echo "=========================================="
}

main() {
  prepare_env
  reset_build
  log 1/7 "准备依赖与构建工具"
  extract_aar_libs
  compile_tools
  log 2/7 "生成 manifest"
  generate_manifest
  if [ "$EXTRACT_STRINGS" = true ]; then log 3/7 "提取字符串"; run_string_extractor; else log 3/7 "跳过字符串提取"; fi
  log 4/7 "校验资源"
  validate_resources
  log 5/7 "编译源码与接口校验"
  compile_sources
  validate_interfaces_and_keep
  package_program_jar
  log 6/7 "执行 $MODE 构建"
  run_r8
  log 7/7 "组装 .mtp 插件"
  assemble_mtp
  print_summary
}

main
